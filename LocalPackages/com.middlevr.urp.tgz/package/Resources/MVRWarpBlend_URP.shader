Shader "MVR/WarpBlend_URP"
{
    Properties
	{
		_ColorMap("ColorMap", 2D) = "white" { }
        _BlendTex("BlendTex", 2D) = "white" { }
        _BlackTex("BlackTex", 2D) = "black" { }
        _CropRect ("Crop Rect", Vector) = (0, 0, 1, 1)
	}

    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline" = "UniversalPipeline"}

        ZWrite Off
        Cull Off
        ZTest Always

        Pass
        {
            Name "MVRWarpBlend_URP"

            HLSLPROGRAM
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            #pragma vertex Vert
            #pragma fragment frag

            TEXTURE2D_X(_ColorMap);
            SAMPLER(sampler_ColorMap);

            TEXTURE2D_X(_BlendTex);
            SAMPLER(sampler_BlendTex);

            TEXTURE2D_X(_BlackTex);
            SAMPLER(sampler_BlackTex);

            float _Gamma = 1.0;

            //TEXTURE2D_X(_CameraOpaqueTexture);
            //SAMPLER(sampler_CameraOpaqueTexture);

            float4x4 _LocalToWorldMatrix;
            float4x4 _WorldToCameraMatrix;
            float4x4 _CustomProjMatrix;

            float4 _Scale;

            float4 _CropRect; // Crop rectangle as (left, top, right, bottom)

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 uv0 : TEXCOORD0;
                float2 uv1 : TEXCOORD1;
            };

            struct Varyings
            {
                float4 positionHCS : SV_POSITION;
                float3 uv0 : TEXCOORD0;
                float2 uv1 : TEXCOORD1;
            };

            Varyings Vert(Attributes input)
            {
                Varyings output;
    
                output.positionHCS = float4(input.positionOS.x, -input.positionOS.y, input.positionOS.z, 1);
                output.uv0 = input.uv0;
                output.uv1 = input.uv1;
                return output;
            }

            float2 WarpCb(float4 localVertex)
            {
                float4 worldPos = mul(_LocalToWorldMatrix, localVertex);
                float4 viewPos = mul(_WorldToCameraMatrix, worldPos);
                float4 projPos = mul(_CustomProjMatrix, viewPos);
                float2 ndcPos = projPos.xy / projPos.w;
                float2 viewportPos = ndcPos.xy * 0.5f + 0.5f;

                return viewportPos;
            }

            half4 frag(Varyings input) : SV_Target
            {
                float2 colorMapUv = WarpCb(float4(input.uv0.xyz, 1.0f));
                //colorMapUv.x = colorMapUv.x * _Scale.x;
                //colorMapUv.y = colorMapUv.y * _Scale.y;

                // Map UVs from full texture space to the crop rectangle
                float2 croppedUV;
                croppedUV.x = lerp(_CropRect.x, _CropRect.z, colorMapUv.x);
                croppedUV.y = lerp(_CropRect.y, _CropRect.w, colorMapUv.y);

                float4 col = SAMPLE_TEXTURE2D_X(_ColorMap, sampler_ColorMap, croppedUV);

                float3 col3 = col.rgb;
                float3 blend = (float3)SAMPLE_TEXTURE2D_X(_BlendTex, sampler_BlendTex, input.uv1);
                float3 gamma = float3(_Gamma, _Gamma, _Gamma);
                float  gammaBlack = (float)pow(abs((float3)SAMPLE_TEXTURE2D_X(_BlackTex, sampler_BlackTex, input.uv1)), gamma);
                float3 gammaColor = pow(abs(col3 * blend), gamma);
                float3 gammaColorCorrection = ( gammaColor * (1.0 - gammaBlack) + gammaBlack);

                float3 color = pow(abs(gammaColorCorrection),float3(1.0 / _Gamma, 1.0 / _Gamma, 1.0 / _Gamma));

                return float4(color, 1.0);
            }
            ENDHLSL
        }
    }
}