Shader "MVR/ProjectiveTransform_URP"
{
    Properties
    {
        _ColorMap ("ColorMap", 2D) = "white" {}
        _Background("Background", Color) = (0, 0, 0, 1)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline" = "UniversalPipeline"}

        // No culling or depth
        Cull Off
        ZWrite Off
        ZTest Always

        Pass
        {
            Name "MVRProjectiveTransform_URP"

            HLSLPROGRAM
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            #pragma vertex vert
            #pragma fragment frag

            TEXTURE2D_X(_ColorMap);
            SAMPLER(sampler_ColorMap);

            float4 _Background;
            float4x4 _Transform;
            
            struct appdata
            {
                uint vertexID : SV_VertexID;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct v2f
            {
                float4 positionCS : SV_POSITION;
                float4 uv : TEXCOORD0;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            v2f vert (appdata input)
            {
                v2f output;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                float4 pos = GetFullScreenTriangleVertexPosition(input.vertexID);
                float2 uv = GetFullScreenTriangleTexCoord(input.vertexID);

                output.positionCS = pos;
                output.uv = mul(_Transform, (float4(uv.xy, 0, 1)));
                return output;
            }

            half4 frag(v2f i) : SV_Target
            {
                float2 pos = float2(i.uv.xy / i.uv.w);

                if (pos.x < 0 || pos.x > 1 || pos.y < 0 || pos.y > 1)
				{
					return _Background;
				}
                
                float4 col = SAMPLE_TEXTURE2D_X(_ColorMap, sampler_ColorMap, pos);
                
                return col;
            }
            ENDHLSL
        }
    }
}
