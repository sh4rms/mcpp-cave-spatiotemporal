using System;
using UnityEngine;

[Obsolete("This class is deprecated. Remove script 'URPSettings' and add script 'MVR_URPSettings' instead.")]
public class URPSettings : MonoBehaviour
{
}
