#if UNITY_6000_0_OR_NEWER
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.Universal;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.Rendering.RenderGraphModule.Util;

internal class MVRProjectiveTransformPass : ScriptableRenderPass
{
    private class PassData
    {
        internal TextureHandle src;
        internal TextureHandle outputRenderTexture;
        internal Material material;
    }
    
    Material _material;

    public MVRProjectiveTransformPass(Material material)
    {
        _material = material;

        renderPassEvent = RenderPassEvent.AfterRenderingPostProcessing;
        requiresIntermediateTexture = true;
    }

    public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
    {
        UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();
        UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();

        // The following line ensures that the render pass doesn't blit
        // from the back buffer.
        if (resourceData.isActiveTargetBackBuffer)
        {
            Debug.LogError($"[MVR] Skipping MVRProjectiveTransform render pass: it requires an intermediate ColorTexture, we can't use the BackBuffer as a texture input.");
            return;
        }

        var script = cameraData.camera.GetComponent<MVRProjectiveTransform>();

        if (script == null)
            return;

        TextureHandle srcCamColor = resourceData.activeColorTexture;

        // This check is to avoid an error from the material preview in the scene
        if (!srcCamColor.IsValid())
            return;

        vrNode3D mvrCameraNode = MVRNodesMapper.Instance.GetNode(cameraData.camera.gameObject);

        var mvrCamera = MVR.DisplayMgr.GetCameraById(mvrCameraNode.GetId());

        var descriptor = cameraData.cameraTargetDescriptor;
        //descriptor.msaaSamples = 1;
        descriptor.depthBufferBits = (int)DepthBits.None;

        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        TextureHandle srcNonOverscanHandle = TextureHandle.nullHandle;

        uint vpWidth = mvrCamera.GetViewport().GetWidth();
        uint vpHeight = mvrCamera.GetViewport().GetHeight();

        if (overscan > 0)
        {
            descriptor.width = (int)vpWidth;
            descriptor.height = (int)vpHeight;

            string srcName = "_SourceNonOverscanRenderTexture_" + cameraData.camera.name;
            srcNonOverscanHandle = UniversalRenderer.CreateRenderGraphTexture(renderGraph, descriptor, srcName, false);

            // This check is to avoid an error from the material preview in the scene
            if (!srcNonOverscanHandle.IsValid())
                return;
        }

        string name = "_OutputRenderTexture_" + cameraData.camera.name;
        TextureHandle outputRenderTextureHandle = UniversalRenderer.CreateRenderGraphTexture(renderGraph, descriptor, name , false);

        if (script.UpdateValues())
            script.UpdateShader(_material);

        // This check is to avoid an error from the material preview in the scene
        if (!outputRenderTextureHandle.IsValid())
            return;

        // If needed, extract the non-overscanned portion of the source texture
        if (overscan > 0)
        {
            float cameraWidth = (float)srcCamColor.GetDescriptor(renderGraph).width;
            float cameraHeight = (float)srcCamColor.GetDescriptor(renderGraph).height;

            float wScale = vpWidth/cameraWidth;
            float hScale = vpHeight/cameraHeight;

            float wOffset = overscan / cameraWidth;
            float hOffset = overscan / cameraHeight;

            renderGraph.AddBlitPass(srcCamColor, srcNonOverscanHandle,
                                    new Vector2(wScale, hScale),
                                    new Vector2(wOffset, hOffset));
        }

        // Execute projective transform pass
        using (var builder = renderGraph.AddRasterRenderPass<PassData>("MVRProjectiveRenderTransformPass", out var passData))
        {
            if (overscan>0)
            {
                passData.src = srcNonOverscanHandle;
            }
            else
            {
                passData.src = srcCamColor;
            }
            
            passData.outputRenderTexture = outputRenderTextureHandle;
            passData.material = _material;

            builder.UseTexture(passData.src);
            builder.SetRenderAttachment(outputRenderTextureHandle, 0);
            builder.AllowPassCulling(false);
            builder.SetRenderFunc((PassData data, RasterGraphContext context) => ExecuteProjPass(data, context, 0));
        }

        if(overscan>0)
        {
            // put back the non-overscanned transformed texture at its place in the overscanned-size original texture
            float wScale = srcCamColor.GetDescriptor(renderGraph).width / (float)vpWidth;
            float hScale = srcCamColor.GetDescriptor(renderGraph).height / (float)vpHeight;

            float wOffset = -overscan / (float)vpWidth;
            float hOffset = -overscan / (float)vpHeight;

            renderGraph.AddBlitPass(outputRenderTextureHandle, srcCamColor,
                                    new Vector2(wScale, hScale), new Vector2(wOffset, hOffset));
        }
        else
        {
            // From CopyRenderFeature.cs
            if (RenderGraphUtils.CanAddCopyPassMSAA())
            {
                //Need to copy back otherwise the pass gets culled since the result of the previous copy is not read.
                renderGraph.AddCopyPass(outputRenderTextureHandle, srcCamColor, passName: "MVRBlit");
            }
            else
            {
                Debug.Log("Can't add the copy pass due to MSAA");
            }
        }
    }

    private static void ExecuteProjPass(PassData data, RasterGraphContext context, int pass)
    {
        data.material.SetTexture("_ColorMap", data.src);
        Blitter.BlitTexture(context.cmd, data.src, new Vector4(1,1, 0, 0), data.material, pass);
    }
}

#else
// 2022
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using MiddleVR;
using MiddleVR.Unity;

internal class MVRProjectiveTransformPass : ScriptableRenderPass
{
    ProfilingSampler _ProfilingSampler = new ProfilingSampler("MVRProjectiveTransform");

    private RTHandle _sourceNonOverscanRenderTexture;
    private RTHandle _outputRenderTexture;
    
    Material _material;
    public vrCamera _mvrCamera = null;

    public MVRProjectiveTransformPass(Material material)
    {
        _material = material;
        renderPassEvent = RenderPassEvent.AfterRenderingPostProcessing;
    }

    public void Setup(in RenderingData renderingData)
    {
        vrNode3D mvrCameraNode = MVRNodesMapper.Instance.GetNode(renderingData.cameraData.camera.gameObject);

        _mvrCamera = MVR.DisplayMgr.GetCameraById(mvrCameraNode.GetId());

        var descriptor = renderingData.cameraData.cameraTargetDescriptor;
        descriptor.depthBufferBits = (int)DepthBits.None;
        
        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        if( overscan>0 )
        {
            uint vpWidth = _mvrCamera.GetViewport().GetWidth();
            uint vpHeight = _mvrCamera.GetViewport().GetHeight();
            descriptor.width = (int)vpWidth;
            descriptor.height = (int)vpHeight;

            RenderingUtils.ReAllocateIfNeeded(ref _sourceNonOverscanRenderTexture, descriptor, name: "_sourceNonOverscan_" + renderingData.cameraData.camera.name);
        }

        RenderingUtils.ReAllocateIfNeeded(ref _outputRenderTexture, descriptor, name: "_OutputRenderTexture_" + renderingData.cameraData.camera.name);

    }

    public void Dispose()
    {
        _outputRenderTexture?.Release();
        _sourceNonOverscanRenderTexture?.Release();
    }

    public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
    {
        ConfigureTarget(_outputRenderTexture);
    }

    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        var cameraData = renderingData.cameraData;
        var camera = cameraData.camera;

        if (camera.cameraType != CameraType.Game)
            return;

        var script = renderingData.cameraData.camera.GetComponent<MVRProjectiveTransform>();

        if (_material == null || script == null)
            return;

        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        uint vpWidth = _mvrCamera.GetViewport().GetWidth();
        uint vpHeight = _mvrCamera.GetViewport().GetHeight();

        RTHandle cameraTargetHandle = renderingData.cameraData.renderer.cameraColorTargetHandle;

        CommandBuffer cmd = CommandBufferPool.Get();
        using (new ProfilingScope(cmd, _ProfilingSampler))
        {
            if (script.UpdateValues())
                script.UpdateShader(_material);

            if (overscan > 0)
            {
                var cameraTargetDescriptor = cameraData.cameraTargetDescriptor;

                // We need to get the non-overscanned texture here
                cmd.CopyTexture(cameraData.renderer.cameraColorTargetHandle,
                                0, 0,
                                (int)overscan, (int)overscan,
                                (int)vpWidth, (int)vpHeight, _sourceNonOverscanRenderTexture, 0, 0, 0, 0);

                _material.SetTexture("_ColorMap", _sourceNonOverscanRenderTexture);
            }
            else
            {
                _material.SetTexture("_ColorMap", cameraTargetHandle);
            }

            Blitter.BlitCameraTexture(cmd, cameraTargetHandle, _outputRenderTexture, _material, 0);

            if (overscan > 0)
            {
                float wScale = cameraData.cameraTargetDescriptor.width / (float)vpWidth;
                float hScale = cameraData.cameraTargetDescriptor.height / (float)vpHeight;

                float wOffset = -overscan / (float)vpWidth;
                float hOffset = -overscan / (float)vpHeight;

                // Copy the non-overscan image to the destination, which has an overscanned resolution
                Blitter.BlitCameraTexture(cmd, _outputRenderTexture, cameraTargetHandle, new Vector4(wScale, hScale, wOffset, hOffset));
            }
            else
            {
                Blitter.BlitCameraTexture(cmd, _outputRenderTexture, cameraTargetHandle);
            }
        }
        context.ExecuteCommandBuffer(cmd);
        cmd.Clear();

        CommandBufferPool.Release(cmd);
    }
}

#endif