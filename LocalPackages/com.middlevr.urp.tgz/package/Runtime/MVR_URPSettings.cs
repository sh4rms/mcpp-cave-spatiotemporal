﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.Linq;
#if UNITY_EDITOR
using UnityEditor;
#if UNITY_2023_1_OR_NEWER
using UnityEditor.Build;
#endif
#endif

namespace MiddleVR.Unity.URP
{
    [MVRDisable(ifNoMVR: true)]
    [ExecuteInEditMode]
    public class MVR_URPSettings : MonoBehaviour
    {
        public uint URPOverscan = 50;

        public bool DisableVignette = true;
        public bool DisableChromaticAberration = true;
        public bool DisableBloom = false;
        public bool DisableMotionBlur = false;
        public bool DisableLensDistortion = true;
        public bool DisableDepthOfField = false;

        public bool Verbose = true;

        private bool _projectiveTransformSetup = false;
        private bool _warpSetup = false;

        private void SetupURP()
        {
            // Volume
#if UNITY_2023_1_OR_NEWER
            foreach (var urpvolume in FindObjectsByType<Volume>(FindObjectsSortMode.None))
#else
            foreach (var urpvolume in FindObjectsOfType<Volume>())
#endif
            {
                var name = urpvolume.name;

                Vignette vignette;
                if (DisableVignette && urpvolume.profile.TryGet<Vignette>(out vignette))
                {
                    if (Verbose) MVRTools.Log(2, "[ ] MVR: Vignetting found on '" + name + "'. Disabling.");
                    vignette.active = false;
                }

                ChromaticAberration ab;
                if (DisableChromaticAberration && urpvolume.profile.TryGet<ChromaticAberration>(out ab))
                {
                    if (Verbose) MVRTools.Log(2, "[ ] MVR: Chromatic aberration found on '" + name + "'. Disabling.");
                    ab.active = false;
                }

                Bloom bloom;
                if (urpvolume.profile.TryGet<Bloom>(out bloom))
                {
                    if (DisableBloom)
                    {
                        if (Verbose) MVRTools.Log(2, "[ ] MVR: Bloom found on '" + name + "'. Disabling.");
                        bloom.active = false;
                    }
                    else
                    {
                        if (Verbose) MVRTools.Log(2, $"[ ] MVR: Bloom found on '{name}'. Requesting Overscan {URPOverscan}.");
                        MVRTools.GetMVRManager().advancedProperties.ForceCompositorHDRRender = true;
                        SetOverscan(URPOverscan);
                    }
                }

                DepthOfField dof;
                if (urpvolume.profile.TryGet<DepthOfField>(out dof))
                {
                    if (DisableDepthOfField)
                    {
                        if (Verbose) MVRTools.Log(2, "[ ] MVR: Depth Of Field found on '" + name + "'. Disabling.");
                        dof.active = false;
                    }
                    else
                    {
                        if (Verbose) MVRTools.Log(2, $"[ ] MVR: Depth Of Field found on '{name}'. Requesting Overscan {URPOverscan}.");
                        SetOverscan(URPOverscan);
                    }
                }

                LensDistortion ld;
                if (DisableLensDistortion && urpvolume.profile.TryGet<LensDistortion>(out ld))
                {
                    if (Verbose) MVRTools.Log(2, "[ ] MVR: Lens Distortion found on '" + name + "'. Disabling.");
                    ld.active = false;
                }

                MotionBlur mb;
                if (urpvolume.profile.TryGet<MotionBlur>(out mb))
                {
                    if (DisableMotionBlur)
                    {
                        if (Verbose) MVRTools.Log(2, $"[ ] MVR: Motion Blur found on '{name}'. Disabling.");
                    }
                    else
                    {
                        if (Verbose) MVRTools.Log(2, $"[ ] MVR: Motion Blur found on '{name}'. Requesting Overscan {URPOverscan}.");
                        SetOverscan(URPOverscan);
                    }
                }
            }
        }

        private void SetupURPComponents()
        {
            // Camera
#if UNITY_2023_1_OR_NEWER
            foreach (var cam in FindObjectsByType<Camera>(FindObjectsSortMode.None))
#else
            foreach (var cam in FindObjectsOfType<Camera>())
#endif
            {
                foreach (var component in cam.GetComponents<MonoBehaviour>())
                {
                    if (component != null && component.GetType().FullName == "UnityTemplateProjects.SimpleCameraController")
                    {
                        component.enabled = false;
                    }

                    if (component != null && component.GetType().FullName == "MVRProjectiveTransform")
                    {
                        SetupProjectiveTransformRenderFeature();
                    }

                    if (component != null && component.GetType().FullName == "MVRWarperMesh")
                    {
                        SetupWarpRenderFeature();
                    }
                }
            }
        }

        private void SetOverscan(uint iOverscan)
        {
            MVRTools.GetMVRManager().SetOverscanIfHigher(iOverscan);
        }

        public void SetupProjectiveTransformRenderFeature()
        {
            if (_projectiveTransformSetup)
                return;

            var pipeline = ((UniversalRenderPipelineAsset) GraphicsSettings.defaultRenderPipeline);
            FieldInfo propertyInfo = pipeline.GetType()
                .GetField("m_RendererDataList", BindingFlags.Instance | BindingFlags.NonPublic);
            var scriptableRendererData = ((ScriptableRendererData[]) propertyInfo?.GetValue(pipeline))?[0];

            scriptableRendererData.rendererFeatures.Add(ScriptableObject.CreateInstance<MVRProjectiveTransformPassFeature>());

            _projectiveTransformSetup = true;


        }
        
        public void SetupWarpRenderFeature()
        {
            if (_warpSetup)
                return;

            var pipeline = ((UniversalRenderPipelineAsset) GraphicsSettings.defaultRenderPipeline);
            FieldInfo propertyInfo = pipeline.GetType()
                .GetField("m_RendererDataList", BindingFlags.Instance | BindingFlags.NonPublic);
            var scriptableRendererData = ((ScriptableRendererData[]) propertyInfo?.GetValue(pipeline))?[0];
            scriptableRendererData.rendererFeatures.Add(ScriptableObject.CreateInstance<MVRWarpPassFeature>());

            _warpSetup = true;
        }

        public void SetupURPMaterials()
        {
#if UNITY_EDITOR
            GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();

            GameObject mvrWand = allObjects.FirstOrDefault(obj => obj.name == "MVRWand");

            if (mvrWand == null) return;

            Renderer wandCubeRenderer = mvrWand.transform.Find("MVRWandCube").GetComponent<Renderer>();
            Renderer wandRayRenderer = mvrWand.transform.Find("MVRWandRay/MVRRayMesh").GetComponent<Renderer>();

            Material cubeMat = (Material)AssetDatabase.LoadAssetAtPath("Packages/com.middlevr.urp/Runtime/Assets/Materials/WandCubeMaterial.mat", typeof(Material));

            wandCubeRenderer.material = cubeMat;
            wandRayRenderer.material = (Material)AssetDatabase.LoadAssetAtPath("Packages/com.middlevr.urp/Runtime/Assets/Materials/WandRayMaterial.mat", typeof(Material));
#endif
        }

        private void Awake()
        {
            if (!MVRTools.GetMVRManager())
            {
                return;
            }

#if UNITY_EDITOR
#if UNITY_2023_1_OR_NEWER
            var defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Standalone);
#else
            var defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Standalone);
#endif
            if (!defines.Contains("MVR_URP"))
            {
                SetupURPMaterials();
                if (Verbose) MVRTools.Log("[ ] MVR: Universal Rendering Pipeline detected.");

                defines += ";MVR_URP";
#if UNITY_2023_1_OR_NEWER
                PlayerSettings.SetScriptingDefineSymbols(NamedBuildTarget.Standalone, defines);
#else
                PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.Standalone, defines);
#endif
            }
#endif
            if (Application.isPlaying)
            {
                SetupURP();
            }
        }

        void Start()
        {
            if(Application.isPlaying)
            {
                SetupURPComponents();
            }
        }

        private void OnApplicationQuit()
        {
            var pipeline = ((UniversalRenderPipelineAsset) GraphicsSettings.defaultRenderPipeline);
            FieldInfo propertyInfo = pipeline.GetType()
                .GetField("m_RendererDataList", BindingFlags.Instance | BindingFlags.NonPublic);
            var scriptableRendererData = ((ScriptableRendererData[]) propertyInfo?.GetValue(pipeline))?[0];

            ScriptableRendererFeature mvrRF = null; 
            
            foreach (var rf in (scriptableRendererData.rendererFeatures))
            {
                if(rf != null)
                {
                    var name = rf.GetType().FullName;
                    if (name == "MVRProjectiveTransformPassFeature"
                        || name == "MVRWarpPass")
                    {
                        mvrRF = rf;
                    }
                }
            }
            
            scriptableRendererData.rendererFeatures.Remove(mvrRF);
        }
    }
}
