#if UNITY_6000_0_OR_NEWER
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.RenderGraphModule.Util;

internal class MVRWarpPass : ScriptableRenderPass
{
    private class PassData
    {
        internal TextureHandle src;
        internal TextureHandle outputRenderTexture;
        internal Material material;
        internal Matrix4x4 projMat;
        internal MVRWarperMesh script;
        internal vrViewport viewport;
    }
    
    Material _warpMaterial;
    public Camera _camera = null;

    private vrCamera _firstICVFXCam = null;


    public MVRWarpPass(Material material)
    {
        _warpMaterial = material;
        renderPassEvent = RenderPassEvent.AfterRenderingPostProcessing;
        requiresIntermediateTexture = true;
    }

    vrCamera GetFirstICVFXCamera()
    {
        foreach (var mvrCamera in MVR.DisplayMgr.Cameras)
        {
            if (mvrCamera.IsICVFX())
            {
                return mvrCamera;
            }
        }
        return null;
    }

    public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
    {
        UniversalResourceData resourceData = frameData.Get<UniversalResourceData>();
        UniversalCameraData cameraData = frameData.Get<UniversalCameraData>();

        // The following line ensures that the render pass doesn't blit
        // from the back buffer.
        if (resourceData.isActiveTargetBackBuffer)
        {
            Debug.LogError($"[MVR] Skipping MVRProjectiveTransform render pass: it requires an intermediate ColorTexture, we can't use the BackBuffer as a texture input.");
            return;
        }

        var script = cameraData.camera.GetComponent<MVRWarperMesh>();

        if (script == null)
                return;

        if (_firstICVFXCam == null) _firstICVFXCam = GetFirstICVFXCamera();

        TextureHandle srcCamColor = resourceData.activeColorTexture;

        // This check is to avoid an error from the material preview in the scene
        if (!srcCamColor.IsValid())
            return;

        var descriptor = cameraData.cameraTargetDescriptor;
        //descriptor.msaaSamples = 1;
        descriptor.depthBufferBits = (int)DepthBits.None;

        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        TextureHandle srcNonOverscanHandle = TextureHandle.nullHandle;

        vrNode3D mvrCameraNode = MVRNodesMapper.Instance.GetNode(cameraData.camera.gameObject);

        var mvrCamera = MVR.DisplayMgr.GetCameraById(mvrCameraNode.GetId());

        var mvrViewport = mvrCamera.GetViewport();
        uint vpWidth = mvrViewport.GetWidth();
        uint vpHeight = mvrViewport.GetHeight();

        if (overscan > 0)
        {
            descriptor.width = (int)vpWidth;
            descriptor.height = (int)vpHeight;
        }

        string name = "_OutputRenderTexture_" + cameraData.camera.name;
        TextureHandle outputRenderTextureHandle = UniversalRenderer.CreateRenderGraphTexture(renderGraph, descriptor, name, false);

        // This check is to avoid an error from the material preview in the scene
        if (!outputRenderTextureHandle.IsValid())
            return;

        // Warp
        using (var builder = renderGraph.AddRasterRenderPass<PassData>("MVRWarpPass", out var passData))
        {

            if (overscan > 0)
            {
                passData.src = srcCamColor;
                // Ignore overscan for warping only
                MVR.DisplayMgr.SetOverscan(0);
                script.GetMVRCamera().Update();
                passData.projMat = script.GetMVRCamera().GetProjectionMatrix().RawToUnity();
                MVR.DisplayMgr.SetOverscan(overscan);

                // extract the non-overscanned portion of the source texture
                // Pass the crop rectangle to the shader
                float fullWidth = (float)srcCamColor.GetDescriptor(renderGraph).width;
                float fullHeight = (float)srcCamColor.GetDescriptor(renderGraph).height;

                float left = overscan / fullWidth;
                float top = overscan / fullHeight;
                float right = (overscan + vpWidth) / fullWidth;
                float bottom = (overscan + vpHeight) / fullHeight;

                // Pass the crop rectangle as normalized UVs
                // So that we get the non-overscanned source image to warp
                _warpMaterial.SetVector("_CropRect", new Vector4(left, top, right, bottom));
            }
            else
            {
                passData.src = srcCamColor;
                passData.projMat = script.GetViewCamera().projectionMatrix;
            }

            passData.outputRenderTexture = outputRenderTextureHandle;
            passData.material = _warpMaterial;
            passData.script = script;
            passData.viewport = mvrViewport;

            builder.UseTexture(passData.src);
            builder.SetRenderAttachment(outputRenderTextureHandle, 0);
            builder.AllowPassCulling(false);
            builder.SetRenderFunc((PassData data, RasterGraphContext context) => ExecuteWarpPass(data, context, 0));
        }


        // Final blit

        if (overscan > 0)
        {
            // put back the non-overscanned transformed texture at its place in the overscanned-size original texture
            float wScale = srcCamColor.GetDescriptor(renderGraph).width / (float)vpWidth;
            float hScale = srcCamColor.GetDescriptor(renderGraph).height / (float)vpHeight;

            float wOffset = -overscan / (float)vpWidth;
            float hOffset = -overscan / (float)vpHeight;

            renderGraph.AddBlitPass(outputRenderTextureHandle, srcCamColor,
                                    new Vector2(wScale, hScale), new Vector2(wOffset, hOffset),
                                    0, 0, -1, 0, 0, 1,
                                    RenderGraphUtils.BlitFilterMode.ClampBilinear,
                                    "MVRWarpOverscan2");
        }
        else
        {
            // From CopyRenderFeature.cs
            if (RenderGraphUtils.CanAddCopyPassMSAA())
            {
                //Need to copy back otherwise the pass gets culled since the result of the previous copy is not read.
                renderGraph.AddCopyPass(outputRenderTextureHandle, srcCamColor, passName: "MVRWarpFinalBlit");
            }
            else
            {
                Debug.Log("Can't add the copy pass due to MSAA");
            }
        }
    }

    private static void ExecuteWarpPass(PassData data, RasterGraphContext context, int pass)
    {
        data.material.SetTexture("_ColorMap", data.src);

        data.material.SetMatrix("_LocalToWorldMatrix", data.script.GetWarperMeshGO().transform.localToWorldMatrix);
        data.material.SetMatrix("_WorldToCameraMatrix", data.script.GetViewCamera().worldToCameraMatrix);
        data.material.SetMatrix("_CustomProjMatrix", data.projMat);

        var scale = RTHandles.rtHandleProperties.rtHandleScale;
        data.material.SetVector("_Scale", scale);

        var mpcdi = data.script.GetWarperMPCDI();

        if (mpcdi != null)
        {
            data.material.SetTexture("_BlendTex", data.script.GetBlendingImage());
            data.material.SetTexture("_BlackTex", data.script.GetBlackImage());
            data.material.SetFloat("_Gamma", (float)mpcdi.GetGamma());
        }
        else
        {
            data.material.SetFloat("_Gamma", 1.0f);
        }

        uint vpWidth = data.viewport.GetWidth();
        uint vpHeight = data.viewport.GetHeight();

        context.cmd.SetViewport(new Rect(0, 0, vpWidth, vpHeight));
        context.cmd.ClearRenderTarget(true, true, Color.black);

        context.cmd.DrawMesh(data.script.GetGridMesh(), Matrix4x4.identity, data.material);
    }
}
#else
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using MiddleVR;
using MiddleVR.Unity;

internal class MVRWarpPass : ScriptableRenderPass
{
    ProfilingSampler _ProfilingSampler = new ProfilingSampler("MVRWarp");

    private RTHandle _outputRenderTexture;

    Material _warpMaterial;
    public Camera _camera = null;

    private vrCamera _firstICVFXCam = null;


    public MVRWarpPass(Material material)
    {
        _warpMaterial = material;
        renderPassEvent = RenderPassEvent.AfterRenderingPostProcessing;
    }

    vrCamera GetFirstICVFXCamera()
    {
        foreach (var mvrCamera in MVR.DisplayMgr.Cameras)
        {
            if (mvrCamera.IsICVFX())
            {
                return mvrCamera;
            }
        }
        return null;
    }

    public void Setup(in RenderingData renderingData)
    {
        var script = renderingData.cameraData.camera.GetComponent<MVRWarperMesh>();

        if (_firstICVFXCam == null) _firstICVFXCam = GetFirstICVFXCamera();


        var descriptor = renderingData.cameraData.cameraTargetDescriptor;
        descriptor.depthBufferBits = (int)DepthBits.None;

        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        if (overscan > 0)
        {
            uint vpWidth = script.GetMVRCamera().GetViewport().GetWidth();
            uint vpHeight = script.GetMVRCamera().GetViewport().GetHeight();
            descriptor.width = (int)vpWidth;
            descriptor.height = (int)vpHeight;
        }

        RenderingUtils.ReAllocateIfNeeded(ref _outputRenderTexture, descriptor, name: "_OutputRenderTexture_" + renderingData.cameraData.camera.name);

    }

    public void Dispose()
    {
        _outputRenderTexture?.Release();
    }

    public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
    {
        ConfigureTarget(_outputRenderTexture);
    }

    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        var cameraData = renderingData.cameraData;
        var camera = cameraData.camera;

        if (camera.cameraType != CameraType.Game)
            return;

        if (_warpMaterial == null)
            return;

        uint overscan = (uint)MVR.DisplayMgr.GetOverscan();

        var script = renderingData.cameraData.camera.GetComponent<MVRWarperMesh>();

        uint vpWidth = script.GetMVRCamera().GetViewport().GetWidth();
        uint vpHeight = script.GetMVRCamera().GetViewport().GetHeight();

        CommandBuffer cmd = CommandBufferPool.Get();
        using (new ProfilingScope(cmd, _ProfilingSampler))
        {
            Matrix4x4 projMat = script.GetViewCamera().projectionMatrix;

            if (overscan > 0)
            {
                var cameraTargetDescriptor = cameraData.cameraTargetDescriptor;

                // Ignore overscan for warping only
                MVR.DisplayMgr.SetOverscan(0);
                script.GetMVRCamera().Update();
                projMat = script.GetMVRCamera().GetProjectionMatrix().RawToUnity();
                MVR.DisplayMgr.SetOverscan(overscan);

                // Pass the crop rectangle to the shader
                float fullWidth = cameraData.cameraTargetDescriptor.width;
                float fullHeight = cameraData.cameraTargetDescriptor.height;

                float left = overscan / fullWidth;
                float top = overscan / fullHeight;
                float right = (overscan + vpWidth) / fullWidth;
                float bottom = (overscan + vpHeight) / fullHeight;

                // Pass the crop rectangle as normalized UVs
                // So that we get the non-overscanned source image to warp
                _warpMaterial.SetVector("_CropRect", new Vector4(left, top, right, bottom));
            }

            _warpMaterial.SetTexture("_ColorMap", cameraData.renderer.cameraColorTargetHandle);

            _warpMaterial.SetMatrix("_LocalToWorldMatrix", script.GetWarperMeshGO().transform.localToWorldMatrix);
            _warpMaterial.SetMatrix("_WorldToCameraMatrix", script.GetViewCamera().worldToCameraMatrix);
            _warpMaterial.SetMatrix("_CustomProjMatrix", projMat);

            var scale = RTHandles.rtHandleProperties.rtHandleScale;
            _warpMaterial.SetVector("_Scale", scale);

            var mpcdi = script.GetWarperMPCDI();

            if (mpcdi != null)
            {
                _warpMaterial.SetTexture("_BlendTex", script.GetBlendingImage());
                _warpMaterial.SetTexture("_BlackTex", script.GetBlackImage());
                _warpMaterial.SetFloat("_Gamma", (float)mpcdi.GetGamma());
            }
            else
            {
                _warpMaterial.SetFloat("_Gamma", 1.0f);
            }

            // SetRenderTarget is done via ConfigureTarget above
            //CoreUtils.SetRenderTarget(cmd, _outputRenderTexture, ClearFlag.None);
            cmd.SetViewport(new Rect(0, 0, vpWidth, vpHeight));
            CoreUtils.ClearRenderTarget(cmd, ClearFlag.Color, Color.black);

            cmd.DrawMesh(script.GetGridMesh(), Matrix4x4.identity, _warpMaterial);

            if (overscan > 0)
            {
                float wScale = cameraData.cameraTargetDescriptor.width / (float)vpWidth;
                float hScale = cameraData.cameraTargetDescriptor.height / (float)vpHeight;

                float wOffset = -overscan / (float)vpWidth;
                float hOffset = -overscan / (float)vpHeight;

                // Copy the non-overscan image to the destination, which has an overscanned resolution
                Blitter.BlitCameraTexture(cmd, _outputRenderTexture, cameraData.renderer.cameraColorTargetHandle, new Vector4(wScale, hScale, wOffset, hOffset));
            }
            else
            {
                Blitter.BlitCameraTexture(cmd,_outputRenderTexture, cameraData.renderer.cameraColorTargetHandle);
            }
        }
        context.ExecuteCommandBuffer(cmd);
        cmd.Clear();

        CommandBufferPool.Release(cmd);
    }
}
#endif