#if UNITY_6000_0_OR_NEWER

using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

internal class MVRProjectiveTransformPassFeature : ScriptableRendererFeature
{
    Material m_Material;

    MVRProjectiveTransformPass m_RenderPass = null;

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (renderingData.cameraData.cameraType == CameraType.Game)
        {
            renderer.EnqueuePass(m_RenderPass);
        }
    }

    public override void Create()
    {
        m_Material = CoreUtils.CreateEngineMaterial(Shader.Find("MVR/ProjectiveTransform_URP"));
        m_RenderPass = new MVRProjectiveTransformPass(m_Material);
    }

    protected override void Dispose(bool disposing)
    {
#if UNITY_EDITOR
        if (EditorApplication.isPlaying)
        {
            Destroy(m_Material);
        }
        else
        {
            DestroyImmediate(m_Material);
        }
#else
        Destroy(m_Material);
#endif
    }
}

#else
// 2022
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

internal class MVRProjectiveTransformPassFeature : ScriptableRendererFeature
{
    Material m_Material;

    MVRProjectiveTransformPass m_RenderPass = null;

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (renderingData.cameraData.cameraType == CameraType.Game)
        {
            m_RenderPass.ConfigureInput(ScriptableRenderPassInput.Color);
            m_RenderPass.Setup(renderingData);
            renderer.EnqueuePass(m_RenderPass);
        }
    }

    public override void SetupRenderPasses(ScriptableRenderer renderer, in RenderingData renderingData)
    {
        if(renderingData.cameraData.cameraType == CameraType.Game)
        {
            m_RenderPass.ConfigureInput(ScriptableRenderPassInput.Color);
        }
    }

    public override void Create()
    {
        m_Material = CoreUtils.CreateEngineMaterial(Shader.Find("MVR/ProjectiveTransform_URP"));
        m_RenderPass = new MVRProjectiveTransformPass(m_Material);
    }

    protected override void Dispose(bool disposing)
    {
        m_RenderPass.Dispose();
        CoreUtils.Destroy(m_Material);
    }
}

#endif