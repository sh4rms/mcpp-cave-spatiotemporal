﻿Shader "MVR/RenderFromUV2"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag


            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv2_MainTex : TEXCOORD1;
            };

            struct v2f
            {
                float2 uv2_MainTex : TEXCOORD0; // ?? 2 or 0
                float4 vertex : SV_POSITION;
            };

            sampler2D _MainTex;
            float4 _MainTex_ST;

            v2f vert (appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
				o.uv2_MainTex = TRANSFORM_TEX(v.uv2_MainTex.xy, _MainTex);
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
			{
				// sample the texture
				//fixed4 col =  tex2D(_MainTex, i.uv);
				
                // debug display uv2
				fixed4 col;
				col.x = i.uv2_MainTex.x;
				col.y = i.uv2_MainTex.y;
				col.z = 0.0f;
				col.a = 1.0f;

                return col;
            }
            ENDCG
        }
    }
}
