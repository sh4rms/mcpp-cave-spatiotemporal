Shader "MVR/ProjectiveTransform"
{
	Properties {
		_MainTex("Base (RGB)", 2D) = "white" {} _Background("Background", Color) = (0, 0, 0, 1)}

	CGINCLUDE uniform float4 _MainTex_TexelSize;
	ENDCG

	SubShader
	{
		// No culling or depth
		Cull Off ZWrite Off ZTest Always

			Pass
		{
			CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#pragma fragmentoption ARB_precision_hint_fastest

#include "UnityCG.cginc"

			uniform sampler2D _MainTex;
			uniform fixed4 _Background;
			uniform float4x4 _Transform;

			struct v2f
			{
				float4 pos : SV_POSITION;
				float4 uv : TEXCOORD0;
			};

			v2f vert(appdata_img v)
			{
				v2f o;
				o.pos = UnityObjectToClipPos(v.vertex);
				float2 uv = v.texcoord.xy;
#if UNITY_UV_STARTS_AT_TOP
				// Rendering upside-down - flip UV y-coordinate prior to transformation
				if (_MainTex_TexelSize.y < 0)
					uv.y = 1 - uv.y;
#endif
				o.uv = mul(_Transform, float4(uv.xy, 0, 1));
				return o;
			}

			fixed4 frag(v2f i) : SV_Target
			{
				float2 pos = float2(i.uv.xy / i.uv.w);
// Rendering upside-down - flip UV y-coordinate back
#if UNITY_UV_STARTS_AT_TOP
				if (_MainTex_TexelSize.y < 0)
					pos.y = 1 - pos.y;
#endif
				if (pos.x < 0 || pos.x > 1 || pos.y < 0 || pos.y > 1)
				{
					return _Background;
				}
				return tex2D(_MainTex, pos);
			}
			ENDCG
		}
	}

	Fallback off
}
