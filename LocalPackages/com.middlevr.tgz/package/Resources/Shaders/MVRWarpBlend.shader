﻿Shader "MVR/WarpBlend"
{
    Properties
	{
		_MainTex("Texture", 2D) = "white" { }
        _BlendTex("Texture", 2D) = "white" { }
		_BlackTex("Texture", 2D) = "black" { }
    }
    SubShader
    {
		Tags {
			"RenderType" = "Opaque"
			"Queue" = "Overlay+1"
        }
        ZTest Off
        Cull Off
        LOD 100

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag

            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float3 uv : TEXCOORD0;
				float2 uv1 : TEXCOORD1;
            };

            struct v2f
            {
				float4 vertex : SV_POSITION;
                float4 uv : TEXCOORD0;
				float2 uv1 : TEXCOORD1;
            };

            sampler2D _MainTex;
			sampler2D _BlendTex;
			sampler2D _BlackTex;
            float _Gamma;

            float4x4 _LocalToWorldMatrix;
            float4x4 _WorldToCameraMatrix;
			float4x4 _ProjMatrix;

            float4 _MainTex_ST;
			float4 _BackgroundTex_ST;

            // Derived from camera.WorldToViewportPoint
            // https://forum.unity.com/threads/camera-worldtoviewportpoint-math.644383/
            float2 Warp(float4 localVertex)
            {
                float4 worldPos = mul(_LocalToWorldMatrix, localVertex);
                float4 viewPos = mul(_WorldToCameraMatrix, worldPos);
                float4 projPos = mul(_ProjMatrix, viewPos);
                float2 ndcPos = projPos.xy / projPos.w;
                float2 viewportPos = ndcPos.xy * 0.5f + 0.5f;

                return viewportPos;
            }
            
            v2f vert (appdata v)
            {
                v2f o;

                o.vertex = UnityObjectToClipPos(v.vertex);
				o.uv = float4(v.uv, 1.0f);
				o.uv1 = v.uv1;

                return o;
            }

            fixed4 frag(v2f i) : SV_Target
			{
				float2 vpPos = Warp(i.uv);
				float4 col = tex2D(_MainTex, vpPos);

                float3 col3 = col.rgb;

                float3 blend = tex2D(_BlendTex, i.uv1);
                float3 gamma = float3(_Gamma, _Gamma, _Gamma);
                float  gammaBlack = pow(tex2D(_BlackTex, i.uv1), gamma);
                float3 gammaColor = pow(col3 * blend, gamma);
                float3 gammaColorCorrection = ( gammaColor * (1.0 - gammaBlack) + gammaBlack);

                float3 color = pow(gammaColorCorrection,float3(1.0 / _Gamma, 1.0 / _Gamma, 1.0 / _Gamma));

                return float4(color,1.0);
            }
            ENDCG
        }
    }
}
