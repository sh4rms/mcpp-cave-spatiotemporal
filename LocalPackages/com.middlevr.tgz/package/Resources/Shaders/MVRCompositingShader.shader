﻿Shader "MVR/Compositing"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
		_BackgroundTex("Texture", 2D) = "white" { }
    }
    SubShader
    {
		Tags {
			"RenderType" = "Opaque"
			"Queue" = "Overlay+1"
        }

        LOD 100
        ZTest Always
        ZWrite Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag

            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float2 uv : TEXCOORD0;
                float4 vertex : SV_POSITION;
            };

            sampler2D _MainTex;
            float4 _MainTex_ST;

            sampler2D _BackgroundTex;
			float4 _BackgroundTex_ST;

            v2f vert (appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                // sample the texture
                fixed4 col = tex2D(_MainTex, i.uv);

                fixed4 backgroundCol = tex2D(_BackgroundTex, i.uv);
				if (col.a <= 0)
				{
					col = backgroundCol;
				}

                return col;
            }
            ENDCG
        }
    }
}
