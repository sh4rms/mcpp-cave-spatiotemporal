using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.SceneManagement;
using static UnityEngine.UIElements.UxmlAttributeDescription;
using System.Linq;

public class TestRendering
{
    // This setup runs before each test.
    [UnitySetUp]
    public IEnumerator Setup()
    {
        Debug.Log("[T] Setup test");
        Debug.Log("[T] Loading scene");

        //EditorSceneManager.OpenScene("Assets/Scenes/MeshWarping.unity");
        SceneManager.LoadScene("UnitTests", LoadSceneMode.Single);
        Debug.Log("[T] Scene loaded requested.");
        yield return new WaitUntil(() => SceneManager.GetActiveScene().name == "UnitTests");
        Debug.Log("[T] Scene loaded.");

        Debug.Log("[T] Setting up MVR Manager");

        // We need to disable the MVRManager to be able to force the config file
        // Before Awake() is called

        // Use Resources.FindObjectsOfTypeAll to locate the inactive GameObject.
        // Note: This method returns all GameObjects (active and inactive) in the scene.
        var allGameObjects = Resources.FindObjectsOfTypeAll<GameObject>();
        var go = allGameObjects.FirstOrDefault(obj => obj.name == "MVRManager");
        Assert.IsNotNull(go, "MVRManager GameObject was not found in the scene.");

        // Ensure the GameObject is inactive so Awake hasn't been called yet.
        Assert.IsFalse(go.activeSelf, "MVRManager should be inactive to delay Awake.");

        var mvrMgr = go.GetComponent<MVRManagerScript>();

        if (mvrMgr != null)
        {
            mvrMgr.EditorConfigFile = "../../../Tests/Common/Configs/Default.vrx";
            mvrMgr.PreviewWindow = true;
        }

        // Now activate the GameObject to trigger Awake.
        go.SetActive(true);

        // Reset MVRManager cache
        MVRTools.GetMVRManager(true);

        Debug.Log("[T] Starting frame");

        // Wait one frame to allow Awake and Start to be executed
        yield return null;
    }

    // This teardown runs after each test.
    [UnityTearDown]
    public IEnumerator TearDown()
    {
        yield return null;
    }

    [Test]
    public void TestRenderingSimplePasses()
    {
        var scene = SceneManager.GetActiveScene().name;
        Debug.Log($"[T] Scene: {scene}");

        Assert.IsTrue(SceneManager.GetActiveScene().name == "UnitTests");

        var mvrMgr = MVRTools.GetMVRManager();

        if (mvrMgr != null)
        {
            Assert.IsTrue(mvrMgr.EditorConfigFile == "../../Assets/Tests/Config/Default.vrx");
            Assert.IsTrue(mvrMgr.PreviewWindow == true);
            Assert.IsTrue(mvrMgr.IsInit());
        }
        else
        {
            Assert.Fail("[T] [X] No MVRManager ?!");
        }
    }

    // A UnityTest behaves like a coroutine in Play Mode. In Edit Mode you can use
    // `yield return null;` to skip a frame.
    /*
    [UnityTest]
    public IEnumerator TestRenderingWithEnumeratorPasses()
    {
        // Use the Assert class to test conditions.
        // Use yield to skip a frame.
        yield return null;

        
    }*/
}
