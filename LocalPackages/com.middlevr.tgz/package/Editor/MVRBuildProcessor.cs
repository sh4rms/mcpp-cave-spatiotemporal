﻿/* MVRBuildProcessor
 * MiddleVR
 * (c) MiddleVR
 */

//#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.Build;
using UnityEditor.Callbacks;
using UnityEngine;

namespace MiddleVR.Unity.Editor
{
    public class BuildPreprocessor : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public bool IsIl2CPP(BuildReport report)
        {
#if UNITY_6000_0_OR_NEWER

            BuildTarget buildTarget = EditorUserBuildSettings.activeBuildTarget;
            BuildTargetGroup targetGroup = BuildPipeline.GetBuildTargetGroup(buildTarget);
            var namedBuildTarget = UnityEditor.Build.NamedBuildTarget.FromBuildTargetGroup(targetGroup);

            var scriptingBackend = PlayerSettings.GetScriptingBackend(namedBuildTarget);

            return (namedBuildTarget == NamedBuildTarget.Standalone
                    && scriptingBackend == ScriptingImplementation.IL2CPP);
#else
            var buildTargetGroup = BuildPipeline.GetBuildTargetGroup(report.summary.platform);
            var scriptingBackend = PlayerSettings.GetScriptingBackend(buildTargetGroup);

            return( report.summary.platform == BuildTarget.StandaloneWindows64
                && scriptingBackend == ScriptingImplementation.IL2CPP );
#endif
        }

        public void OnPreprocessBuild(BuildReport report)
        {

            if (IsIl2CPP(report)
                && MVRTools.GetMVRManager(true))
            {
                bool result = EditorUtility.DisplayDialog("MiddleVR error", "MiddleVR does not support IL2CPP. Disable/remove the MVRManager or set 'Project Settings > Player > Scripting Backend > Mono'", "Build anyway", "Cancel build");

                if (!result)
                {
                    throw new BuildFailedException("Build was canceled by the user.");
                }
            }
        }
    }

    public static class PostProcessBuild
    {
        [PostProcessBuild(1)]
        public static void OnPostProcessBuild(BuildTarget target, string pathToBuiltProject)
        {
            if (target == BuildTarget.StandaloneWindows64)
            {
                string playerPath = Path.GetFullPath(pathToBuiltProject);
                string playerPlugins = GetPluginsOutputFolder(target, playerPath);

                CopyExeAsset("MiddleVR_UnityPlayer.exe", target, playerPath);
                CopyExeAsset("MiddleVR_Compositor.exe", target, Path.Combine(playerPlugins, "MiddleVR_Compositor.exe"));
            }
        }

        private static string GetPluginsOutputFolder(BuildTarget target, string playerPath)
        {
            string playerPlugins = Path.Combine(
                Path.GetDirectoryName(playerPath),
                Path.GetFileNameWithoutExtension(playerPath) + "_Data",
                "Plugins");

            return Path.Combine(playerPlugins, GetPlayerArchFolderName(target));
        }

        private static void CopyExeAsset(string assetFileName, BuildTarget target, string destination)
        {
            string mvrUnityPlayerPath = FindExeAsset(assetFileName, GetProjectArchFolderName(target));
            if (mvrUnityPlayerPath == null)
            {
                throw new FileNotFoundException($"Could not find {assetFileName} for BuildTarget '{target}'!");
            }

            try
            {
                File.Copy(
                    mvrUnityPlayerPath,
                    destination,
                    overwrite: true);
            }
            catch (IOException iox)
            {
                throw new IOException($"[X] MVR Build: Could not copy '{assetFileName}' file to '{destination}': {iox.Message}!", iox);
            }

            Debug.Log($"[+] MVR Build: Copied '{assetFileName}' file to '{destination}'.");
        }

        private static string FindExeAsset(string assetFileName, string subfolderName)
        {
            foreach (string guid in AssetDatabase.FindAssets(Path.GetFileNameWithoutExtension(assetFileName)))
            {
                string foundAssetPath = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(Application.dataPath), AssetDatabase.GUIDToAssetPath(guid)));
                string fountAssetFileName = Path.GetFileName(foundAssetPath);
                string parentDirectoryName = Path.GetFileName(Path.GetDirectoryName(foundAssetPath));

                if (fountAssetFileName.Equals(assetFileName, StringComparison.OrdinalIgnoreCase) &&
                    parentDirectoryName.Equals(subfolderName, StringComparison.OrdinalIgnoreCase))
                {
                    return foundAssetPath;
                }
            }

            return null;
        }


        private static string GetProjectArchFolderName(BuildTarget target)
        {
            switch (target)
            {
                case BuildTarget.StandaloneWindows64: return "x64";
                default: throw new InvalidOperationException($"MiddleVR Player Build PostProcessing: Unknown BuildTarget '{target}'!");
            };
        }

        private static string GetPlayerArchFolderName(BuildTarget target)
        {
            switch (target)
            {
                case BuildTarget.StandaloneWindows64: return "x86_64";
                default: throw new InvalidOperationException($"MiddleVR Player Build PostProcessing: Unknown BuildTarget '{target}'!");
            };
        }
    }
}
//#endif
