﻿/* MVRWand
 * MiddleVR
 * (c) MiddleVR
 */

using System;
using System.Text.RegularExpressions;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine;
using UnityEngine.Events;

[AddComponentMenu("")]
public class MVRWand : MonoBehaviour
{
    public float DefaultRayLength = 10;
    public Color DefaultRayColor = Color.white;

    [System.Serializable]
    public class MVRWandButtonEvent : UnityEvent<int, bool> { }

    [System.Serializable]
    public class MVRWandTouchEvent : UnityEvent<bool> { }

    private vrWand _wandDevice = null;
    private GameObject _wandCube = null;
    private GameObject _wandRay = null;
    private Renderer _wandRayRenderer = null;
    private float _rayLength = 0;
    private MVRSelectionManager _selectionMgr = null;

    private int _userIndex = -1;

    #region MonoBehaviour
    private void Start()
    {
        MultiUserSetup();

        _selectionMgr = this.GetComponent<MVRSelectionManager>();
        if (_selectionMgr == null)
        {
            MVRTools.Log(0, "[X] VRWand: impossible to retrieve VRSelectionManager.");
            enabled = false;
            return;
        }

        FindWandGeometry();

        SetRayLength(DefaultRayLength);
    }

    private void Update()
    {
        // If wand was not already set by SetUserIndex
        if(_wandDevice == null)
        {
            _wandDevice = MVR.DeviceMgr.GetWand("Wand0");
            if (_wandDevice == null)
            {
                MVRTools.Log(0, "[X] VRWand: impossible to retrieve vrWand device.");
            }
        }

        MVRSelection selection = _selectionMgr.GetSelection();

        // Send action if selection not null
        if (selection != null && selection.SelectedObject != null && MVR.DeviceMgr.GetWandButtons() != null )
        {
            for (int i = 0; i < MVR.DeviceMgr.GetWandButtons().GetButtonsNb(); i++)
            {
                if (MVR.DeviceMgr.IsWandButtonToggled((uint)i))
                {
                    selection.SelectedObject.GetComponent<MVRActor>().MVRWandButton.Invoke(i, true);
                    selection.SelectedObject.SendMessage("OnMVRWandButtonPressed", selection, SendMessageOptions.DontRequireReceiver);
                }
                if (MVR.DeviceMgr.IsWandButtonToggled((uint)i, false))
                {
                    selection.SelectedObject.GetComponent<MVRActor>().MVRWandButton.Invoke(i, false);
                    selection.SelectedObject.SendMessage("OnMVRWandButtonReleased", selection, SendMessageOptions.DontRequireReceiver);
                }
            }
        }
    }
    #endregion

    private void FindWandGeometry()
    {
        _wandCube = transform.Find("MVRWandCube").gameObject;
        _wandRay = transform.Find("MVRWandRay").gameObject;
        _wandRayRenderer = transform.Find("MVRWandRay/MVRRayMesh").GetComponent<Renderer>();
    }

    public void Show(bool iValue)
    {
        if (_wandRay == null || _wandRayRenderer == null || _wandCube == null)
        {
            FindWandGeometry();
        }

        if (_wandRayRenderer != null && _wandCube != null)
        {
            _wandRayRenderer.enabled = iValue;
            _wandCube.GetComponent<Renderer>().enabled = iValue;
        }
    }

    public void ShowRay(bool iValue)
    {
        _wandRayRenderer.enabled = iValue;
    }

    public bool IsRayVisible()
    {
        return _wandRayRenderer.enabled;
    }

    public MVRSelection GetSelection()
    {
        // Find Selection Mgr
        MVRSelectionManager selectionManager = this.GetComponent<MVRSelectionManager>();

        // Return selection
        return selectionManager.GetSelection();
    }

    public float GetDefaultRayLength()
    {
        return DefaultRayLength;
    }

    private float GetRayLength()
    {
        return _rayLength;
    }

    public void SetRayLength(float iLength)
    {
        _rayLength = iLength;
        _wandRay.transform.localScale = new Vector3(1.0f, 1.0f, _rayLength);
    }

    public void SetRayColor(Color iColor)
    {
        _wandRayRenderer.material.SetColor("_EmissionColor", iColor);
    }

    public float GetVerticalAxisValue()
    {
        return _wandDevice.GetVerticalAxisValue();
    }

    public float GetHorizontalAxisValue()
    {
        return _wandDevice.GetHorizontalAxisValue();
    }

    public bool IsButtonPressed(uint iButton)
    {
        return _wandDevice.IsButtonPressed(iButton);
    }

    public bool IsButtonToggled(uint iButton)
    {
        return _wandDevice.IsButtonToggled(iButton, true);
    }

    public bool IsButtonToggled(uint iButton, bool iPressed)
    {
        return _wandDevice.IsButtonToggled(iButton, iPressed);
    }

    public int GetUserIndex()
    {
        return _userIndex;
    }

    private int GetUsersNb()
    {
        int usersNb = 0;

        foreach(vrNode3D node in MVR.DisplayMgr.Nodes)
        {
            string name = node.GetName();

            Regex rx = new Regex(@"^User\d$");
            if(rx.IsMatch(name))
            {
                usersNb++;
            }
        }

        return usersNb;
    }

    private GameObject GetUser(int iIndex)
    {
        foreach (vrNode3D node in MVR.DisplayMgr.Nodes)
        {
            string name = node.GetName();

            Regex rx = new Regex(@"^User\d$");
            if (rx.IsMatch(name))
            {
                int index = -1;

                if (Int32.TryParse(name.Substring(name.Length - 1), out index))
                {
                    if (index == iIndex)
                    {
                        return(MVRNodesMapper.Instance.GetNode(node));
                    }
                }
            }
        }

        return null;
    }

    private void MultiUserSetup()
    {
        // We are a clone who has just been instantiated by this very function, ignore
        if (gameObject.name.Contains("Clone") || gameObject.name.Contains("User"))
        {
            return;
        }

        // Look for Users
        int nb = GetUsersNb();

        if(nb > 0)
        {
            MVRTools.Log("[+] " + nb + " users have been found in the configuration. Setting up multi-user interactions.");

            for (int i = 0; i < nb; i++)
            {
                GameObject user = GetUser(i);

                if(user == null)
                {
                    MVRTools.Log("[X] Couldn't find node 'User" + i + "'");
                    continue;
                }

                // Navigation need to be able to manually udpate the user's transform
                MVRNodesMapper.Instance.SetManualUpdate(user);

                // Duplicate and attach to each user's hand
                GameObject handNode = GameObject.Find(user.name + ".HandNode");

                if (handNode == null)
                {
                    MVRTools.Log("[X] Couldn't find node 'User" + i.ToString() + ".HandNode'");
                    continue;
                }

                GameObject newWand = (GameObject)GameObject.Instantiate(gameObject, handNode.transform, false);
                newWand.GetComponent<MVRAttachToNode>().enabled = false;
                newWand.GetComponent<MVRWand>().SetUserIndex(i);
            }

            // Disable main MVRWand
            gameObject.SetActive(false);
        }
    }

    public void SetUserIndex(int iIndex)
    {
        _userIndex = iIndex;
        GameObject user = GetUser(_userIndex);

        string wandName = "Wand" + _userIndex.ToString();

        _wandDevice = MVR.DeviceMgr.GetWand(wandName);

        if (_wandDevice == null)
        {
            MVRTools.Log(0, "[X] VRWand: impossible to find vrWand '" + wandName + "'");
        }

        gameObject.name = user.name + ".MVRWand";
    }
}
