/* MVRTools
 * MiddleVR
 * (c) MiddleVR
 */

using System;
using System.IO;
using System.Reflection;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace MiddleVR.Unity
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    public sealed class MVRDisableAttribute : Attribute
    {
        public bool IfServer { get; set; }
        public bool IfClient { get; set; }
        public bool IfCluster { get; set; }
        public bool IfNoCluster { get; set; }
        public bool IfMVR { get; set; }
        public bool IfNoMVR { get; set; }

        public MVRDisableAttribute(bool ifServer = false,
                                   bool ifClient = false,
                                   bool ifCluster = false,
                                   bool ifNoCluster = false,
                                   bool ifMVR = false,
                                   bool ifNoMVR = false)
        {
            IfServer = ifServer;
            IfClient = ifClient;
            IfCluster = ifCluster;
            IfNoCluster = ifNoCluster;
            IfMVR = ifMVR;
            IfNoMVR = ifNoMVR;
        }
    }

    public static class PackageInitializer
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        public static void Initialize()
        {
            // Disable attributes [MVRDisable(ifNoMVR: true)]
            // If MVR Manager not present or not active
            if (!MVRTools.GetMVRManager(true))
            {
                MVRTools.MVRDisableAttributes(false);
            }
        }
    }

    [System.Serializable]
    public class EditorClusterDebuggingProperties
    {
        [Tooltip("Will start all cluster nodes and use this Unity Editor as a cluster node")]
        public bool EnableEditorClusterDebugging = false;

        [Tooltip("You need to build the project so the other cluster nodes have the same project version. If left empty will automatically get the path of the last build")]
        public string ExePath;

        [Tooltip("Which cluster ID should be used by this Unity Editor")]
        public string EditorClusterID = "";

        [Tooltip("You can decide to start other cluster nodes manually, with MiddleVR Config, a .bat file, or with other Unity Editors")]
        public bool StartOtherClusterNodes = true;

        [Tooltip("Same argument as in MiddleVR Config")]
        public int LogLevel = 2;
        [Tooltip("Same argument as in MiddleVR Config")]
        public string LogFolder;
        [Tooltip("Same argument as in MiddleVR Config")]
        public bool LogDatePrefix;
        [Tooltip("Same argument as in MiddleVR Config")]
        public string CustomArguments;
        [Tooltip("Ask 'Did you rebuild your application' ?")]
        public bool AskBuildValidation;
    }

    [System.Serializable]
    public class ClusterProperties
    {
        [Tooltip("Tries to identify objects that will not be correctly synchronised, such as physics objects")]
        public bool SimpleCluster = true;

        public EditorClusterDebuggingProperties editorClusterDebuggingProperties;
    }

    public partial class MVRTools
    {
        private static string s_commandLineConfigFile = null;
        private static VRLogLevel s_logLevel = VRLogLevel.Info;

        private static int _layerWarping = -1;
        private static int _layerWarpingMask = -1;

        private static int _layerScreens = -1;
        private static int _layerScreensMask = -1;

        private static MVRManagerScript _mvrMgr = null;
        private static bool _mvrManagerPresenceChecked = false;
        private static bool _mvrDisableDone = false;

        #region Properties

        /// Activate/deactivate sending of messages to the underlying MiddleVR log system.
        public static bool UsingMiddleVRLogSystem { get; set; } = true;

        /// Activate/deactivate sending of messages to the Unity console.
        public static bool RedirectingLogsToUnityConsole { get; set; } = true;

        #endregion Properties
        public static bool VRDestroy(bool iInEditorMode)
        {
            Log(3, "[>] Destroying MiddleVR.");

            MVR.VRDestroy();

            return true;
        }

        public static bool VRLMCheck(bool iEnableEditorClusterDebugging)
        {
            bool lic = false;

            vrClusterManager clusterMgr = MVR.ClusterMgr;

            if (clusterMgr.GetRequestedClusterID().Length != 0 && clusterMgr.GetRequestedClusterID() != "ClusterServer" &&
                !(MVR.Kernel.IsEditorMode() && iEnableEditorClusterDebugging))
            {
                Log(3, "[ ] In Unity, Cluster client, not checking for license.");
                lic = true;
            }
            else
            {
                MVR.LogMgr.SetLogPopupEnabled(false);

                if (MVR.LicenseMgr.Checkout("MVR3-Pro-Unity"))
                {
                    lic = true;
                }

                MVR.LogMgr.SetLogPopupEnabled(true);
            }

            if (!lic)
            {
                lic = MVR.LicenseMgr.CheckoutTrial();
            }

            if (!lic)
            {
                Log(2, "[ ] No license or trial license found, starting trial.");
                MVR.LicenseMgr.StartTrial();
                lic = MVR.LicenseMgr.CheckoutTrial();
            }

            MVR.LicenseMgr.DumpLicense();

            return lic;
        }

        public static bool VRInitialize(string iEditorConfigFile,
                                        bool iEnablePreviewWindow,
                                        ClusterProperties iProps,
                                        int iEditorLogLevel,
                                        bool iForceEnable = false)
        {
            Application.runInBackground = true;

            bool isInit = false;

            Log(3, "[>] MiddleVR.Unity - Starting VR init.");

            if (Application.isEditor)
            {
                vrKernel.SetRuntimeMode(MiddleVR.VRRuntimeMode.Editor);
            }
            else
            {
                vrKernel.SetRuntimeMode(MiddleVR.VRRuntimeMode.Player);
                vrDisplayManager.SetIgnoreGFXAPI();
            }

            MVR.VRInitialize();

            if (MVR.Kernel == null)
            {
                Log(0, "[X] VR Manager failed to initialize.");
                return false;
            }

            // Set export version to current MiddleVR.Unity.dll version.
            Version version = Assembly.GetExecutingAssembly().GetName().Version;

            uint versionMajor = (uint)version.Major;
            uint versionMinor = (uint)version.Minor;
            uint versionRevision = (uint)version.Revision;

            MVR.Kernel.SetExportVersion(versionMajor, versionMinor, versionRevision);

            MVR.Log(2, "[ ] 'MiddleVR.Unity' version '" + version + "'.");

            var log_path = System.IO.Path.Combine(Environment.GetEnvironmentVariable("AppData"),
                                        "..",
                                        "LocalLow",
                                        Application.companyName,
                                        Application.productName);
            MVR.Log(2, "[ ] Unity logs (if not overriden by -logfile): " + log_path);

            vrKernel.Set3DEngine("Unity3D");

            // This will set the clusterId, which is required for LMCheck
            MVRTools.ProcessCommandLineArguments();

            if (Application.isEditor)
            {
                if(iEnablePreviewWindow)
                {
                    MVR.DisplayMgr.SetForceWindowMode(VRWindowMode.Compositor);
                }
                else
                {
                    MVR.DisplayMgr.SetForceWindowMode(VRWindowMode.NativeWindow);
                }

                MVR.LogMgr.SetLogLevel((VRLogLevel)iEditorLogLevel);

                if (iProps.editorClusterDebuggingProperties.EnableEditorClusterDebugging)
                {
                    MVR.DisplayMgr.SetForceWindowMode(VRWindowMode.Compositor);
                    MVR.ClusterMgr.SetDebugClusterInEditorMode(true);

                    if (iProps.editorClusterDebuggingProperties.EditorClusterID.Length == 0)
                    {
                        iProps.editorClusterDebuggingProperties.EditorClusterID = "ClusterServer";
                        Log(2, "[ ] No editor cluster id set, using ClusterServer");
                    }

                    MVR.ClusterMgr.SetRequestedClusterID(iProps.editorClusterDebuggingProperties.EditorClusterID);
                    MVR.LogMgr.SetLogLevel((VRLogLevel)iProps.editorClusterDebuggingProperties.LogLevel);
                }
            }

            VRLMCheck(iProps.editorClusterDebuggingProperties.EnableEditorClusterDebugging);

            Log(3, "[<] MiddleVR.Unity - End of init.");

            string cfgFile = null;

            if (Application.isEditor || iForceEnable)
            {
                cfgFile = iEditorConfigFile;
            }
            else
            {
                // Player mode
                if (s_commandLineConfigFile != null)
                {
                    cfgFile = s_commandLineConfigFile;
                }
            }

            if (cfgFile != null)
            {
                MVR.Log(2, "[ ] Unity Loading Config: '" + cfgFile + "'.");

                if (MVR.Kernel.LoadConfig(cfgFile))
                {
                    MVR.Log(2, "[+] Config loaded successfully: '" + cfgFile + "'.");
                    isInit = true;
                }
                else
                {
                    Log(0, "[X] Config failed to load: '" + cfgFile + "'.");
                    isInit = true;
                }
            }
            else
            {
                Log(1, "[~] No configuration file was loaded.");

                isInit = true;
            }

            if (isInit == true)
            {
                Log(3, "[+] VR Manager Initialization OK!");
                s_logLevel = MVR.LogMgr.GetLogLevel();

                MVR.DisplayMgr.RenameNativeWindow();
            }
            else
            {
                Log(0, "[X] VR Manager failed to load config file '" + iEditorConfigFile + "'.");
            }

            MVR.Log(2,"[ ] Unity: Current quality level: " + QualitySettings.GetQualityLevel());
            MVR.Log(2,"[ ] Unity: In this project's current quality level, VSync is: " + QualitySettings.vSyncCount);

            if (QualitySettings.vSyncCount != 0)
            {
                Log(1, "[X] Unity: You *MUST* deactivate VSync in your Unity application, MiddleVR will handle it." +
                    " (Edit > Project Settings > Quality > VSync Count > Don't Sync)");

                if (!Application.isEditor)
                {
                    MVR.MessageWindow(
                        "You *MUST* deactivate VSync in your Unity application, MiddleVR will handle it." +
                        " (Edit > Project Settings > Quality > VSync Count > Don't Sync)");
                }
            }

            Log(3, "[<] MiddleVR.Unity - End of VRInitialize.");

            if (Application.isEditor
                    && iProps.editorClusterDebuggingProperties.EnableEditorClusterDebugging)
            {
                if (MVR.DisplayMgr.GetRealWindowMode() != VRWindowMode.Compositor)
                {
                    Log(0, "[X] Editor Cluster Debugging is only compatible with a configuration where ForceViewportOutputMode is 'Compositor'");
                    MVR.Kernel.SetQuitting();

#if UNITY_EDITOR
                    MVR.Kernel.SetQuitting();
                    UnityEditor.EditorApplication.ExitPlaymode();
                    throw new System.OperationCanceledException("MiddleVR: Stopping execution - Editor Cluster Debugging requires Compositor mode.");
#endif
                }
                else
                {
#if UNITY_EDITOR
                    if (MVR.ClusterMgr.IsClusterConfig())
                    {
                        bool start = true;

                        if (iProps.editorClusterDebuggingProperties.AskBuildValidation)
                        {
                            start = EditorUtility.DisplayDialog("MiddleVR: Did you build your application?",
                                "MiddleVR: Did you rebuild your application ? If you did not build the latest version of your application, the cluster nodes will not be executing the same version of the application.",
                                "Yes, continue",
                                "No, stop running");
                        }

                        if (start)
                        {
#endif
                            if (iProps.editorClusterDebuggingProperties.StartOtherClusterNodes)
                            {
                                StartClusterNodes(cfgFile, iProps);
                            }

#if UNITY_EDITOR
                        }
                        else
                        {
                            MVR.Kernel.SetQuitting();
                            UnityEditor.EditorApplication.ExitPlaymode();
                            throw new System.OperationCanceledException("MiddleVR: Stopping execution - Build validation cancelled.");
                        }
                    }
#endif
                }
            }

            MVRTools.FindOrCreateLayer("MVR_Warping", out _layerWarping, out _layerWarpingMask);
            MVRTools.FindOrCreateLayer("MVR_ICVFX", out _layerScreens, out _layerScreensMask, _layerWarping + 1);

            return isInit;
        }

        public static MVRManagerScript GetMVRManager(bool iReset = false)
        {
            if (iReset) _mvrManagerPresenceChecked = false;

            if (!_mvrManagerPresenceChecked)
            {
                _mvrManagerPresenceChecked = true;

                var mvrMgr = UnityEngine.Object.FindFirstObjectByType<MVRManagerScript>(FindObjectsInactive.Include);
                if (mvrMgr == null || !mvrMgr.gameObject.activeInHierarchy)
                {
                    Debug.Log("[ ] MVR Manager not found or disabled.");
                    _mvrMgr = null;
                }
                else { _mvrMgr = mvrMgr; }
            }

            return _mvrMgr;
        }

        public static bool WillMVRManagerBeDisabled(bool iVerbose=true)
        {
            bool disableMiddleVR = false;

            if (!Application.isEditor) // If player
            {
                string[] args = System.Environment.GetCommandLineArgs();
                bool foundCfgParam = false;
                bool foundDisableMVRParam = false;

                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i] == "--config")
                    {
                        foundCfgParam = true;
                    }

                    if (args[i] == "--mvr-disable-mvr")
                    {
                        foundDisableMVRParam = true;
                    }
                }

                if (!foundCfgParam)
                {
                    if (iVerbose) Debug.Log("[ ] In Unity Player, command line argument --config not found. Disabling MiddleVR.");
                    disableMiddleVR = true;
                }

                if (foundDisableMVRParam)
                {
                    if (iVerbose) Debug.Log("[ ] In Unity Player, command line argument --mvr-disable-mvr found. Disabling MiddleVR.");
                    disableMiddleVR = true;
                }
            }

            return disableMiddleVR;
        }

        public static void MVRDisableAttributes(bool isMVREnabled = true)
        {
            if (_mvrDisableDone) return;

#if UNITY_2023_1_OR_NEWER
            var behaviours = GameObject.FindObjectsByType<MonoBehaviour>(FindObjectsSortMode.None);
#else
            var behaviours = GameObject.FindObjectsOfType<MonoBehaviour>();
#endif

            foreach (var script in behaviours)
            {
                if (script.enabled)
                {
                    var type = script.GetType();

                    var attribute = type.GetCustomAttribute<MVRDisableAttribute>();

                    string reason = "Unknown Reason";

                    if (attribute != null)
                    {
                        bool disable = false;

                        if (isMVREnabled)
                        {
                            if (attribute.IfMVR) { disable = true; reason = "MVRManager is enabled and present"; }
                            if (MVR.ClusterMgr.IsServer() && attribute.IfServer) { disable = true; reason = "Cluster node is Server"; }
                            if (MVR.ClusterMgr.IsClient() && attribute.IfClient) { disable = true; reason = "Cluster node is Client"; }
                            if (MVR.ClusterMgr.IsClusterConfig() && attribute.IfCluster) { disable = true; reason = "Config is cluster"; }
                            if (!MVR.ClusterMgr.IsClusterConfig() && attribute.IfNoCluster) { disable = true; reason = "Config is not cluster"; }
                        }

                        if (!isMVREnabled && attribute.IfNoMVR) { disable = true; reason = "MVRManager is disabled or not present"; }

                        if (disable)
                        {
                            script.enabled = false; // Disabling the script
                            MVRTools.Log(3, $"[ ] MVR Disabling script '{script.GetType().ToString()}' on '{script.ToString()}' because {reason}");
                        }
                    }
                }
            }

            _mvrDisableDone = true;
        }

        private static void StartClusterNodes(string iCfgFile, ClusterProperties iProps)
        {
            // Create command line
            string cmdLineParameters = MVR.ClusterMgr.CreateCommandLineParameters(
                    iCfgFile,
                    iProps.editorClusterDebuggingProperties.CustomArguments,
                    iProps.editorClusterDebuggingProperties.LogLevel,
                    iProps.editorClusterDebuggingProperties.LogFolder,
                    iProps.editorClusterDebuggingProperties.LogDatePrefix);

            // We don't want the cluster server to start the nodes, we are doing it here
            cmdLineParameters += " --nostartclients";

            var myClusterNode = MVR.ClusterMgr.FindAndSetMyClusterNode();

            if (myClusterNode == null)
            {
                Log(0, "[X] Editor Cluster Debug: Couldn't find cluster node '" + iProps.editorClusterDebuggingProperties.EditorClusterID + "'");
            }
            else
            {
                MVR.ClusterMgr.GetMyClusterNode().SetStartManually(true);

                string exe = iProps.editorClusterDebuggingProperties.ExePath;
#if UNITY_EDITOR
                if (exe.Length == 0)
                {
                    string path = UnityEditor.EditorUserBuildSettings.GetBuildLocation(UnityEditor.BuildTarget.StandaloneWindows64);
                    exe = "\"" + Path.GetFullPath(path) + "\"";
                }
#endif
                if (exe.Length == 0)
                {
                    Log(0, "[X] Editor Cluster Debugging: You must build your application");
                    MVR.Kernel.SetQuitting();
                    return;
                }

                string cmdLine = exe + " " + cmdLineParameters;
                Log(2, "[ ] Unity editor executing : '" + cmdLine + "'.");

                MVR.ClusterMgr.RemoteStartAll(cmdLine, true);

                MVR.Kernel.AddCommandLineArguments(iProps.editorClusterDebuggingProperties.CustomArguments);

                // Update port if needed
                MVR.ClusterMgr.GetClusterServer()._ReadCommandLinePort();

                foreach (var clusterNode in MVR.ClusterMgr.Clients)
                {
                    clusterNode._ReadCommandLinePort();
                }

                MVR.ClusterMgr.StartMyClusterNode();

                MVR.ClusterMgr.GetMyClusterNode().SetStartManually(false);
            }
        }

        public static void VRReset()
        {
        }

        private static void ProcessCommandLineArguments()
        {
            // Extract arguments and apply them in the MiddleVR kernel.
            MVR.Kernel.ExtractCommandLineArguments(true);

            // Find if a configuration file was passed.
            bool nextArgIsConfigFile = false;
            for (uint i = 0, iEnd = MVR.Kernel.GetCommandLineArgumentsNb(); i < iEnd; ++i)
            {
                var cmdLineArg = MVR.Kernel.GetCommandLineArgument(i);

                if (cmdLineArg == "--config")
                {
                    nextArgIsConfigFile = true;
                }
                else if (nextArgIsConfigFile)
                {
                    s_commandLineConfigFile = cmdLineArg;
                    nextArgIsConfigFile = false;
                }
            }
        }

        public static void Log(string iMsg)
        {
            if(MVRTools.GetMVRManager())
            {
                Log(VRLogLevel.Info, iMsg);
            }
            else
            {
                Debug.Log(iMsg);
            }
        }

        public static void Log(int iLogLevel, string iMsg)
        {
            if(MVRTools.GetMVRManager())
            {
                Log((VRLogLevel)iLogLevel, iMsg);
            }
            else
            {
                Debug.Log(iMsg);
            }
        }

        public static void LogError(string iMsg)
        {
            Log(0, "[X] " + iMsg);
        }

        public static void Log(VRLogLevel iLogLevel, string iMsg)
        {
            if (iMsg != null)
            {
                if (RedirectingLogsToUnityConsole &&
                    iLogLevel <= s_logLevel && Application.isEditor)
                {
                    switch (iLogLevel)
                    {
                        case VRLogLevel.Critical:
                        // Treat this as an error.
                        case VRLogLevel.Error:
                            Debug.LogError(iMsg);
                            break;
                        case VRLogLevel.Warning:
                            Debug.LogWarning(iMsg);
                            break;
                        default:
                            Debug.Log(iMsg);
                            break;
                    }
                }

                if (UsingMiddleVRLogSystem)
                {
                    string module = "Unity";
                    MVR.Log((int)iLogLevel, module, iMsg);
                }
            }
        }

        public static void UpdateCameraProperties(vrCamera iMVRCamera, Camera iUnityCamera)
        {
            iUnityCamera.nearClipPlane = iMVRCamera.GetFrustumNear();
            iUnityCamera.farClipPlane = iMVRCamera.GetFrustumFar();
            iUnityCamera.projectionMatrix = iMVRCamera.GetProjectionMatrix().RawToUnity();
        }

        public static void UpdateCameraProperties(MVRNodesMapper iNodesMapper)
        {
            var logLevel = MVR.LogMgr.GetLogLevel();

            foreach (var camera in MVR.DisplayMgr.Cameras)
            {
                if (camera is vrCameraStereo)
                    continue;

                var cameraGameObject = iNodesMapper.GetNode(camera);
                var cameraComponent = cameraGameObject.GetComponent<Camera>();

                /*
                // Check of the log level to avoid unneeded calls to mvrCam.GetName().
                if (logLevel >= VRLogLevel.Debug1)
                {
                    MVRTools.Log(VRLogLevel.Debug1, "[ ] Computing projection matrix for camera '" +
                        camera.GetName() + "', enabled? '" +
                        cameraComponent.enabled + "'.");
                }*/

                UpdateCameraProperties(camera, cameraComponent);
            }
        }

        public static void AddClusterScript(GameObject iObject)
        {
            if (iObject != null && iObject.GetComponent<MVRClusterObject>() == null)
            {
                iObject.AddComponent<MVRClusterObject>();
                MVRTools.Log("AddClusterScript to " + iObject.name);
            }
        }

        public static bool FindOrCreateLayer(string iLayerName, out int iLayer, out int iLayerMask, int iStartLayer = 9)
        {
            for (int i = iStartLayer; i < 32; i++)
            {
                int mask = 1 << i;
                string name = LayerMask.LayerToName(i);
                //Debug.Log($"Layer {i} ; mask : {mask} ; name : {name}");

                if (name.Length == 0 || name == iLayerName)
                {
                    iLayer = i;
                    iLayerMask = mask;
                    return true;
                }
            }

            iLayer = -1;
            iLayerMask = -1;

            MVRTools.Log("[X] MVRTools: Could not find empty or MVR layer");
            return false;
        }

        public static int GetWarpingLayer()
        {
            return _layerWarping;
        }

        public static int GetWarpingLayerMask()
        {
            return _layerWarpingMask;
        }

        public static int GetScreensLayer()
        {
            return _layerScreens;
        }

        public static int GetScreensLayerMask()
        {
            return _layerScreensMask;
        }

        public static void SaveRenderTexture(RenderTexture iRT, string iPath)
        {
            Texture2D tex = new Texture2D(iRT.width, iRT.height, TextureFormat.RGB24, false);
            RenderTexture prevRT = RenderTexture.active;
            RenderTexture.active = iRT;
            tex.ReadPixels(new Rect(0, 0, iRT.width, iRT.height), 0, 0);
            tex.Apply();
            RenderTexture.active = prevRT;

            byte[] bytes = tex.EncodeToPNG();
            System.IO.File.WriteAllBytes(iPath, bytes);
            UnityEngine.Object.Destroy(tex);
        }

        public static void SaveTexture(Texture2D iTex, string iPath)
        {
            byte[] bytes = iTex.EncodeToPNG();
            System.IO.File.WriteAllBytes(iPath, bytes);
        }

        public static bool AddDefine(string iDefine)
        {
            bool foundDefine = false;

#if UNITY_EDITOR
#if UNITY_2023_1_OR_NEWER
            var defines = PlayerSettings.GetScriptingDefineSymbols(UnityEditor.Build.NamedBuildTarget.Standalone);
#else
            var defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Standalone);
#endif

            string[] defineList = defines.Split(";");

            foreach (string define in defineList)
            {
                if (define == iDefine) foundDefine = true;
            }

            if (!foundDefine)
            {

                defines += ";" + iDefine;
#if UNITY_2023_1_OR_NEWER
                PlayerSettings.SetScriptingDefineSymbols(UnityEditor.Build.NamedBuildTarget.Standalone, defines);
#else
                PlayerSettings.SetScriptingDefineSymbolsForGroup(BuildTargetGroup.Standalone, defines);
#endif
                Debug.Log("Added define: " + iDefine);
            }
#endif
            return foundDefine;
        }
    }
} // namespace MiddleVR.Unity
