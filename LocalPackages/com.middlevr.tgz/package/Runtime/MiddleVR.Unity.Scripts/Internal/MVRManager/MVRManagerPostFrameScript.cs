/* MVRManagerPostFrameScript
 * MiddleVR
 * (c) MiddleVR
 */

using System.Collections;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine;
using UnityEngine.Events;

[AddComponentMenu("")]
public class MVRManagerPostFrameScript : MonoBehaviour
{
    private bool _loggedNoKeyboard = false;
    private bool _continuePostFrameUpdate = false;

    private UnityEvent _afterPostFrameEvent;

    #region MonoBehaviour
    private void Start()
    {
        MVRTools.Log(VRLogLevel.Trace, "[ ] Unity: StartCoroutine PostFrameUpdate");

        _afterPostFrameEvent = new UnityEvent();

        _continuePostFrameUpdate = true;
        StartCoroutine(PostFrameUpdate());
    }

    private void Update()
    {
        MVRTools.Log(VRLogLevel.Trace, "[>] Unity: VR EndFrame Update!");

        MVR.Kernel.EndFrameUpdate();

        Cluster.DispatchMessages();

        MVRTools.Log(VRLogLevel.Trace, "[<] Unity: End of VR EndFrame Update!");
    }

    public void AddPostFrameListener(UnityAction iListener)
    {
        _afterPostFrameEvent.AddListener(iListener);
    }

    private void OnApplicationQuit()
    {
        _continuePostFrameUpdate = false;
    }
    #endregion

    #region VRManagerPostFrame
    // This coroutine when started, will wait for every end of frame and then
    // call the PostFrameUpdate of the vrKernel.
    private IEnumerator PostFrameUpdate()
    {
        while (_continuePostFrameUpdate)
        {
            yield return new WaitForEndOfFrame();

            var mgr = GetComponent<MVRManagerScript>();

            MVRTools.Log(VRLogLevel.Trace, "[>] Unity: Start of VR PostFrameUpdate.");

            if (MVR.DeviceMgr != null)
            {
                var keyboard = MVR.DeviceMgr.GetKeyboard();
                if (keyboard != null)
                {
                    if (mgr != null && mgr.advancedProperties.QuitOnEsc && (keyboard.IsKeyPressed((uint)MVR.VRK_ESCAPE)))
                    {
                        mgr.QuitApplication();
                    }
                }
                else
                {
                    // IsQuitting: We might be in EditorClusterDebugg and stopped the execution abruptly
                    if (!_loggedNoKeyboard && !MVR.Kernel.IsQuitting())
                    {
                        MVRTools.Log(VRLogLevel.Error, "[X] No VR keyboard.");
                        _loggedNoKeyboard = true;
                    }
                }
            }

            if (MVR.Kernel != null)
            {
                MVR.Kernel.PostFrameUpdate();
                _afterPostFrameEvent.Invoke();
            }

            MVRTools.Log(VRLogLevel.Trace, "[<] Unity: End of VR PostFrameUpdate.");
        }
    }
    #endregion
}
