/* MVRManagerScript
 * MiddleVR
 * (c) MiddleVR
 */

using System.Collections.Generic;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Playables;
using System;
using System.IO;
using System.Reflection;

#if !UNITY_2019_4 && !UNITY_2020_3 && !UNITY_2021_1 && !UNITY_2021_2 && !UNITY_2021_3 && !UNITY_2022_1 && !UNITY_2022_2 && !UNITY_2022_3 && !UNITY_2023_1 && !UNITY_2023_2 && !UNITY_2023_3 && !UNITY_6000
#error This version of Unity is not supported.
#endif

[AddComponentMenu("")]
[HelpURL("http://www.middlevr.com/2/doc/current/#vrmanager_options")]
public class MVRManagerScript : MonoBehaviour
{
    // Exposed parameters:
    [Tooltip("Which configuration will be loaded on play?")]
    public string EditorConfigFile = "C:\\Program Files\\MiddleVR3\\data\\Config\\Default\\Default.vrx";

    [Tooltip("Attach MVRManager to the first active camera in the scene")]
    public bool AttachToCamera = true;

    [Tooltip("Enable the preview window")]
    public bool PreviewWindow = false;

    public ClusterProperties clusterProperties;

    [System.Serializable]
    public class VRProperties_
    {
        public bool ShowWand = true;

        [SerializeField]
        private bool _showScreenProximityWarnings = false;
        public bool ShowScreenProximityWarnings
        {
            get
            {
                return _showScreenProximityWarnings;
            }
            set
            {
                _showScreenProximityWarnings = value;

                var mvrManager = MVRTools.GetMVRManager();
                if (mvrManager != null) mvrManager.EnableProximityWarning(value);
            }
        }
    }

    public VRProperties_ VRProperties;

    [System.Serializable]
    public class AdvancedProperties
    {
        public bool UseTemplateCamera = true;

        [Tooltip("Choose which camera in the scene should be duplicated for each MiddleVR camera")]
        public GameObject TemplateCamera = null;

        [Tooltip("[Warning] Experimental, see documentation for possible negative side effects")]
        public bool UseMVRTime = false;

        public uint Overscan = 0;

        [Tooltip("Previz cameras on screens")]
        public bool VisualizeScreens;

        [Tooltip("Disable existing cameras in the scene for performances reasons")]
        public bool DisableExistingCameras = true;

        public int EditorLogLevel = 2;

        [Tooltip("Quit the application when the user presses 'Esc'.")]
        public bool QuitOnEsc = true;

        [SerializeField]
        private bool _showFPS = false;

        public bool ShowFPS
        {
            get
            {
                return _showFPS;
            }
            set
            {
                _showFPS = value;

                var mvrManager = MVRTools.GetMVRManager();
                if (mvrManager != null) mvrManager.EnableFPSDisplay(value);
            }
        }

        [Tooltip("Allows modification of the transform of an MVR node if it has no tracker assigned.")]
        public bool DisengageUntrackedNodes = false;

        [Tooltip("Save the final render of the compositor/preview window")]
        public string SaveOutputFile;
        [Tooltip("Increment the name of the saved render")]
        public bool SaveOutputIncrement = false;

        [HideInInspector]
        public bool ForceCompositorHDRRender = false;
    }

    public AdvancedProperties advancedProperties;

    // Private members
    private GameObject _root = null;

    private bool _logsToUnityConsole = true;
    private bool _forceQuality = false;
    private int _forceQualityIndex = 3;

    private List<Text> _fpsTexts = new List<Text>();

    private GameObject _wand = null;

    public bool IsInit() { return _isInit; }
    private bool _isInit = false;
    private bool _isGeometrySet = false;

    private uint _firstFrameAfterReset = 0;

    [HideInInspector]
    public bool ForceEnable = false;

    private struct TimeStruct
    {
        public float TimeScale;
        public float FixedDeltaTime;
    }

    private TimeStruct _time = new TimeStruct();

    // Public methods

    public GameObject GetRoot()
    {
        return _root;
    }

    public void Log(string text)
    {
        MVRTools.Log(text);
    }

    private enum ClusterChannels : int
    {
        Quit = -1,
        RandomSeed = -2,
        Time = -3
    }

    // Private methods

    private void InitializeVR()
    {
        if (MVR.Kernel != null)
        {
            MVRTools.Log(VRLogLevel.Debug, "[ ] MVRManager::VRKernel already alive, reset Unity Manager.");
            MVRTools.VRReset();
            _isInit = true;
            _firstFrameAfterReset = MVR.Kernel.GetFrame();
        }
        else
        {
            _isInit = MVRTools.VRInitialize(EditorConfigFile, PreviewWindow, clusterProperties, advancedProperties.EditorLogLevel, ForceEnable);
        }

        DumpOptions();

        if (MVR.ClusterMgr.IsClusterConfig())
        {
            if (clusterProperties.SimpleCluster)
            {
                SetupSimpleCluster();
            }

            Cluster.AddMessageHandler(
                null,
                (int exitCode) =>
                {
                    LocalQuit(exitCode);
                },
                channel: ClusterChannels.Quit);

            Cluster.AddMessageHandler(
                null,
                (UnityEngine.Random.State state) =>
                {
                    UnityEngine.Random.state = state;

                    Cluster.RemoveMessageHandler(
                        null,
                        channel: ClusterChannels.RandomSeed);
                },
                channel: ClusterChannels.RandomSeed);

            Cluster.BroadcastMessage(
                null,
                UnityEngine.Random.state,
                channel: ClusterChannels.RandomSeed);

            _time.TimeScale = Time.timeScale;
            _time.FixedDeltaTime = Time.fixedDeltaTime;

            Cluster.AddMessageHandler(
                null,
                (TimeStruct time) =>
                {
                    Time.fixedDeltaTime = time.FixedDeltaTime;
                    Time.timeScale = time.TimeScale;
                },
                channel: ClusterChannels.Time);
        }

        if (!advancedProperties.UseTemplateCamera && advancedProperties.TemplateCamera != null)
        {
            advancedProperties.TemplateCamera = null;
        }
        else if (advancedProperties.UseTemplateCamera && advancedProperties.TemplateCamera == null)
        {
            GrabTemplateCamera();
        }

        _root = this.gameObject;

        Transform origParent = null;

        if (advancedProperties.TemplateCamera != null
            && this.transform.IsChildOf(advancedProperties.TemplateCamera.transform))
        {
            // Prevent duplication of the MVRManager if it is a child of the template camera
            origParent = this.transform.parent;

            this.transform.parent = null;
        }

        MVRTools.CreateNodes(_root,
                             advancedProperties.TemplateCamera,
                             advancedProperties.VisualizeScreens,
                             advancedProperties.DisengageUntrackedNodes);

        if (origParent != null)
        {
            this.transform.parent = origParent;
        }

        if (AttachToCamera && Camera.allCamerasCount > 0)
        {
            var cam = Camera.allCameras[0];
            this.transform.parent = cam.transform;
            this.transform.localPosition = new Vector3(0, 0, 0);
            this.transform.localRotation = new Quaternion(0, 0, 0, 1);
            this.transform.localScale = new Vector3(1, 1, 1);
        }

        if (advancedProperties.DisableExistingCameras)
        {
#if UNITY_2023_1_OR_NEWER
            foreach (var camera in GameObject.FindObjectsByType<Camera>(FindObjectsSortMode.None))
#else
            foreach (var camera in FindObjectsOfType<Camera>())
#endif
            {
                if (camera.targetTexture == null)
                {
                    camera.enabled = false;
                }
            }
        }

        MVRTools.CreateViewportsAndCameras(mvrManagerGO: gameObject);

        bool enableWand = false;

        foreach (vrNode3D node in MVR.DisplayMgr.Nodes)
        {
            if (node.GetName().Contains("HandNode"))
            {
                enableWand = true;
            }
        }

        var wand = transform.Find("MVRWand");
        if (wand != null)
        {
            wand.gameObject.SetActive(enableWand);
        }

        ManageAudioListeners();

        MVRTools.Log(4, "[<] MVRManager::End of InitializeVR");
    }

    private void PreInitCommandLine()
    {
        // Parse for parameters that need to be applied before MVR is initialized
        string[] args = System.Environment.GetCommandLineArgs();
        bool nextArgIsSaveOutputFile = false;
        bool nextArgIsClusterId = false;
        string saveOutputFile = "";
        string clusterId = "";

        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "--mvr-save-output")
            {
                nextArgIsSaveOutputFile = true;
            }
            else if (nextArgIsSaveOutputFile)
            {
                saveOutputFile = args[i];
                nextArgIsSaveOutputFile = false;
            }

            if (args[i] == "--clusterid")
            {
                nextArgIsClusterId = true;
            }
            else if (nextArgIsClusterId)
            {
                clusterId = args[i];
                nextArgIsClusterId = false;
            }

            if (args[i] == "--mvr-save-output-increment")
            {
                this.advancedProperties.SaveOutputIncrement = true;
            }
        }

        if (saveOutputFile.Length > 0)
        {
            if (clusterId.Length > 0)
            {
                //saveOutputFile = saveOutputFile + "_" + clusterId;

                // Append clusterId to file name
                // Get directory (if any), file name without extension, and the extension.
                string directory = Path.GetDirectoryName(saveOutputFile);
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(saveOutputFile);
                string extension = Path.GetExtension(saveOutputFile);

                // Construct the new file name with the postfix inserted.
                string newFileName = fileNameWithoutExtension + "_" + clusterId + extension;

                // If the original filename had a directory, combine it with the new file name.
                if (!string.IsNullOrEmpty(directory))
                {
                    newFileName = Path.Combine(directory, newFileName);
                }

                saveOutputFile = newFileName;
            }

            this.advancedProperties.SaveOutputFile = saveOutputFile;
        }
    }

    protected void Awake()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.playModeStateChanged += HandleOnPlayModeChanged;
#endif

        // Disable MVR if not in widnows
#if !(UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN)

#else
        if (MVRTools.WillMVRManagerBeDisabled() && !ForceEnable)
#endif
        {
            // Disable attributes [MVRDisable(ifNoMVR: true)]
            // If MVR Manager is disabled because --config was not found

            MVRTools.MVRDisableAttributes(false);

            Debug.Log("[ ] Disabling MiddleVR");
            gameObject.SetActive(false);
            return;
        }

        MVRNodesMapper.CreateInstance();

        MVRTools.RedirectingLogsToUnityConsole = _logsToUnityConsole;

        PreInitCommandLine();

        InitializeVR();

        // Disable all other attributes [MVRDisable(isServer, isClient, ifCluster, ifNoCluster)]
        // After cluster has been initialized
        MVRTools.MVRDisableAttributes();

        if(MVR.ClusterMgr.IsClusterConfig())
            this.gameObject.AddComponent<MVRClusterObject>();
    }

#if UNITY_EDITOR
    void HandleOnPlayModeChanged(UnityEditor.PlayModeStateChange iState)
    {
        // This method is run whenever the playmode state is changed.
        if (Application.isEditor
            && clusterProperties.editorClusterDebuggingProperties.EnableEditorClusterDebugging
            && iState == UnityEditor.PlayModeStateChange.ExitingPlayMode)
        {
            // Tell every cluster node to quit
            QuitApplication();
        }
    }
#endif

    protected void Start()
    {
        MVRTools.Log(4, "[>] MVRManager::Start.");

        _wand = GameObject.Find("MVRWand");

        ShowWandGeometry(VRProperties.ShowWand);

        EnableProximityWarning(VRProperties.ShowScreenProximityWarnings);

        EnableFPSDisplay(advancedProperties.ShowFPS);

        if (_forceQuality)
        {
            QualitySettings.SetQualityLevel(_forceQualityIndex);
        }

        //SetupGPULink();

        // Calling that here because the property has been set by either URP or HDRP before
        // And we need to pass the overscan value to the MiddleVR kernel
        SetOverscanIfHigher(advancedProperties.Overscan);

        MVRTools.Log(4, "[<] MVRManager::End of Start.");
    }

    public void SetOverscanIfHigher(uint iOverscan)
    {
        if (MVR.DisplayMgr != null)
        {
            if (iOverscan > MVR.DisplayMgr.GetOverscan())
            {
                MVR.DisplayMgr.SetOverscan(iOverscan);
                advancedProperties.Overscan = iOverscan;
            }
        }
        else
        {
            advancedProperties.Overscan = iOverscan;
        }
    }

    public uint GetOverscan()
    {
        return advancedProperties.Overscan;
    }

    private void SetupGPULink()
    {
        foreach (var cam in MVR.DisplayMgr.Cameras)
        {
            if (cam.GetRenderToTexture() && cam.GetRenderTextureGPUIndex() >= 0)
            {
                gameObject.AddComponent<MVRGPULink>();
                break;
            }
        }
    }

    private void EnableProximityWarning(bool iShow)
    {
        if (_wand != null)
        {
            MVRScreenProximityWarning proximityWarning = _wand.GetComponent<MVRScreenProximityWarning>();

            if (proximityWarning != null)
            {
                proximityWarning.enabled = VRProperties.ShowScreenProximityWarnings;
            }
        }
    }

    private void EnableFPSDisplay(bool iEnable)
    {
        foreach(var cam in Camera.allCameras)
        {
            Transform camCanvas = cam.transform.Find(cam.name + "_Canvas");
            if ( camCanvas == null)
            {
                GameObject go = new GameObject(cam.name + "_Canvas");
                go.transform.parent = cam.transform;
                //go.transform.position = new Vector3(0, 0, 0);
                //go.transform.rotation = new Quaternion(0, 0, 0, 1);

                var canvas = go.gameObject.AddComponent<Canvas>();
                // Draw 2D interface
                canvas.renderMode = RenderMode.ScreenSpaceCamera;
                canvas.worldCamera = cam;
                // Draw on top of everything
                //canvas.sortingOrder = 1000;

                var canvasScaler = go.gameObject.AddComponent<CanvasScaler>();
                // Use coordinates in pixels
                //canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;

                var textGO = new GameObject("FPS Text");
                textGO.transform.parent = go.transform;

                var text = textGO.AddComponent<Text>();
                var rct = text.rectTransform;

#if UNITY_2022_3 || UNITY_2023_1_OR_NEWER
                text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                text.fontSize = 15;
                text.rectTransform.pivot = new Vector2(0, 0);
                rct.anchorMin = new Vector2(0.0f, 0.0f);
                rct.anchorMax = new Vector2(1.0f, 1.0f);
                text.alignment = TextAnchor.LowerLeft;
                text.rectTransform.anchoredPosition3D = new Vector3(0, 0, 0);
                text.transform.localRotation = new Quaternion(0, 0, 0, 1);
                text.transform.localScale = new Vector3(1, 1, 1);

                _fpsTexts.Add(text);

            }

            //GameObject camCanvasGO = cam.transform.Find(cam.name + "_Canvas").gameObject;
            GameObject camCanvasGO = GameObject.Find(cam.name + "_Canvas");
            camCanvasGO.GetComponent<Canvas>().enabled = advancedProperties.ShowFPS;
        }
    }

    public void ShowWandGeometry(bool iShow)
    {
        if (_wand != null)
        {
            _wand.GetComponent<MVRWand>().Show(iShow);
        }
    }

    protected void GrabTemplateCamera()
    {
        // List all *active/enabled* cameras
        Camera[] allCameras = Camera.allCameras;

        if (allCameras.Length > 0)
        {
            advancedProperties.TemplateCamera = allCameras[0].gameObject;

            MVRTools.Log(3, "[ ] Using camera '" + advancedProperties.TemplateCamera.name + "' as template camera.");
        }
        else
        {
            MVRTools.Log(3, "[~] Couldn't find an active camera to use as a template camera.");
        }
    }

    protected void ManageAudioListeners()
    {
        // Disable all audio listeners
#if UNITY_2023_1_OR_NEWER
        foreach (var listener in GameObject.FindObjectsByType<AudioListener>(FindObjectsSortMode.None))
#else
        foreach (var listener in FindObjectsOfType<AudioListener>())
#endif
        {
            listener.enabled = false;
        }

        // Enable AudioListener on HeadNode
        var headNode = GameObject.Find("HeadNode");
        if (headNode != null)
        {
            var headListener = headNode.GetComponent<AudioListener>();
            if (headListener == null)
                headListener = headNode.AddComponent<AudioListener>();
            headListener.enabled = true;
        }
    }

    // Update is called once per frame
    protected void Update()
    {
        MVRNodesMapper nodesMapper = MVRNodesMapper.Instance;

        if (_isInit)
        {
            MVRTools.Log(4, "[>] Unity Update - Start");

            if (MVR.Kernel.GetFrame() >= _firstFrameAfterReset + 1 && !_isGeometrySet && !Application.isEditor)
            {
                MVR.DisplayMgr.SetNativeWindowGeometry();
                _isGeometrySet = true;
            }

            // Set the random seed in kernel for dispatching only during start-up.
            if (MVR.Kernel.GetFrame() == 0)
            {
                // Disable obsolescence warning for Random.seed as we only use it to initalize
                // the MiddleVR random seed.
                // Using Random.seed was deprecated because it is a single integer and does not
                // contain the full state of the random number generator and thus could not be
                // used for restoring or synchronizing the state.
#pragma warning disable 618
                // The cast is safe because the seed is always positive.
                MVR.Kernel._SetRandomSeed((uint)UnityEngine.Random.seed);
#pragma warning restore 618
            }

            // Must wait that compositor creates the render textures
            if (MVR.Kernel.GetFrame() == 1)
            {
                if (advancedProperties.VisualizeScreens && Application.isEditor)
                {
                    SetupScreens();
                }
            }

            if (MVR.ClusterMgr.IsClusterConfig())
            {
                if (Mathf.Abs(Time.timeScale - _time.TimeScale) > 0.00001f
                || Mathf.Abs(Time.fixedDeltaTime - _time.FixedDeltaTime) > 0.00001f)
                {
                    _time.TimeScale = Time.timeScale;
                    _time.FixedDeltaTime = Time.fixedDeltaTime;

                    Cluster.BroadcastMessage(
                        null,
                        _time,
                        channel: ClusterChannels.Time
                        );
                }
            }

            MVR.Kernel.Update();

            if (advancedProperties.ShowFPS)
            {
                foreach (var text in _fpsTexts)
                {
                    text.text = MVR.Kernel.GetFPS().ToString("f2");
                }
            }

            nodesMapper.UpdateNodesMiddleVRToUnity();

            MVRTools.UpdateCameraProperties(nodesMapper);

            Cluster.DispatchMessages();

            vrKeyboard keyb = MVR.DeviceMgr.GetKeyboard();

            if (keyb != null)
            {
                if (keyb.IsKeyPressed(MVR.VRK_LSHIFT) || keyb.IsKeyPressed(MVR.VRK_RSHIFT))
                {

                    if (keyb.IsKeyToggled(MVR.VRK_D))
                    {
                        advancedProperties.ShowFPS = !advancedProperties.ShowFPS;
                    }

                    if (keyb.IsKeyToggled(MVR.VRK_W) || keyb.IsKeyToggled(MVR.VRK_Z))
                    {
                        VRProperties.ShowWand = !VRProperties.ShowWand;
                        ShowWandGeometry(VRProperties.ShowWand);
                    }
                }
            }

            MVRTools.Log(4, "[<] Unity Update - End");
        }
    }

    private void SetupSimpleCluster()
    {
        // Rigidbody
#if UNITY_2023_1_OR_NEWER
        foreach (var rigidBody in GameObject.FindObjectsByType<Rigidbody>(FindObjectsSortMode.InstanceID))
#else
        foreach (var rigidBody in FindObjectsOfType<Rigidbody>())
#endif
        {
            if (!rigidBody.isKinematic)
            {
                MVRTools.AddClusterScript(rigidBody.gameObject);
            }
        }

        // CharacterController
#if UNITY_2023_1_OR_NEWER
        foreach (var characterController in GameObject.FindObjectsByType<CharacterController>(FindObjectsSortMode.InstanceID))
#else
        foreach (var characterController in FindObjectsOfType<CharacterController>())
#endif
        {
            MVRTools.AddClusterScript(characterController.gameObject);
        }

        // Animator
#if UNITY_2023_1_OR_NEWER
        foreach (var anim in GameObject.FindObjectsByType<Animator>(FindObjectsSortMode.None))
#else
        foreach (var anim in FindObjectsOfType<Animator>())
#endif

        {
            anim.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        }

        // PlayableDirector
#if UNITY_2023_1_OR_NEWER
        foreach (var playabledirector in GameObject.FindObjectsByType<PlayableDirector>(FindObjectsSortMode.InstanceID))
#elif UNITY_2021_1_OR_NEWER
        foreach (var playabledirector in FindObjectsOfType<PlayableDirector>(true))
#else
        foreach (var playabledirector in FindObjectsOfType<PlayableDirector>())
#endif
        {
            if (playabledirector.gameObject.GetComponent<MVRClusterPlayableDirector>() == null)
            {
                playabledirector.gameObject.AddComponent<MVRClusterPlayableDirector>();
            }
        }

        // ParticleSystem
#if UNITY_2023_1_OR_NEWER
        foreach (var particleSystem in GameObject.FindObjectsByType<ParticleSystem>(FindObjectsSortMode.InstanceID))
#elif UNITY_2021_1_OR_NEWER
        foreach (var particleSystem in FindObjectsOfType<ParticleSystem>(true))
#else
        foreach (var particleSystem in FindObjectsOfType<ParticleSystem>())
#endif
        {
            if (particleSystem.gameObject.GetComponent<MVRClusterParticleSystem>() == null)
            {
                particleSystem.gameObject.AddComponent<MVRClusterParticleSystem>();
            }
        }
    }

    private void DumpOptions()
    {
        MVRTools.Log(3, "[ ] Dumping MVRManager's options:");
        MVRTools.Log(3, "[ ] - Config File : " + EditorConfigFile);
        MVRTools.Log(3, "[ ] - Template Camera : " + advancedProperties.TemplateCamera);
        MVRTools.Log(3, "[ ] - Show Wand : " + VRProperties.ShowWand);
        MVRTools.Log(3, "[ ] - Show Proximity Warnings: " + VRProperties.ShowScreenProximityWarnings);
        MVRTools.Log(3, "[ ] - Show FPS  : " + advancedProperties.ShowFPS);
        MVRTools.Log(3, "[ ] - Disable Existing Cameras : " + advancedProperties.DisableExistingCameras);
        MVRTools.Log(3, "[ ] - Quit On Esc : " + advancedProperties.QuitOnEsc);
        MVRTools.Log(3, "[ ] - Simple Cluster : " + clusterProperties.SimpleCluster);
    }

    public void QuitApplication(int exitCode = 0)
    {
        MVRTools.Log(3, "[ ] Execute QuitCommand.");

        // IsQuitting: We might be in EditorClusterDebugg and stopped the execution abruptly
        if (MVR.ClusterMgr.IsClusterConfig() && !MVR.Kernel.IsQuitting())
        {
            Cluster.BroadcastMessage(null, exitCode, channel: ClusterChannels.Quit);
        }
        else
        {
            LocalQuit(exitCode);
        }
    }

    private void LocalQuit(int exitCode = 0)
    {
        MVRTools.Log(3, "[ ] Unity says we're quitting.");
        MVR.Kernel.SetQuitting();

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit(exitCode);
#endif
    }

    protected void OnApplicationQuit()
    {
        MVRNodesMapper.DestroyInstance();

        MVRTools.VRDestroy(Application.isEditor);
    }

    protected void OnDestroy()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.playModeStateChanged -= HandleOnPlayModeChanged;
#endif
    }

    private void SetupScreens()
    {
        foreach (var screen in MVR.DisplayMgr.Screens)
        {
            foreach (var cam in MVR.DisplayMgr.Cameras)
            {
                // Only display screen if one camera is using it
                if (cam.GetScreen() != null && cam.GetScreen().GetId() == screen.GetId())
                {
                    if (cam is vrCameraStereo)
                        continue;

                    var screenGameObject = MVRNodesMapper.Instance.GetNode(screen);

                    var plane = GameObject.CreatePrimitive(PrimitiveType.Quad);

                    plane.name = screenGameObject.name + "-Gizmo";
                    plane.transform.parent = screenGameObject.transform;
                    plane.transform.localPosition = new Vector3(-screen.GetOriginX(), -screen.GetOriginZ(), 0);
                    plane.transform.localRotation = Quaternion.identity;

                    plane.transform.localScale = new Vector3(
                        screen.GetWidth(),
                        screen.GetHeight(),
                        1.0f
                        );

                    plane.layer = MVRTools.GetScreensLayer();

#if MVR_URP
                    var material = new Material(Shader.Find("Universal Render Pipeline/Unlit"));
#elif MVR_HDRP
            var material = new Material(Shader.Find("MVR/UnlitShader_HDRP"));
#else
            var material = new Material(Shader.Find("MVR/UnlitShader"));
#endif

                    plane.GetComponent<Renderer>().material = material;

                    var unityCam = MVRNodesMapper.Instance.GetNode(cam).GetComponent<Camera>();

                    if (unityCam.targetTexture == null)
                    {
                        unityCam.rect = new Rect(0, 0, 1920, 1080);
                        unityCam.targetTexture = new RenderTexture(1920, 1280, 24);
                        unityCam.targetTexture.Create();
                    }

#if MVR_HDRP
                    material.SetTexture("_ColorMap", unityCam.targetTexture);
#else
                    material.mainTexture = unityCam.targetTexture;
#endif
                    // Don't render screens on Unity camera
                    unityCam.cullingMask = unityCam.cullingMask & ~MVRTools.GetScreensLayerMask();
                }
            }
        }
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void ReplaceTimeGetters()
    {
        var mvrMgr = MVRTools.GetMVRManager(false);
        if (mvrMgr != null && mvrMgr.advancedProperties.UseMVRTime)
        {
            MVRTools.Log("[+] Replacing Unity Time with MVR time [XXX Warning XXX Experimental. Make sure to read the documentation for limitations and possible side effects.");
            // replace Time.time
            ReplaceMethod(typeof(Time).GetProperty("time", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public).GetGetMethod(),
                          typeof(MVRManagerScript).GetMethod("GetTime", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public));

            // replace Time.timeAsDouble
            ReplaceMethod(typeof(Time).GetProperty("timeAsDouble", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public).GetGetMethod(),
                          typeof(MVRManagerScript).GetMethod("GetTimeAsDouble", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public));

            // replace Time.deltaTime
            ReplaceMethod(typeof(Time).GetProperty("deltaTime", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public).GetGetMethod(),
                          typeof(MVRManagerScript).GetMethod("GetDeltaTime", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public));

            // replace Time.frameCount
            ReplaceMethod(typeof(Time).GetProperty("frameCount", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public).GetGetMethod(),
                          typeof(MVRManagerScript).GetMethod("GetFrameCount", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public));
        }
    }

    /// <summary>
    /// Inpired by https://tryfinally.dev/detours-redirecting-csharp-methods-at-runtime
    /// </summary>
    private static void ReplaceMethod(MethodInfo originalMethod, MethodInfo newMethod)
    {
        RuntimeMethodHandle methodHandle = originalMethod.MethodHandle;
        unsafe
        {
            if (IntPtr.Size == sizeof(long))
            {
                long functionPointer = methodHandle.GetFunctionPointer().ToInt64();
                // Native source address
                byte* functionPointerByte = (byte*)functionPointer;

                // Pointer to insert jump address into native code
                long* functionPointerAddress = (long*)(functionPointerByte + 0x02);

                // Insert 64-bit absolute jump into native code (address in rax)
                // mov rax, immediate64
                // jmp [rax]
                *(functionPointerByte + 0x00) = 0x48;
                *(functionPointerByte + 0x01) = 0xB8;
                *functionPointerAddress = newMethod.MethodHandle.GetFunctionPointer().ToInt64();
                *(functionPointerByte + 0x0A) = 0xFF;
                *(functionPointerByte + 0x0B) = 0xE0;
            }
            else
            {
                int functionPointer = methodHandle.GetFunctionPointer().ToInt32();
                // Native source address
                byte* functionPointerByte = (byte*)functionPointer;

                // Pointer to insert jump address into native code
                int* functionPointerAddress = (int*)(functionPointerByte + 0x02);

                // Insert 64-bit absolute jump into native code (address in rax)
                // mov rax, immediate64
                // jmp [rax]
                *(functionPointerByte + 0x00) = 0x48;
                *(functionPointerByte + 0x01) = 0xB8;
                *functionPointerAddress = newMethod.MethodHandle.GetFunctionPointer().ToInt32();
                *(functionPointerByte + 0x0A) = 0xFF;
                *(functionPointerByte + 0x0B) = 0xE0;
            }
        }
    }

    public static float GetTime()
    {
        return MVR.Kernel != null ? (float)MVR.Kernel.GetTime() / 1000f : 0;
    }

    public static double GetTimeAsDouble()
    {
        return MVR.Kernel != null ? MVR.Kernel.GetTime() / 1000d : 0;
    }

    public static float GetDeltaTime()
    {
        return MVR.Kernel != null ? (float)MVR.Kernel.GetDeltaTime() : 0;
    }

    public static int GetFrameCount()
    {
        return MVR.Kernel != null ? (int)MVR.Kernel.GetFrame() : 0;
    }
}
