﻿/* MVRTools
 * MiddleVR
 * (c) MiddleVR
 */

using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using UnityEngine;

namespace MiddleVR.Unity
{
    public partial class MVRTools
    {
        #region Viewport Creation
        /// <summary>
        /// Setup the output window and all cameras in the scene
        /// </summary>
        /// <param name="iUsingAntiAliasing">Enable Anti-Aliasing</param>
        public static void CreateViewportsAndCameras(
            GameObject mvrManagerGO)
        {
            MVRTools.Log(VRLogLevel.Debug, "[>] Starting to create viewports.");

            VRWindowMode realOutputMode = MVR.DisplayMgr.GetRealWindowMode();

            VRLogLevel logLevel = VRLogLevel.Critical;

            if (MVR.ClusterMgr.IsClient())
            {
                logLevel = VRLogLevel.Error;
            }

            SetupRenderToTexture();

            if (realOutputMode == VRWindowMode.Compositor &&
                SystemInfo.graphicsDeviceType != UnityEngine.Rendering.GraphicsDeviceType.Direct3D11 &&
                SystemInfo.graphicsDeviceType != UnityEngine.Rendering.GraphicsDeviceType.Direct3D12)
            {
                MVRTools.Log(logLevel, "[ ] Compositor is only supported with Direct3D11 or Direct3D12 Rendering. Switching to NativeWindow. Quad-buffer cameras will only show the left eye.");
                realOutputMode = VRWindowMode.NativeWindow;
            }

            var windowRect = new RectInt
            {
                x = MVR.DisplayMgr.GetWindowLeft(),
                y = MVR.DisplayMgr.GetWindowTop(),
                width = (int)MVR.DisplayMgr.GetWindowWidth(),
                height = (int)MVR.DisplayMgr.GetWindowHeight()
            };

            Compositor compositor = mvrManagerGO.GetComponent<Compositor>();
            if (compositor != null)
            {
                UnityEngine.Object.Destroy(compositor);
                compositor = null;
            }

            var vsync = GetVSync();
            QualitySettings.vSyncCount = vsync.unity ? 1 : 0;
            QualitySettings.antiAliasing = (int)MVR.DisplayMgr.GetAntiAliasing();

            if (realOutputMode == VRWindowMode.Compositor)
            {
                compositor = mvrManagerGO.AddComponent<Compositor>();
                compositor.ForceHDRRender = mvrManagerGO.GetComponent<MVRManagerScript>().advancedProperties.ForceCompositorHDRRender;

                var mvrMgr = mvrManagerGO.GetComponent<MVRManagerScript>();

                if (Application.isEditor)
                {
                    compositor.EditorConfigFile = mvrMgr.EditorConfigFile;

                    if (mvrMgr.clusterProperties.editorClusterDebuggingProperties.EnableEditorClusterDebugging)
                    {
                        compositor.EditorClusterId = mvrMgr.clusterProperties.editorClusterDebuggingProperties.EditorClusterID;
                    }
                }

                int AA = 1;
                int mvrAA = (int)MVR.DisplayMgr.GetAntiAliasing();

                if (mvrAA == 1 || mvrAA == 2 || mvrAA == 4 || mvrAA == 8)
                {
                    AA = mvrAA;
                }

                compositor.AntiAliasing = AA;

                switch (MVR.DisplayMgr.GetCompositorMode())
                {
                    case VRCompositorMode.Direct3D11:
                        compositor.Mode = Compositor.CompositorMode.Direct3D11;
                        break;
                    case VRCompositorMode.OpenGL:
                        compositor.Mode = Compositor.CompositorMode.OpenGL;
                        break;
                    default:
                        compositor.Mode = Compositor.CompositorMode.Auto;
                        break;
                }

                if (MVR.DisplayMgr.GetHDR())
                {
                    compositor.HDRMode = Compositor.CompositorHDRMode.HDR_FP16;
                }
                else
                {
                    compositor.HDRMode = Compositor.CompositorHDRMode.SDR;
                }
            }

            var viewportOutputOptions = new OutputConfiguration
            (
                outputMode: realOutputMode,
                quadBuffer: MVR.DisplayMgr.GetWindowQuadBuffer(),
                antiAliasing: (int)MVR.DisplayMgr.GetAntiAliasing(),
                compositor: compositor
            );

            SetupUnityWindow(realOutputMode, windowRect);


            List<vrViewport> viewportList;
            var clusterNode = MVR.ClusterMgr.GetMyClusterNode();
            if (clusterNode != null)
            {
                if (clusterNode.GetViewportsNb() == 0)
                {
                    MVRTools.Log(VRLogLevel.Error, $"[X] Couldn't find a viewport for my cluster node '{clusterNode.GetName()}'!");
                }
                viewportList = clusterNode.Viewports.ToList();
            }
            else
            {
                if (MVR.DisplayMgr.GetViewportsNb() == 0)
                {
                    MVRTools.Log(VRLogLevel.Error, $"[X] Couldn't find a viewport!");
                }
                viewportList = MVR.DisplayMgr.Viewports.ToList();
            }

            foreach (var viewport in viewportList)
            {
                CreateViewport(viewportOutputOptions, viewport, windowRect);
            }

            MVRTools.Log(3, "[<] End of viewport creation.");
        }

        private static void SetupRenderToTexture()
        {
            foreach (var cam in MVR.DisplayMgr.Cameras)
            {
                if (cam.GetRenderToTexture()) // && cam.GetRenderTextureGPUIndex() < 0)
                {
                    SetupRenderToTexture(cam);
                }
            }
        }

        private static void SetupRenderToTexture(vrCamera iMVRCamera)
        {
            bool enableThisCamera = false;

            List<vrViewport> viewportsList = new List<vrViewport>();

            if (MVR.ClusterMgr.IsClusterConfig())
            {
                // Only render cameras from our cluster node
                var clusterNode = MVR.ClusterMgr.GetMyClusterNode();

                if (clusterNode != null)
                {
                    viewportsList = clusterNode.Viewports.ToList();

                    foreach (var viewport in viewportsList)
                    {
                        if (viewport.GetCamera().GetId() == iMVRCamera.GetId())
                        {
                            MVRTools.Log($"[+] Enabling Camera Render Texture {iMVRCamera.GetName()} because viewport {viewport.GetName()} is on this cluster node");
                            enableThisCamera = true;
                            break;
                        }
                    }
                }
            }
            else
            {
                // If no cluster, enable all cameras
                enableThisCamera = true;
            }

            if (enableThisCamera)
            {
                Camera uCam = MVRNodesMapper.Instance.GetNode(iMVRCamera).GetComponent<Camera>();

                // testing if cam is null because with a camera stereo
                // the parent game object does not have a camera component
                if (uCam != null)
                {
                    int overscan = (int)MVRTools.GetMVRManager().GetOverscan();
                    int width = (int)iMVRCamera.GetRenderTextureWidth() + overscan * 2;
                    int height = (int)iMVRCamera.GetRenderTextureHeight() + overscan * 2;

                    RenderTextureFormat format = RenderTextureFormat.ARGB32;

                    if (MVRTools.GetMVRManager().advancedProperties.ForceCompositorHDRRender)
                    {
                        format = RenderTextureFormat.DefaultHDR;
                    }

                    var renderTexture = new RenderTexture(width, height, 32, format)
                    {
                        antiAliasing = (int)MVR.DisplayMgr.GetAntiAliasing(),
                        name = "RTT-" + iMVRCamera.GetName()
                    };

                    uCam.targetTexture = renderTexture;
                    uCam.enabled = true;
                }
            }
        }

        /*
        private static void SetupCopyTextureToViewport()
        {
            foreach (var vp in MVR.DisplayMgr.Viewports)
            {
                var cam = vp.GetRenderToTextureCamera();
                // If camera is rendering to a texture on the same GPU
                // (Otherwise use GPULink)
                if (cam != null && cam.GetRenderTextureGPUIndex() < 0)
                {
                    var uCamGO = MVRNodesMapper.Instance.GetNode(cam);
                    Camera uCam = uCamGO.GetComponent<Camera>();

                    var script = uCamGO.AddComponent<MVRCopyTextureToViewport>();

                    script.Texture = uCam.targetTexture;
                    script.ViewportName = vp.GetName();
                    script.SameFrame = true;

                    break;
                }
            }
        }*/

        /// <summary>
        /// Output configuration for this instance of Unity
        /// </summary>
        private class OutputConfiguration
        {
            public OutputConfiguration(VRWindowMode outputMode, bool quadBuffer, int antiAliasing, Compositor compositor)
            {
                OutputMode = outputMode;
                QuadBuffer = quadBuffer;
                AntiAliasing = antiAliasing;
                Compositor = compositor;
            }

            public readonly VRWindowMode OutputMode;
            public readonly bool QuadBuffer;
            public readonly int AntiAliasing;
            public readonly Compositor Compositor;
        }

        /// <summary>
        /// The target eye for a camera
        /// </summary>
        public enum Eye
        {
            /// <summary>
            /// Camera targets a normal (non-quadbuffer) output
            /// </summary>
            Mono,

            /// <summary>
            /// Camera targets the left eye on a quadbuffer output
            /// </summary>
            Left,

            /// <summary>
            /// Camera targets the right eye on a quadbuffer output
            /// </summary>
            Right
        }

        /// <summary>
        /// Orientation of a SideBySide (split) stereo viewport
        /// </summary>
        private enum SideBySideOrientation
        {
            None,
            Horizontal,
            Vertical
        }

        /// <summary>
        /// Compression of a SideBySide (split) stereo viewport
        /// </summary>
        private enum SideBySideCompression
        {
            Disabled,
            Enabled
        }

        /// <summary>
        /// Setups the Unity window size and fullscreen mode
        /// </summary>
        /// <param name="outputMode"></param>
        /// <param name="windowRect"></param>
        /// <param name="fullscreen"></param>
        private static void SetupUnityWindow(VRWindowMode outputMode, RectInt windowRect)
        {
            if (outputMode == VRWindowMode.Compositor)
            {
                // Using active stereo so we don't need to set the screen
                // resolution.
                if (!Application.isEditor)
                {
                    MVRTools.Log(VRLogLevel.Debug, "[ ] This output mode will create a new window, so hiding the Unity one.");
                    if(MVR.DisplayMgr.GetHideNativeWindow())
                    {
                        MVR.DisplayMgr.HideNativeWindow();
                    }
                    else
                    {
                        MVRTools.Log(VRLogLevel.Debug, "[ ] But HideNativeWindow is false, so not hiding it.");
                    }
                }
            }
            else // VRWindowMode.UnityWindow
            {
                var resolution = Screen.currentResolution;
#if UNITY_2022_3 || UNITY_2023_1_OR_NEWER
                MVRTools.Log(3, $"[ ] Current resolution: {resolution.width}x{resolution.height} ({resolution.refreshRateRatio}Hz).");
#else
                MVRTools.Log(3, $"[ ] Current resolution: {resolution.width}x{resolution.height} ({resolution.refreshRate}Hz).");
#endif

                MVRTools.Log(VRLogLevel.Debug, "[>] Starting listing of available screen resolutions.");
                foreach (var availableResol in Screen.resolutions)
                {
#if UNITY_2022_3 ||UNITY_2023_1_OR_NEWER
                    MVRTools.Log(VRLogLevel.Debug, $"[ ] {availableResol.width}x{availableResol.height} ({availableResol.refreshRateRatio}Hz).");
#else
                    MVRTools.Log(VRLogLevel.Debug, $"[ ] {availableResol.width}x{availableResol.height} ({availableResol.refreshRate}Hz).");
#endif
                }
                MVRTools.Log(VRLogLevel.Debug, "[<] End of available screen resolutions.");
                MVRTools.Log(VRLogLevel.Debug, $"[ ] Setting resolution to {windowRect.width}x{windowRect.height} {"in window mode"}.");

                Screen.SetResolution(windowRect.width, windowRect.height, false);
            }
        }

        private static (bool unity, bool viewportOutput) GetVSync()
        {
            if (MVR.ClusterMgr.IsServer() && MVR.ClusterMgr.GetServerUnityWindow())
            {
                MVR.Log(VRLogLevel.Info, "[ ] Unity: ServerUnityWindow: Disable VSync on Cluster Master.");
                return (unity: false, viewportOutput: false);
            }
            else if (!MVR.DisplayMgr.GetVSync())
            {
                MVR.Log(VRLogLevel.Info, "[ ] Unity: Disabling VSync.");
                return (unity: false, viewportOutput: false);
            }
            else if (MVR.DisplayMgr.GetRealWindowMode() != VRWindowMode.NativeWindow)
            {
                MVR.Log(VRLogLevel.Info, "[ ] Unity: Disabling VSync in Unity, it will be handled by the viewport output.");
                return (unity: false, viewportOutput: true);
            }
            else
            {
                MVR.Log(VRLogLevel.Info, "[ ] Unity: Enabling VSync.");
                return (unity: true, viewportOutput: true);
            }
        }

        /// <summary>
        /// Setups one viewport
        /// </summary>
        /// <param name="outputConfiguration">Current output configuration</param>
        /// <param name="viewport"></param>
        /// <param name="windowRect">Window output coordinates</param>
        private static void CreateViewport(
            [NotNull] OutputConfiguration outputConfiguration,
            [NotNull] vrViewport viewport,
            RectInt windowRect)
        {
            MVRTools.Log(VRLogLevel.Debug, $"[ ] Evaluating viewport '{viewport.GetName()}'.");

            var vpRect = new RectInt
            {
                x = viewport.GetLeft(),
                y = viewport.GetTop(),
                width = (int)viewport.GetWidth(),
                height = (int)viewport.GetHeight()
            };

            if (viewport.GetStereo() && viewport.GetStereoMode() == VRStereoMode.QuadBuffer)
            {
                CreateQuadBufferViewport(
                    outputConfiguration,
                    viewport,
                    vpRect,
                    windowRect);
            }
            else if (viewport.GetStereo() && viewport.GetStereoMode() == VRStereoMode.SideBySide)
            {
                CreateSideBySideViewport(
                    outputConfiguration,
                    viewport,
                    vpRect,
                    windowRect,
                    SideBySideOrientation.Horizontal,
                    viewport.GetCompressSideBySide() ? SideBySideCompression.Enabled : SideBySideCompression.Disabled);

            }
            else if (!viewport.GetStereo())
            {
                var camera = viewport.GetCamera();
                if (camera == null)
                {
                    MVRTools.Log(VRLogLevel.Error, $"[X] Couldn't find camera for viewport '{viewport.GetName()}'. Stopping setup of this viewport.");

                    return;
                }

                CreateMonoViewport(
                    outputConfiguration,
                    viewport,
                    camera,
                    vpRect,
                    windowRect);
            }
            else
            {
                MVRTools.Log(VRLogLevel.Error, $"[X] Invalid options for viewport '{viewport.GetName()}'. Stopping setup of this viewport.");
            }
        }

        /// <summary>
        /// Get the "Left" and "Right" cameras of any stereo viewport,
        /// taking into account custom stereo cameras and invert eyes parameters
        /// </summary>
        /// <param name="viewport">vrViewport reference</param>
        /// <returns>(LeftCamera, RightCamera)</returns>
        private static (vrCamera cameraLeft, vrCamera cameraRight) GetViewportStereoCameras([NotNull] vrViewport viewport)
        {
            vrCamera cameraLeft;
            vrCamera cameraRight;

            if (viewport.GetUseCustomStereoCameras())
            {
                cameraLeft = viewport.GetCustomLeftBufferCamera();
                cameraRight = viewport.GetCustomRightBufferCamera();
            }
            else
            {
                var camera = viewport.GetCamera();
                if (camera == null)
                {
                    MVRTools.Log(VRLogLevel.Error, "[X] Viewport using null camera. Viewport will be black.");
                    return (null, null);
                }

                var cameraStereo = camera as vrCameraStereo;
                if (cameraStereo == null)
                {
                    MVRTools.Log(VRLogLevel.Error, "[X] Stereo viewport using a non-stereo camera. Viewport will be black.");
                    return (null, null);
                }

                cameraLeft = cameraStereo.GetCameraLeft();
                cameraRight = cameraStereo.GetCameraRight();
            }

            if (viewport.GetStereoInvertEyes())
            {
                return (cameraRight, cameraLeft);
            }
            else
            {
                return (cameraLeft, cameraRight);
            }
        }

        /// <summary>
        /// Setups a mono viewport
        /// </summary>
        /// <param name="outputConfiguration">Current output configuration</param>
        /// <param name="camera"></param>
        /// <param name="vpRect"></param>
        /// <param name="windowRect"></param>
        private static void CreateMonoViewport(
            [NotNull] OutputConfiguration outputConfiguration,
            [NotNull] vrViewport viewport,
            [NotNull] vrCamera camera,
            RectInt vpRect,
            RectInt windowRect)
        {
            CreateViewportSingleEye(outputConfiguration, viewport, camera, vpRect, windowRect, Eye.Mono, SideBySideOrientation.None, SideBySideCompression.Disabled);
        }

        /// <summary>
        /// Setups a SideBySide viewport
        /// </summary>
        /// <param name="outputConfiguration">Current output configuration</param>
        /// <param name="viewport"></param>
        /// <param name="vpRect"></param>
        /// <param name="windowRect"></param>
        /// <param name="sideBySideOrientation"></param>
        /// <param name="sideBySideCompression"></param>
        private static void CreateSideBySideViewport(
            [NotNull] OutputConfiguration outputConfiguration,
            [NotNull] vrViewport viewport,
            RectInt vpRect,
            RectInt windowRect,
            SideBySideOrientation sideBySideOrientation,
            SideBySideCompression sideBySideCompression)
        {
            RectInt leftRect = vpRect;
            if (sideBySideOrientation == SideBySideOrientation.Horizontal)
            {
                leftRect.width = vpRect.width / 2;
            }
            else if (sideBySideOrientation == SideBySideOrientation.Vertical)
            {
                leftRect.height = vpRect.height / 2;
            }

            var (cameraLeft, cameraRight) = GetViewportStereoCameras(viewport);
            if (cameraLeft == null || cameraRight == null)
            {
                MVRTools.Log(VRLogLevel.Error, $"[X] Couldn't find cameras for viewport '{viewport.GetName()}'. Stopping setup of this viewport.");
                return;
            }

            var cameraComponentLeft = MVRNodesMapper.Instance.GetNode(cameraLeft).GetComponent<Camera>();
            CreateViewportSingleEye(outputConfiguration, viewport, cameraLeft, leftRect, windowRect, Eye.Mono, sideBySideOrientation, sideBySideCompression);

            RectInt rightRect = vpRect;
            if (sideBySideOrientation == SideBySideOrientation.Horizontal)
            {
                rightRect.x += vpRect.width / 2;
                rightRect.width = vpRect.width / 2;
            }
            else if (sideBySideOrientation == SideBySideOrientation.Vertical)
            {
                rightRect.y += vpRect.height / 2;
                rightRect.height = vpRect.height / 2;
            }

            var cameraComponentRight = MVRNodesMapper.Instance.GetNode(cameraRight).GetComponent<Camera>();
            CreateViewportSingleEye(outputConfiguration, viewport, cameraRight, rightRect, windowRect, Eye.Mono, sideBySideOrientation, sideBySideCompression);
        }

        /// <summary>
        /// Setups a QuadBuffer viewport
        /// </summary>
        /// <param name="outputConfiguration">Current output configuration</param>
        /// <param name="viewport"></param>
        /// <param name="windowRect"></param>
        private static void CreateQuadBufferViewport(
            [NotNull] OutputConfiguration outputConfiguration,
            [NotNull] vrViewport viewport,
            RectInt vpRect,
            RectInt windowRect)
        {
            var (cameraLeft, cameraRight) = GetViewportStereoCameras(viewport);
            if (cameraLeft == null || cameraRight == null)
            {
                MVRTools.Log(VRLogLevel.Error, $"[X] Couldn't find stereo cameras for viewport '{viewport.GetName()}'. Stopping setup of this viewport.");
                return;
            }

            CreateViewportSingleEye(outputConfiguration, viewport, cameraLeft, vpRect, windowRect, Eye.Left, SideBySideOrientation.None, SideBySideCompression.Disabled);
            CreateViewportSingleEye(outputConfiguration, viewport, cameraRight, vpRect, windowRect, Eye.Right, SideBySideOrientation.None, SideBySideCompression.Disabled);
        }

        /// <summary>
        /// Configure a Camera behaviour for a single eye vrCamera
        /// </summary>
        /// <param name="outputConfiguration">Current output configuration</param>
        /// <param name="vp">vrViewport instance</param>
        /// <param name="camera">vrCamera instance</param>
        /// <param name="vpRect">Viewport output rectangle (absolute coordinates)</param>
        /// <param name="windowRect">Window output rectangle (absolute coordinates)</param>
        /// <param name="eye">Target eye of the camera</param>
        /// <param name="sideBySideOrientation">Orientation of the SideBySide viewport</param>
        /// <param name="sideBySideCompression">Compression of the SideBySide viewport</param>
        private static void CreateViewportSingleEye(
            [NotNull] OutputConfiguration outputConfiguration,
            [NotNull] vrViewport vp,
            [NotNull] vrCamera camera,
            RectInt vpRect,
            RectInt windowRect,
            Eye eye,
            SideBySideOrientation sideBySideOrientation,
            SideBySideCompression sideBySideCompression)
        {
            var cameraComponent = MVRNodesMapper.Instance.GetNode(camera).GetComponent<Camera>();


            //
            // Check eye
            //

            // Unity is not capable of outputting stereo in its editor window so we only show the left eye
            if (outputConfiguration.OutputMode == VRWindowMode.NativeWindow && eye != Eye.Mono)
            {
                if (eye == Eye.Left)
                {
                    eye = Eye.Mono;
                }
                else if (eye == Eye.Right)
                {
                    MVRTools.Log(VRLogLevel.Warning, $"[~] Unity: Skipping setup of {camera.GetName()}: Right eye is not renderer in a Unity window.");
                    return;
                }
            }

            if (eye == Eye.Mono && outputConfiguration.QuadBuffer)
            {
                MVRTools.Log(VRLogLevel.Error, $"[X] {camera.GetName()}: Error. Trying to render a mono viewport in a quadbuffer window! Viewport will flicker.");
                CreateQuadBufferViewport(outputConfiguration, vp, vpRect, windowRect);
                return;
            }
            else if (eye != Eye.Mono && !outputConfiguration.QuadBuffer)
            {
                MVRTools.Log(VRLogLevel.Error, $"[X] {camera.GetName()}: Trying to render a quadbuffer viewport in a mono window! Viewport will be black.");
                return;
            }

            /*
            Rect renderRect;

            if (camera.GetRenderToTexture())
            {
                renderRect = new Rect
                {
                    x = 0,
                    y = 0,
                    width = 1,
                    height = 1
                };
            }
            else
            {
                renderRect = new Rect
                {
                    x = 0,
                    y = 0,
                    width = camera.GetRenderTextureWidth(),
                    height = camera.GetRenderTextureHeight()
                };
            }*/

            //
            // Set viewport coordinates
            //

            // Set Unity's camera rectangle or use camera's own aspect ratio otherwise.
            MVRTools.Log(VRLogLevel.Debug, $"[ ] Setting-up viewport for camera '{camera.GetName()}' ({vpRect.x},{vpRect.y})({vpRect.width}x{vpRect.height}).");

            if (outputConfiguration.OutputMode == VRWindowMode.NativeWindow)
            {
                var camRect = new Rect
                {
                    x = (float)(vpRect.x - windowRect.x) / (float)windowRect.width,
                    y = 1.0f - (float)(vpRect.y - windowRect.y + vpRect.height) / (float)windowRect.height,
                    width = (float)vpRect.width / (float)windowRect.width,
                    height = (float)vpRect.height / (float)windowRect.height
                };

                cameraComponent.rect = camRect;

                MVRTools.Log(VRLogLevel.Debug, $"[ ] Viewport normalized rect: ({camRect.x},{camRect.y})({camRect.width}x{camRect.height}).");
            }

            //
            // Set camera aspect ratio
            //

            float aspectRatio;

            if (camera.GetUseViewportAspectRatio())
            {
                aspectRatio = (float)vpRect.width / (float)vpRect.height;
                MVRTools.Log(VRLogLevel.Debug, $"[ ] Camera uses viewport aspect ratio: {aspectRatio}.");
            }
            else
            {
                aspectRatio = camera.GetAspectRatio();
                MVRTools.Log(VRLogLevel.Debug, $"[ ] Camera uses its own aspect ratio: {aspectRatio}.");
            }

            if (sideBySideCompression == SideBySideCompression.Enabled)
            {
                if (sideBySideOrientation == SideBySideOrientation.Horizontal)
                {
                    MVRTools.Log(VRLogLevel.Debug, "[ ] Compressed Side-by-Side (Horizontal).");
                    // Side-by-side will be displayed on only one display but
                    // will be stretched (scaled) by the system.
                    aspectRatio *= 2.0f;
                }
                if (sideBySideOrientation == SideBySideOrientation.Vertical)
                {
                    MVRTools.Log(VRLogLevel.Debug, "[ ] Compressed Side-by-Side (Vertical).");
                    // Side-by-side will be displayed on only one display but
                    // will be stretched (scaled) by the system.
                    aspectRatio /= 2.0f;
                }
                else
                {
                    MVRTools.Log(VRLogLevel.Debug, "[ ] Uncompressed Side-by-Side.");
                }
            }

            camera.SetAspectRatio(aspectRatio);

            //
            // Handle viewport output
            //

           if (outputConfiguration.OutputMode == VRWindowMode.Compositor)
           {
                /*
                if (vp != null && vp.GetRenderToTexture())
                {
                    MVRTools.Log(VRLogLevel.Debug, $"[ ] Don't add camera {camera.GetName()} to compositor because it will RenderToTexture.");
                }
                else*/
                {
                    outputConfiguration.Compositor.Viewports.Add(new Compositor.ViewportInfo { MVRViewport = vp, MVRCamera = camera, Camera = cameraComponent, Rect = vpRect, Eye = eye });
                }
            }

            if (vp.GetCornerOffsetBottomLeftX() != 0 || vp.GetCornerOffsetBottomLeftY() != 0 ||
                vp.GetCornerOffsetBottomRightX() != 0 || vp.GetCornerOffsetBottomRightY() != 0 ||
                vp.GetCornerOffsetTopLeftX() != 0 || vp.GetCornerOffsetTopLeftY() != 0 ||
                vp.GetCornerOffsetTopRightX() != 0 || vp.GetCornerOffsetTopRightY() != 0)
            {
                SetupProjectiveTransform(vp, cameraComponent);
            }

            //
            // Finally, enable the camera
            //

            if (MVR.DisplayMgr.IsRenderingDisabled())
            {
                Log("Rendering disabled, disabling camera component");
                cameraComponent.enabled = false;
            }
            else
            {
                cameraComponent.enabled = true;
            }
        }

        private static void SetupProjectiveTransform(vrViewport vp, Camera cameraComponent)
        {
            var script = cameraComponent.gameObject.AddComponent<MVRProjectiveTransform>();
            script.SetViewport(vp);
        }

#endregion
    }
}
