/* MVRTools
 * MiddleVR
 * (c) MiddleVR
 */

using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;

namespace MiddleVR.Unity
{
    public partial class MVRTools
    {
        #region Nodes setup
        /// <summary>
        /// Create GameObjects with appropriate behaviours for every vrNode3D in the current configuration
        /// </summary>
        /// <param name="rootGameObject">Root GameObject</param>
        /// <param name="templateCameraObject">Template GameObject/Prefab for cameras</param>
        public static void CreateNodes(
            [NotNull] GameObject rootGameObject,
            GameObject templateCameraObject,
            bool showSceneOnScreens,
            bool disengageUntrackedNodes)
        {
            MVRTools.Log(VRLogLevel.Debug, "[>] Creating " + MVR.DisplayMgr.GetNodesNb() + " nodes.");

            // Clean nodes cache before creating new ones
            MVRNodesMapper.Instance.ClearMappings();

            foreach (var node in MVR.DisplayMgr.GetRootNode().Children)
            {
                CreateNode(node,
                           rootGameObject,
                           templateCameraObject,
                           showSceneOnScreens,
                           disengageUntrackedNodes);
            }

            // Force update of all nodes, even those without a tracker
            MVRNodesMapper.Instance.UpdateNodesMiddleVRToUnity(true);

            MVRTools.Log(VRLogLevel.Debug, "[<] End of node creation.");
        }

        /// <summary>
        /// Recursively create a node and its children under a parent GameObject
        /// </summary>
        /// <param name="node">Instance of vrNode3D</param>
        /// <param name="parentGameObject">Parent GameObject</param>
        /// <param name="templateCameraObject">Template GameObject/Prefab for cameras</param>
        private static void CreateNode(
            [NotNull] vrNode3D node,
            [NotNull] GameObject parentGameObject,
            GameObject templateCameraObject,
            bool showSceneOnScreens,
            bool disengageUntrackedNodes)
        {
            var nodeName = node.GetName();

            //
            // GameObject creation
            //

            GameObject nodeGameObject = null;

            // 2- Create a camera
            if (nodeGameObject == null && node is vrCamera && !(node is vrCameraStereo) && templateCameraObject != null)
            {
                nodeGameObject = CreateCameraInstanceFromTemplate(nodeName, templateCameraObject);
            }

            // 3- Create an empty GameObject
            if (nodeGameObject == null)
            {
                nodeGameObject = new GameObject(nodeName);
            }

            //
            // Setup node according to its type
            //

            MVRTools.Log(VRLogLevel.Debug, $"[+] Creating '{nodeName}' [{node.GetType()}]");

            if (node is vrCamera camera && !(node is vrCameraStereo))
            {
                SetupCamera(camera, nodeGameObject, showSceneOnScreens);
            }

            if(node is vrMesh mesh)
            {
                SetupMesh(mesh, nodeGameObject);
            }

            if(node is vrWarper warper)
            {
                SetupWarper(warper, nodeGameObject);
            }

            //
            // Register node in mapping
            //

            nodeGameObject.transform.parent = parentGameObject.transform;
            MVRNodesMapper.Instance.CreateMapping(nodeGameObject, node);

            if(disengageUntrackedNodes && node.GetTracker() == null)
            {
                MVRNodesMapper.Instance.SetManualUpdate(nodeGameObject);
            }

            //
            // Recurse through children
            //

            foreach (var child in node.Children)
            {
                CreateNode(child,
                           nodeGameObject,
                           templateCameraObject,
                           showSceneOnScreens,
                           disengageUntrackedNodes);
            }
        }

        private static GameObject CreateCameraInstanceFromTemplate([NotNull] string name, [NotNull] GameObject templateCamera)
        {
            MVRTools.Log(VRLogLevel.Debug, $"[ ] Unity: Creating camera '{name}' using template camera '{templateCamera.name}'.");

            var cameraGameObject = UnityEngine.Object.Instantiate(templateCamera) as GameObject;
            cameraGameObject.SetActive(true);
            cameraGameObject.name = name;

            var cinemachineBrain = cameraGameObject.GetComponent("CinemachineBrain");
            if(cinemachineBrain != null)
            {
                MonoBehaviour.Destroy(cinemachineBrain);
            }

            return cameraGameObject;
        }

        private static void SetupWarper([NotNull] vrWarper warper, [NotNull] GameObject warperGameObject)
        {

            if (warper.GetWarpingType() == VRWarpingType.Mesh)
            {
                /*
                var script = warperGameObject.AddComponent<MVRWarperMesh>();
                script.SetMVRWarper(warper);
                */
                // XXX display mesh & texture according to mvrmanager property
            }
        }

        private static void SetupMesh([NotNull] vrMesh vrmesh, [NotNull] GameObject meshGameObject)
        {
            var meshRenderer = meshGameObject.AddComponent<MeshRenderer>();
            var meshFilter = meshGameObject.AddComponent<MeshFilter>();
            var mesh = new Mesh();

            Vector3[] vertices = new Vector3[vrmesh.GetVertexNb()];
            Vector2[] uvs = new Vector2[vrmesh.GetVertexNb()];
            Vector3[] normals = new Vector3[vrmesh.GetVertexNb()];

            int vtxNb = vertices.Length;

            for (uint vIdx = 0; vIdx < vtxNb; vIdx++)
            {
                vrVec3 vrvtx = vrmesh.GetVertex(vIdx);
                Vector3 uvtx = new Vector3(vrvtx.x, vrvtx.z, vrvtx.y);
                vertices[vIdx] = uvtx;

                if (vrmesh.GetUVNb() > 0)
                {
                    vrVec2 vruv = vrmesh.GetUV(vIdx);
                    Vector2 uv = new Vector2(vruv.x, vruv.y);
                    uvs[vIdx] = uv;
                }

                if(vrmesh.GetNormalsNb() > 0)
                {
                    vrVec3 vrnorm = vrmesh.GetNormal(vIdx);
                    Vector3 unorm = new Vector3(vrnorm.x, vrnorm.z, vrnorm.y);
                    normals[vIdx] = unorm;
                }
            }

            mesh.vertices = vertices;
            mesh.uv = uvs;
            mesh.normals = normals;

            int[] triangles = new int[vrmesh.GetTrianglesIndexNb()];
            int tNb = triangles.Length;

            for (uint tIdx = 0; tIdx < tNb; tIdx += 3)
            {
                // Change triangle winding
                triangles[tIdx + 2] = (int)vrmesh.GetTrianglesIndex(tIdx);
                triangles[tIdx + 1] = (int)vrmesh.GetTrianglesIndex(tIdx + 1);
                triangles[tIdx] = (int)vrmesh.GetTrianglesIndex(tIdx + 2);
            }

            mesh.triangles = triangles;

            meshFilter.mesh = mesh;

            MeshRenderer mr = meshGameObject.GetComponent<MeshRenderer>();
            mr.material = new Material(Shader.Find("Diffuse"));

            // By default don't show the mesh
            mr.enabled = false;
        }

        private static void SetupCamera([NotNull] vrCamera mvrCamera, [NotNull] GameObject cameraGameObject, bool showSceneOnScreens)
        {
            // Ensure the GameObject has a Camera component
            var cameraComponent = cameraGameObject.GetComponent<Camera>();
            if (cameraComponent == null)
                cameraComponent = cameraGameObject.AddComponent<Camera>();

            MVRTools.Log(VRLogLevel.Debug, $"[ ] Camera '{cameraGameObject.name}' rendering path: {cameraComponent.actualRenderingPath}.");

#if UNITY_2022_3 || UNITY_2023_1_OR_NEWER
            if (MVR.DisplayMgr.GetAntiAliasing() >= 2 && cameraComponent.actualRenderingPath == RenderingPath.DeferredShading)
#else
            if (MVR.DisplayMgr.GetAntiAliasing() >= 2 && cameraComponent.actualRenderingPath == RenderingPath.DeferredLighting)
#endif
            {
                MVRTools.Log(VRLogLevel.Warning, "[~] Anti-Aliasing is enabled but currently does not work in deferred rendering mode.");
            }

            mvrCamera.SetFrustumNear(cameraComponent.nearClipPlane);
            mvrCamera.SetFrustumFar(cameraComponent.farClipPlane);

            cameraComponent.fieldOfView = mvrCamera.GetVerticalFov();

            // By default all cameras are deactivated until the viewports are created
            if (MVR.DisplayMgr.GetViewportsNb() > 0)
            {
                cameraComponent.enabled = false;
            }
            else
            {
                MVRTools.Log(VRLogLevel.Info, "[ ] No viewport defined, so enabling all MiddleVR cameras. You will probably only see the last camera defined.");
            }

            if(mvrCamera.IsICVFX())
            {
                // An ICVFX camera must be enabled on all nodes
                // XXX except nodes where it is disabled
                var script = cameraGameObject.AddComponent<MVRICVFXRender>();
                cameraComponent.enabled = true;
            }

            vrWarper warper = mvrCamera.GetWarper();

            if (warper != null
                && ( warper.GetWarpingType() == VRWarpingType.Mesh || warper.GetWarpingType() == VRWarpingType.MPCDI ))
            {
                var script = cameraGameObject.AddComponent<MVRWarperMesh>();
                script.ShowSceneOnScreens = showSceneOnScreens;
            }
        }

#endregion
    }
} // namespace MiddleVR.Unity
