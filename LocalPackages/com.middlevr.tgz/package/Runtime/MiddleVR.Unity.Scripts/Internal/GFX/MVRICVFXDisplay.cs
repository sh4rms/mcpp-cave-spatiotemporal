﻿using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using System.Collections.Generic;
using UnityEngine.Rendering;

public class MVRICVFXDisplay : MonoBehaviour
{
#pragma warning disable IDE1006 // Naming Styles
    private Camera _ICVFXCamera = null;
#pragma warning restore IDE1006 // Naming Styles
    private vrCamera _mvrICVFXCamera = null;

    private GameObject _backgroundCameraGO = null;
    private Camera _backgroundCamera = null;
    private vrCamera _mvrBackgroundCamera = null;
    private vrWarper _warper = null;

    private Camera _thisCamera = null;

    private GameObject _quad = null;

    private RenderTexture _backgroundTex = null;
    private Material _compositingMat = null;

    private GameObject _mvrManager = null;

#if MVR_HDRP && !UNITY_2019_4
    void OnEnable()
    {
        UnityEngine.Rendering.RenderPipelineManager.beginCameraRendering += BeginCameraRendering;
        UnityEngine.Rendering.RenderPipelineManager.endCameraRendering += EndCameraRendering;
        UnityEngine.Rendering.RenderPipelineManager.endContextRendering += EndContextRendering;
    }

    void OnDisable()
    {
        UnityEngine.Rendering.RenderPipelineManager.beginCameraRendering -= BeginCameraRendering;
        UnityEngine.Rendering.RenderPipelineManager.endCameraRendering -= EndCameraRendering;
        UnityEngine.Rendering.RenderPipelineManager.endContextRendering -= EndContextRendering;
    }

    private void BeginCameraRendering(ScriptableRenderContext context, Camera camera)
    {
        if (_thisCamera == camera)
        {
            OnPreCull();
        }
    }

    private void EndCameraRendering(ScriptableRenderContext context, Camera camera)
    {
        if (_thisCamera == camera)
        {
            Graphics.Blit(_backgroundCamera.targetTexture, _backgroundTex);

            _compositingMat.SetTexture("_ColorMap", _thisCamera.targetTexture);
            _compositingMat.SetTexture("_BackgroundTex", _backgroundTex);
            Graphics.Blit(_thisCamera.targetTexture, _backgroundCamera.targetTexture, _compositingMat);

            //Graphics.Blit(_thisCamera.targetTexture, _backgroundCamera.targetTexture);
        }
    }

    void EndContextRendering(ScriptableRenderContext context, List<Camera> cameras)
    {
        foreach (var camera in cameras)
        {
            // Blit to screen

            var script = camera.GetComponent<MVRICVFXDisplay>();

            if(script != null)
            {
                //RenderTexture thisRT = Camera.main.targetTexture;
                //_thisCamera.targetTexture = null;
                //Graphics.Blit(script._backgroundCamera.targetTexture, (RenderTexture)null);
                //Debug.Log("Blitting : " + script._backgroundCamera.name);
                //Camera.main.targetTexture = thisRT;
            }
        }
    }
#endif

    private void OnPreCull()
    {
        _quad.GetComponent<Renderer>().enabled = true;
    }

    private void OnRenderImage(RenderTexture src, RenderTexture dest)
    {
        _quad.GetComponent<Renderer>().enabled = false;

        Graphics.Blit(_backgroundCamera.targetTexture, _backgroundTex);

        _compositingMat.SetTexture("_ColorMap", src);
        _compositingMat.SetTexture("_BackgroundTex", _backgroundTex);
        Graphics.Blit(src, _backgroundCamera.targetTexture, _compositingMat);

        // Blit to screen
        RenderTexture thisRT = Camera.main.targetTexture;
        _thisCamera.targetTexture = null;
        Graphics.Blit(_backgroundCamera.targetTexture, (RenderTexture)null);
        Camera.main.targetTexture = thisRT;

        //Graphics.Blit(src, dest);
    }

    public void SetReferences(GameObject iQuad, vrCamera iOrigCamera, vrCamera iICVFXCamera)
    {
        _quad = iQuad;

        _mvrBackgroundCamera = iOrigCamera;
        _mvrICVFXCamera = iICVFXCamera;

        _ICVFXCamera = MVRNodesMapper.Instance.GetNode(_mvrICVFXCamera).GetComponent<Camera>();
        _backgroundCameraGO = MVRNodesMapper.Instance.GetNode(_mvrBackgroundCamera);
        _backgroundCamera = _backgroundCameraGO.GetComponent<Camera>();
    }

    void Start()
    {
        SetupThisCamera();
        SetupWarping();

        _mvrManager = GameObject.Find("MVRManager");

#if MVR_HDRP
        _compositingMat = new Material(Shader.Find("MVR/Compositing_HDRP"));
#else
        _compositingMat = new Material(Shader.Find("MVR/Compositing"));
#endif
    }

    private void SetupWarping()
    {
        var origWarpScript = _backgroundCameraGO.GetComponent<MVRWarperMesh>();
        if (origWarpScript != null)
        {
            var newWarpScript = this.GetComponent<MVRWarperMesh>();
            newWarpScript.ICVFXFrom(origWarpScript);

#if MVR_HDRP
            newWarpScript.GetWarperMeshGO().GetComponent<Renderer>().material.SetTexture("_ColorMap", _backgroundCamera.targetTexture);
#else
            newWarpScript.GetWarperMeshGO().GetComponent<Renderer>().material.SetTexture("_MainTex", _backgroundCamera.targetTexture);
#endif
        }
    }

    private void SetupThisCamera()
    {
        _thisCamera = GetComponent<Camera>();

        if (GetComponent<MVRWarperMesh>() != null)
        {
            _warper = GetComponent<MVRWarperMesh>().GetWarper();
        }

        _thisCamera.transform.parent = _ICVFXCamera.transform;

        _thisCamera.transform.localPosition = Vector3.zero;
        _thisCamera.transform.localRotation = Quaternion.identity;

        // Render only ICVFX frustum
        _thisCamera.cullingMask = MVRTools.GetScreensLayerMask();

        // Set a clear background so that the warping shader
        // can blend the warped quad and the background
        // Will be overriden in HDRP in MVR_HDRPSettings
        //_thisCamera.clearFlags = CameraClearFlags.Nothing;
        _thisCamera.clearFlags = CameraClearFlags.Color;
        _thisCamera.backgroundColor = new Color(0, 0, 0, 0);

        // Fog will also be overriden to off in MVR_HDRPSettings

        // Render after ICVFX camera & background cameras
        _thisCamera.depth = _ICVFXCamera.depth + 1;

        uint width = 1920;
        uint height = 1200;

        if(_mvrBackgroundCamera.GetViewport() != null)
        {
            width = _mvrBackgroundCamera.GetViewport().GetWidth();
            height = _mvrBackgroundCamera.GetViewport().GetHeight();
        }

        if (_backgroundCamera.targetTexture == null)
        {
            _backgroundCamera.targetTexture = new RenderTexture((int)width, (int)height, 32) { name = $"{_backgroundCamera.name}-{width}x{height}" };
        }

        _thisCamera.targetTexture = new RenderTexture((int)width, (int)height, 32) { name = $"{_thisCamera.name}-{width}x{height}" };

        _backgroundTex = new RenderTexture((int)width, (int)height, 32) { name = $"{_thisCamera.name}-Background-{width}x{height}" };
    }

    void Update()
    {
        vrVec3 bakPos = _mvrBackgroundCamera.GetPositionWorld();
        vrQuat bakRot = _mvrBackgroundCamera.GetOrientationWorld();

        _mvrBackgroundCamera.SetPositionWorld(_mvrICVFXCamera.GetPositionWorld());
        //_mvrBackgroundCamera.Update();

        if (_warper == null)
        {
            if (GetComponent<MVRWarperMesh>() != null)
            {
                _warper = GetComponent<MVRWarperMesh>().GetWarper();
            }
        }

        if(_warper != null)
        {
            //Update warper screen
            _warper.UpdateCamera(_mvrBackgroundCamera);

            // force orientation so that camera always faces the warper
            transform.rotation = _mvrBackgroundCamera.GetOrientationWorld().ToUnity() * _mvrManager.transform.rotation;

            //Frustum
            MVRTools.UpdateCameraProperties(_mvrBackgroundCamera, _thisCamera);

            _mvrBackgroundCamera.SetPositionWorld(bakPos);

            // Restore warper screen
            _warper.UpdateCamera(_mvrBackgroundCamera);
        }
    }
}
