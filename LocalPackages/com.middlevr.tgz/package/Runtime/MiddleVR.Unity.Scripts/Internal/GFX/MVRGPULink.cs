﻿/* MVRGPULink
 * MiddleVR
 * (c) MiddleVR
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using System.Runtime.InteropServices;
using MiddleVR;
using MiddleVR.Unity;
using System.IO;

public class MVRGPULink : MonoBehaviour
{
    public class OffscreenCameraClient
    {
        public Camera Camera;
        public Texture2D SharedTexture;
        public RenderTexture RT;
    }

    public class OffscreenCameraServer
    {
        public vrCamera MVRCamera;
        public vrViewport OffscreenViewport;

        public Camera Camera;
        public Texture2D SharedTexture;
    }

    // This is the list of all offscreen cameras after they have been transfered to the server
    public Dictionary<string, OffscreenCameraServer> ServerOffscreenCameras = null;
    private List<OffscreenCameraClient> _clientOffscreenCameras = null;

    private Coroutine _waitForEndOfFrameCoroutine = null;
    private readonly WaitForEndOfFrame _waitForEndOfFrame = new WaitForEndOfFrame();

    private Camera GetCameraFromVRCamera(vrCamera iVRCam)
    {
        var go = MVRNodesMapper.Instance.GetNode(iVRCam);

        if (go != null)
        {
            return go.GetComponent<Camera>();
        }

        return null;
    }

    void SetupClientOffscreenCameras()
    {
        _clientOffscreenCameras = new List<OffscreenCameraClient>();

        // For this client, list all cameras/viewports that are offscreen
        List<vrViewport> viewportsList = new List<vrViewport>();

        if (MVR.ClusterMgr.IsClusterConfig())
        {
            var clusterNode = MVR.ClusterMgr.GetMyClusterNode();

            if (clusterNode != null)
            {
                viewportsList = clusterNode.Viewports.ToList();
            }
        }
        else
        {
            viewportsList = MVR.DisplayMgr.Viewports.ToList();
        }

        foreach (var vp in viewportsList)
        {
            // Create the shared textures
            if (vp.GetRenderToTexture())
            {
                OffscreenCameraClient offCam = new OffscreenCameraClient();

                vrCamera vrcam = vp.GetCamera();
                Camera cam = GetCameraFromVRCamera(vrcam);

                offCam.Camera = cam;

                // Override the rect of this camera because we want it to render
                // to the full size of the rendertarget, which has the size of the viewport
                cam.rect = new Rect(0, 0, 1, 1);

                // Create shared SharedTexture on the client GPU
                Texture2D texture = Texture2D.CreateExternalTexture(
                    (int)vp.GetWidth(), (int)vp.GetHeight(),
                    TextureFormat.RGBA32,
                    false,
                    false,
                    CreateSharedTexture(cam.name, vp.GetWidth(), vp.GetHeight(), vp.GetRenderTextureGPUIndex()));

                offCam.SharedTexture = texture;

                // Render to a texture
                var renderTexture = new RenderTexture((int)vp.GetWidth(), (int)vp.GetHeight(), 0, RenderTextureFormat.ARGB32)
                {
                    antiAliasing = (int)MVR.DisplayMgr.GetAntiAliasing()
                };

                cam.targetTexture = renderTexture;

                // Intermediate render texture to copy the texture from the camera
                var desc = renderTexture.descriptor;
                desc.msaaSamples = 1;
                offCam.RT = new RenderTexture(desc);
                offCam.RT.Create();

                // Add to dict
                _clientOffscreenCameras.Add(offCam);
            }
        }
    }

    void SetupServerOffscreenCameras()
    {
        foreach(var vp in MVR.DisplayMgr.Viewports)
        {
            var mvrcam = vp.GetRenderToTextureCamera();
            if(mvrcam != null)
            {
                var go = MVRNodesMapper.Instance.GetNode(vp.GetCamera());
                var script = go.AddComponent<MVRGPULinkBlit>();
                script.Init(mvrcam);
            }
        }
    }

    void Start()
    {
#if UNITY_2023_1_OR_NEWER
        MVRManagerPostFrameScript mvr = UnityEngine.Object.FindFirstObjectByType<MVRManagerPostFrameScript>();
#else
        MVRManagerPostFrameScript mvr = UnityEngine.Object.FindObjectOfType<MVRManagerPostFrameScript>();
#endif
        if (mvr != null)
        {
            mvr.AddPostFrameListener(this.ExtractSharedTextures);
        }

        SetupClientOffscreenCameras();
        SetupServerOffscreenCameras();

        _waitForEndOfFrameCoroutine = StartCoroutine(WaitForEndOfFrameCoroutine());
    }

    private void OnDisable()
    {
        if (_waitForEndOfFrameCoroutine != null)
        {
            StopCoroutine(_waitForEndOfFrameCoroutine);
            _waitForEndOfFrameCoroutine = null;
        }

        CleanSharedTextures();
    }

    private IEnumerator WaitForEndOfFrameCoroutine()
    {
        while (true)
        {
            yield return _waitForEndOfFrame;
            OnEndOfFrame();
        }
    }

    private void OnEndOfFrame()
    {
        RenderCameras();
    }

    private void RenderCameras()
    {
        foreach (var offCam in _clientOffscreenCameras)
        {
            offCam.Camera.targetTexture.ResolveAntiAliasedSurface(offCam.RT);
            Graphics.CopyTexture(offCam.RT, 0, offCam.SharedTexture, 0);
        }
    }

    /// <summary>
    /// Called by MVRManagerPostFrameScript::PostFrameUpdate
    /// after soft swaplock
    /// 
    /// </summary>
    public void ExtractSharedTextures()
    {
        // Execute on the server GPU only
        // XXX server GPU can be a cluster client
        if (!MVR.ClusterMgr.IsClusterConfig()
            || MVR.ClusterMgr.IsServer())
        {
            foreach (var vp in MVR.DisplayMgr.Viewports.ToList())
            {
                // For all offscreen viewports, create the server side structure
                if (vp.GetRenderToTexture())
                {
                    OffscreenCameraServer offCam = null;

                    vrCamera vrcam = vp.GetCamera();

                    if (ServerOffscreenCameras == null)
                    {
                        ServerOffscreenCameras = new Dictionary<string, OffscreenCameraServer>();
                    }
                    else
                    {
                        ServerOffscreenCameras.TryGetValue(vrcam.GetName(), out offCam);
                    }

                    if (offCam == null)
                    {
                        offCam = new OffscreenCameraServer();

                        offCam.Camera = GetCameraFromVRCamera(vrcam);
                        offCam.MVRCamera = vrcam;
                        offCam.OffscreenViewport = vp;

                        // Add to list
                        ServerOffscreenCameras.Add(vrcam.GetName(), offCam);

                        // Open shared texture from client GPU
                        Texture2D texture = Texture2D.CreateExternalTexture(
                            (int)vp.GetWidth(), (int)vp.GetHeight(),
                            TextureFormat.RGBA32,
                            false,
                            false,
                            OpenSharedTexture(vrcam.GetName(), vp.GetWidth(), vp.GetHeight(), vp.GetRenderTextureGPUIndex()));

                        offCam.SharedTexture = texture;
                    }
                }
            }

            ExtractAllSharedTextures();
        }
    }

#region Plugin Bindings
    private const string PluginName = "MiddleVR_UnityRendering";

    [DllImport(PluginName, CallingConvention = CallingConvention.StdCall)]
    private static extern IntPtr CreateSharedTexture(
            [MarshalAs(UnmanagedType.LPWStr)] string name,
            uint width,
            uint height,
            int gpuIndex);

    [DllImport(PluginName, CallingConvention = CallingConvention.StdCall)]
    private static extern IntPtr OpenSharedTexture(
            [MarshalAs(UnmanagedType.LPWStr)] string name,
            uint width,
            uint height,
            int gpuIndex);

    [DllImport(PluginName, CallingConvention = CallingConvention.StdCall)]
    private static extern IntPtr GetExtractAllSharedTexturesCallback();

    private static void ExtractAllSharedTextures()
    {
        GL.IssuePluginEvent(GetExtractAllSharedTexturesCallback(), 0);
    }

    [DllImport(PluginName, CallingConvention = CallingConvention.StdCall)]
    private static extern IntPtr GetCleanSharedTexturesCallback();

    private static void CleanSharedTextures()
    {
        GL.IssuePluginEvent(GetCleanSharedTexturesCallback(), 0);
    }

#endregion
}
