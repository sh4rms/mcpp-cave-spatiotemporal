using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.Rendering;

public class MVRDecoder
{
    [StructLayout(LayoutKind.Sequential), Serializable]
    public struct DecodeData
    {
        [MarshalAs(UnmanagedType.I4)]
        public int Id;

        public IntPtr Data;

        [MarshalAs(UnmanagedType.I4)]
        public int Size;
    }

    DecodeData _decData = new DecodeData();

    public int Id { get; private set; } = -1;

    public void Create(Texture tex)
    {
        Id = Lib.Create(tex);
    }

    public void SetCodec(MVREncoder.Codec iCodec)
    {
        Lib.DecoderSetCodec(Id, (int)iCodec);
    }

    public void Destroy()
    {
        Lib.DecoderDestroy(Id);
    }

    public bool Decode(IntPtr data, int size)
    {
        _decData = new DecodeData
        {
            Id = Id,
            Data = data,
            Size = size
        };

        Lib.Decode(_decData);

        return true;
    }

    public void CopyTexture()
    {
        Lib.CopyTexture(Id);
    }

    public static class Lib
    {
        public const string DllName = "MiddleVR_UnityRendering";

        static IntPtr s_decDataPtr;
        // ---

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        private static extern int DecoderCreate(System.IntPtr tex);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern void DecoderSetCodec(int id, int codec);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int DecoderDestroy(int id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern bool DecoderIsValid(int id);

        //[DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        //public static extern int DecoderDecode(int id, IntPtr data, int size);

        public static int Create(Texture tex)
        {
            IntPtr texPtr = tex.GetNativeTexturePtr();
            var id = DecoderCreate(texPtr);

            s_decDataPtr = IntPtr.Zero;

            return id;
        }

        public static void Decode(DecodeData data)
        {
            if (s_decDataPtr != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(s_decDataPtr);
            }

            s_decDataPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DecodeData)));
            Marshal.StructureToPtr(data, s_decDataPtr, false);

            var cmdBuf = new CommandBuffer();
            cmdBuf.IssuePluginEventAndData(
                DecoderDecodeCallback(),
                0,
                s_decDataPtr
                );
            Graphics.ExecuteCommandBuffer(cmdBuf);
        }

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr DecoderDecodeCallback();

        public static void CopyTexture(int id)
        {
            var cmdBuf = new CommandBuffer();
            cmdBuf.IssuePluginEventAndData(
                DecoderCopyTextureCallback(),
                id,
                IntPtr.Zero
                );
            Graphics.ExecuteCommandBuffer(cmdBuf);
        }

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr DecoderCopyTextureCallback();
    }
}
