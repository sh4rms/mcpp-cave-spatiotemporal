﻿/* MVRCompositor
 * MiddleVR
 * (c) MiddleVR
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Rendering;

namespace MiddleVR.Unity
{
    public class Compositor : MonoBehaviour
    {
        public List<ViewportInfo> Viewports = new List<ViewportInfo>();

        [Serializable]
        public class ViewportInfo
        {
            public vrViewport MVRViewport;
            public vrCamera MVRCamera;
            public Camera Camera;
            public RectInt Rect;
            public MiddleVR.Unity.MVRTools.Eye Eye;
        }

        enum WarpingType
        {
            None,
            Vioso,
            ScalableDisplay
        }

        public int AntiAliasing = 1;
        public CompositorMode Mode = CompositorMode.Auto;
        public CompositorHDRMode HDRMode = CompositorHDRMode.SDR;
        public bool ForceHDRRender = false;
        public string EditorConfigFile;
        public string EditorClusterId;

        private class RegisteredViewport
        {
            public vrViewport MVRViewport;
            public vrCamera MVRCamera;
            public Camera Camera;
            public MiddleVR.Unity.MVRTools.Eye Eye;
            public RectInt Rect;
            public Texture2D Surface;
            public Texture2D SurfaceHDR;
            public RenderTexture RTRGB;
            public RenderTexture RT;
        }

        private readonly List<RegisteredViewport> _registeredViewports= new List<RegisteredViewport>();

        private Coroutine _waitForEndOfFrameCoroutine = null;
        private readonly WaitForEndOfFrame _waitForEndOfFrame = new WaitForEndOfFrame();

        private Material _hdrToRGBMaterial;

        private void Start()
        {
            if (!IsRendererSupported())
            {
                Debug.LogError("MvrCompositor only supports Direct3D11 or Direct3D12");
                return;
            }

            ResetCompositor();

            MVR.Log(2, "[ ] MVR: Final Overscan = " + MVR.DisplayMgr.GetOverscan());

            if (ViewportsListHasChanged())
            {
                ClearRegisteredViewports();
                CreateRegisteredViewports();
            }

            CreateCompositor(
                editorCfg: EditorConfigFile,
                editorClusterId: EditorClusterId,
                viewports: this._registeredViewports,
                hdrMode: HDRMode,
                mode: Mode);

            if (!WaitCompositor())
                throw new InvalidOperationException("Could not start MiddleVR Compositor! Please check MiddleVR logs.");

            CreateRegisteredCamerasSurfaces();

            _waitForEndOfFrameCoroutine = StartCoroutine(WaitForEndOfFrameCoroutine());

#if MVR_HDRP
            ForceHDRRender = false;
#endif
#if MVR_URP
            _hdrToRGBMaterial = new Material(Shader.Find("MVR/HDRToRGBA"));
#endif
        }

        private void OnDisable()
        {
            if (!IsRendererSupported())
                return;

            ClearRegisteredViewports();

            DestroyCompositor();

            if (_waitForEndOfFrameCoroutine != null)
            {
                StopCoroutine(_waitForEndOfFrameCoroutine);
                _waitForEndOfFrameCoroutine = null;
            }
        }

        private IEnumerator WaitForEndOfFrameCoroutine()
        {
            while (true)
            {
                yield return _waitForEndOfFrame;
                OnEndOfFrame();
            }
        }

        private bool ViewportsListHasChanged()
        {
            int count = Viewports.Count;
            if (count != _registeredViewports.Count)
            {
                return true;
            }
            else
            {
                for (int i = 0; i < count; ++i)
                {
                    var viewportInfo = Viewports[i];
                    var registeredViewport = _registeredViewports[i];

                    if (viewportInfo.Camera != registeredViewport.Camera ||
                        viewportInfo.Eye != registeredViewport.Eye ||
                        viewportInfo.Rect.x != registeredViewport.Rect.x ||
                        viewportInfo.Rect.y != registeredViewport.Rect.y ||
                        viewportInfo.Rect.width != registeredViewport.Rect.width ||
                        viewportInfo.Rect.height != registeredViewport.Rect.height)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private void ClearRegisteredViewports()
        {
            foreach (var compositorSurfaceInfo in _registeredViewports)
            {
                if (compositorSurfaceInfo.Camera != null &&
                    compositorSurfaceInfo.Camera.targetTexture != null)
                {
                    Destroy(compositorSurfaceInfo.Camera.targetTexture);
                    compositorSurfaceInfo.Camera.targetTexture = null;
                }

                compositorSurfaceInfo.Camera = null;
                Destroy(compositorSurfaceInfo.Surface);
            }

            _registeredViewports.Clear();
        }

        private void CreateRegisteredViewports()
        {
            foreach (var viewportInfo in Viewports)
            {
                // Create a render texture for each viewport's camera
                // Unless it already has one
                if (viewportInfo.Camera.targetTexture == null)
                {
                    RenderTexture renderTexture = null;

                    int width = viewportInfo.Rect.width + (int)MVR.DisplayMgr.GetOverscan() * 2;
                    int height = viewportInfo.Rect.height + (int)MVR.DisplayMgr.GetOverscan() * 2;

                    if (MVR.DisplayMgr.GetHDR())
                    {
                        renderTexture = new RenderTexture(width, height, 24, RenderTextureFormat.DefaultHDR)
                        {
                            antiAliasing = AntiAliasing,
                            name = "Compositor-" + viewportInfo.MVRViewport.GetName()
                        };
                    }
                    else
                    {
                        RenderTextureFormat format = RenderTextureFormat.ARGB32;

                        if (ForceHDRRender)
                        {
                            format = RenderTextureFormat.DefaultHDR;
                        }

                        renderTexture = new RenderTexture(width, height, 24, format)
                        {
                            antiAliasing = AntiAliasing,
                            name = "Compositor-" + viewportInfo.MVRViewport.GetName()
                        };
                    }

                    viewportInfo.Camera.targetTexture = renderTexture;
                }

                _registeredViewports.Add(new RegisteredViewport
                {
                    MVRViewport = viewportInfo.MVRViewport,
                    MVRCamera = viewportInfo.MVRCamera,
                    Camera = viewportInfo.Camera,
                    Eye = viewportInfo.Eye,
                    Rect = viewportInfo.Rect
                });
            }

        }

        private void CreateRegisteredCamerasSurfaces()
        {
            for (int i = 0; i < _registeredViewports.Count; i++)
            {
                var vp = _registeredViewports[i];

                Texture2D texture = null;

                // Camera.Surface
                if (MVR.DisplayMgr.GetHDR())
                {
                    texture = Texture2D.CreateExternalTexture(
                                            vp.Rect.width,
                                            vp.Rect.height,
                                            TextureFormat.RGBAHalf,
                                            false,
                                            true,
                                            GetCompositorSurface(i));
                }
                else
                {
                    texture = Texture2D.CreateExternalTexture(
                                            vp.Rect.width,
                                            vp.Rect.height,
                                            TextureFormat.RGBA32,
                                            false,
                                            true,
                                            GetCompositorSurface(i));
                }

                vp.Surface = texture;

                // Viewport.RT
                var renderTexture = _registeredViewports[i].Camera.targetTexture;
                var desc = renderTexture.descriptor;
                desc.msaaSamples = 1;
                _registeredViewports[i].RT = new RenderTexture(desc)
                {
                    name = "RTT-" + vp.MVRViewport.GetName()
                    // XXX We could use vp width and height but since we need to resolve the AA texture anyway,
                    // let's use the camera target texture's size
                    //width = vp.Rect.width,
                    //height = vp.Rect.height
                };

                _registeredViewports[i].RT.Create();

                // Viewport.SurfaceHDR
                if (ForceHDRRender)
                {
                    vp.SurfaceHDR = new Texture2D(vp.Rect.width, vp.Rect.height, TextureFormat.RGBAHalf, true, false);
                    vp.RTRGB = new RenderTexture(vp.Rect.width, vp.Rect.height, 24, RenderTextureFormat.ARGB32);
                }
            }
        }

        private void CopyViewportsToSurfaces(IntPtr iRenderParameters)
        {
            for (int surfaceId = 0; surfaceId < _registeredViewports.Count; ++surfaceId)
            {
                LockCompositorSurface(surfaceId);

                var registeredViewport = _registeredViewports[surfaceId];

                Camera camera = registeredViewport.Camera;

                RenderTexture cameraTexture = camera.targetTexture;

                int cameraRTWidth = cameraTexture.width;
                int cameraRTHeight = cameraTexture.height;

                vrViewport mvrVp = registeredViewport.MVRViewport;
                vrCamera mvrCamera = registeredViewport.MVRCamera;
                vrWarper mvrWarper = mvrCamera.GetWarper();

                int vpWidth = (int)mvrVp.GetWidth();
                int vpHeight = (int)mvrVp.GetHeight();

                RenderTexture vpRT = registeredViewport.RT;

                Texture2D compositorSurface = registeredViewport.Surface;

                int overscan = (int)MVR.DisplayMgr.GetOverscan();

                ref RenderTexture srcRT = ref vpRT;

                cameraTexture.ResolveAntiAliasedSurface(vpRT);

                // IF HDR RTT
                if (ForceHDRRender)
                {
                    compositorSurface = registeredViewport.SurfaceHDR;
                }

                int srcX = overscan;
                int srcY = overscan;
                int width = vpWidth;
                int height = vpHeight;

                if (mvrVp.GetStereo() && mvrVp.GetStereoMode() == VRStereoMode.SideBySide)
                {
                    width /= 2;
                }

                if (mvrCamera.GetRenderToTexture())
                {
                    // +---------------------------+ ^              ^
                    // |Overscan                   | |              | 
                    // |  +----------------------+ | |              | 
                    // |  |Non-overscan camera RT| | | srcY         |
                    // |  |                      | | |              | cameraRTHeight
                    // |  |      +----------+    | | v ^            |
                    // |  |      | VP       |    | |   |vpHeight    |
                    // |  |      |          |    | |   |            |
                    // |  |      |          |    | |   v            |
                    // |  |      +----------+    | |   ^            |
                    // |  +----------------------+ |   | RTOffsetY  |
                    // +---------------------------+   v            v
                    //    <-----> RTOffsetX
                    // <--------> srcX
                    //    

                    srcX = (int)mvrVp.GetRenderTextureOffsetX() + overscan;

                    // We want zero to be top left, not bottom left as Unity.Graphics is using
                    srcY = cameraRTHeight - overscan - (int)mvrVp.GetRenderTextureOffsetY() - vpHeight;
                }

                Graphics.CopyTexture(vpRT, 0, 0, srcX, srcY, width, height, compositorSurface, 0, 0, 0, 0);

                if (ForceHDRRender)
                {
                    // Convert HDR surface to SDR surface
                    Graphics.Blit(compositorSurface, registeredViewport.RTRGB, _hdrToRGBMaterial);
                    Graphics.CopyTexture(registeredViewport.RTRGB, 0, registeredViewport.Surface, 0);
                }

                UnlockCompositorSurface(surfaceId);

                vrVec3 pos = mvrCamera.GetPositionWorld();

                if (mvrWarper != null)
                {
                    pos = mvrCamera.GetPositionRelative(mvrWarper);
                }

                AddViewportRenderParameters(
                    iRenderParameters,
                    pos.x, pos.y, pos.z,
                    mvrVp.GetCornerOffsetTopLeftX(), mvrVp.GetCornerOffsetTopLeftY(),
                    mvrVp.GetCornerOffsetTopRightX(), mvrVp.GetCornerOffsetTopRightY(),
                    mvrVp.GetCornerOffsetBottomRightX(), mvrVp.GetCornerOffsetBottomRightY(),
                    mvrVp.GetCornerOffsetBottomLeftX(), mvrVp.GetCornerOffsetBottomLeftY(),
                    mvrVp.GetBlendingZoneLeft(), mvrVp.GetBlendingZoneRight(),
                    mvrVp.GetBlendingZoneBottom(), mvrVp.GetBlendingZoneTop()
                    );
            }
        }

        private void OnEndOfFrame()
        {
            IntPtr renderParameters = CreateRenderParameters();
            CopyViewportsToSurfaces(renderParameters);
            RenderCompositor(renderParameters);
            PresentCompositor();
        }

        static void AddViewportsToCreationParameters(IntPtr iParameters, List<RegisteredViewport> iViewports)
        {
            for (int surfaceId = 0; surfaceId < iViewports.Count; ++surfaceId)
            {
                RegisteredViewport viewportInfo = iViewports[surfaceId];

                vrNode3D mvrNode = MVRNodesMapper.Instance.GetNode(viewportInfo.Camera.gameObject);

                int eye = 0; // left or mono by default
                if (viewportInfo.Eye == MiddleVR.Unity.MVRTools.Eye.Right)
                {
                    eye = 1;
                }

                // Look for warping
                vrCamera mvrCam = (vrCamera)mvrNode;
                if (mvrCam != null)
                {
                    VRWarpingType warpingType = VRWarpingType.None;

                    string warperName = "";
                    string warpingCfg = "";
                    string warpingChannel = "";
                    float warpingScale = 1.0f;

                    vrWarper warper = mvrCam.GetWarper();

                    if (warper != null)
                    {
                        warperName = warper.GetName();

                        if (warper.GetWarpingType() == VRWarpingType.Vioso)
                        {
                            vrWarperVioso vioso = (vrWarperVioso)warper;

                            string cfg = vioso.GetConfigurationFile();
                            if (cfg.Length > 0)
                            {
                                warpingType = MiddleVR.VRWarpingType.Vioso;
                                warpingCfg = cfg;
                                warpingChannel = vioso.GetChannelName();
                            }
                        }
                        else if(warper.GetWarpingType() == VRWarpingType.ScalableDisplay)
                        {
                            vrWarperScalableDisplay sd = warper as vrWarperScalableDisplay;

                            string cfg = sd.GetConfigurationFile();

                            if (cfg.Length > 0)
                            {
                                warpingType = VRWarpingType.ScalableDisplay;
                                warpingCfg = cfg;
                                warpingScale = sd.GetUnitScale();
                            }
                        }
                    }

                    AddViewport(iParameters,
                              eye,
                              viewportInfo.MVRViewport.GetName(),
                              viewportInfo.Rect.x, viewportInfo.Rect.y, viewportInfo.Rect.width, viewportInfo.Rect.height,
                              warperName,
                              (int)warpingType,
                              warpingCfg,
                              warpingChannel,
                              warpingScale);
                }
            }

        }

#region Compositor Plugin Bindings

        public enum CompositorMode
        {
            Auto = 0,
            OpenGL = 1,
            Direct3D11 = 2,
        }

        // Order must match Compositor/Parameters.hpp::OutputFormat
        public enum CompositorHDRMode
        {
            SDR = 0,
            HDR_RGB10,
            HDR_FP16
        }

        private const string CompositorPluginName = "MiddleVR_UnityRendering";

        // synchronises compositor surface list

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        private static extern bool IsRendererSupported();

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern void ResetCompositor();

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        private static extern bool WaitCompositor();

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetCompositorSurface(int compositorSurfaceId);

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr AddViewport(
            IntPtr parameters,
            int eye,
            [MarshalAs(UnmanagedType.LPWStr)] string name,
            int vpX, int vpY, int vpW, int vpH,
            [MarshalAs(UnmanagedType.LPWStr)] string warperName,
            int warpintType,
            [MarshalAs(UnmanagedType.LPWStr)] string warpingCfgFile,
            [MarshalAs(UnmanagedType.LPWStr)] string warpingChannel,
            float warpingScale
            );

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr AddViewportRenderParameters(
            IntPtr parameters,
            float x, float y, float z,
            int vpTLX, int vpTLY, int vpTRX, int vpTRY, int vpBRX, int vpBRY, int vpBLX, int vpBLY,
            int vpBZL, int vpBZR, int vpBZB, int vpBZT
            );

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr CreateRenderParameters();

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr CreateCompositorParameters(
            [MarshalAs(UnmanagedType.LPWStr)] string editorCfg,
            [MarshalAs(UnmanagedType.LPWStr)] string editorClusterId,
            CompositorHDRMode hdrMode,
            CompositorMode mode
            );

        // Pass result of CreateCompositorParameters() as data
        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetCreateCompositorCallback();
        private static void CreateCompositor(
            string editorCfg,
            string editorClusterId,
            List<RegisteredViewport> viewports,
            CompositorHDRMode hdrMode,
            CompositorMode mode)
        {
            IntPtr parameters = CreateCompositorParameters(
                    editorCfg,
                    editorClusterId,
                    hdrMode,
                    mode);

            AddViewportsToCreationParameters(parameters, viewports);

            var cmdBuf = new CommandBuffer();
            cmdBuf.IssuePluginEventAndData(
                GetCreateCompositorCallback(),
                0,
                parameters
                );
            Graphics.ExecuteCommandBuffer(cmdBuf);
        }

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetDestroyCompositorCallback();
        private static void DestroyCompositor() => GL.IssuePluginEvent(GetDestroyCompositorCallback(), 0);

        // Pass result of GenerateCompositorSurfaceId() as event id
        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetLockCompositorSurfaceCallback();
        private static void LockCompositorSurface(int compositorSurfaceId) => GL.IssuePluginEvent(GetLockCompositorSurfaceCallback(), compositorSurfaceId);

        // Pass result of GenerateCompositorSurfaceId() as event id
        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetUnlockCompositorSurfaceCallback();
        private static void UnlockCompositorSurface(int compositorSurfaceId) => GL.IssuePluginEvent(GetUnlockCompositorSurfaceCallback(), compositorSurfaceId);

        // Pass result of CreateCompositorSurfaceStruct() as event id
        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetRenderCompositorCallback();
        private static void RenderCompositor(IntPtr parameters)
        {
            var cmdBuf = new CommandBuffer();
            cmdBuf.IssuePluginEventAndData(
                GetRenderCompositorCallback(),
                0,
                parameters
                );
            Graphics.ExecuteCommandBuffer(cmdBuf);
        }

        [DllImport(CompositorPluginName, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetPresentCompositorCallback();
        private static void PresentCompositor() => GL.IssuePluginEvent(GetPresentCompositorCallback(), 0);

#endregion
    }
}
