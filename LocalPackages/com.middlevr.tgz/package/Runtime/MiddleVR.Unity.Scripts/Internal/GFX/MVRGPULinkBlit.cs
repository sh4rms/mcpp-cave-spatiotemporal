/* MVRGPULinkBlit
 * MiddleVR
 * (c) MiddleVR
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;

public class MVRGPULinkBlit : MonoBehaviour
{
    private vrCamera _mvrCam = null;
    private Texture2D _tex = null;

    private void Start()
    {
        var cameraComponent = GetComponent<Camera>();
        // Render nothing
        cameraComponent.cullingMask = 0;
        cameraComponent.clearFlags = CameraClearFlags.Color;
        cameraComponent.backgroundColor = Color.black;
    }

    public void Init(vrCamera iCam)
    {
        _mvrCam = iCam;
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (_tex == null)
        {
#if UNITY_2023_1_OR_NEWER
            var script = GameObject.FindFirstObjectByType<MVRGPULink>();
#else
            var script = GameObject.FindObjectOfType<MVRGPULink>();
#endif
            MVRGPULink.OffscreenCameraServer off;

            if (script && script.ServerOffscreenCameras != null && script.ServerOffscreenCameras.TryGetValue(_mvrCam.GetName(), out off))
            {
                _tex = off.SharedTexture;
            }
        }

        if (_tex != null)
        {
            Graphics.Blit(_tex, destination);
        }
    }
}
