/* MVRManagerPostFrameScript
 * MiddleVR
 * (c) MiddleVR
 * 
 * Copies the render of the current camera to the MiddleVR viewport 'ViewportName'
 * If the current camera does not use a targetTexture, will create one based
 * on the viewport's resolution.
 * The script will also disable the rendering of the MiddleVR camera associated with the viewport
 * 
 * SameFrame:
 * - If False, the copy will have one frame delay.
 * - If True, the copy will be in the same frame, but some textures might not be copied correctly
 *   due to, it seems, a Unity bug in some versions
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;

[MVRDisable(ifNoMVR: true)]
public class MVRCopyTextureToViewport : MonoBehaviour
{
    public RenderTexture Texture;
    public string ViewportName = "Viewport0";
    public bool SameFrame = false;
    private vrViewport _mvrViewport;
    private vrCamera _mvrCam;
    private Camera _unityCam;
    private Camera _unityMvrCam;
    private RenderTexture _mvrTexture;
    private bool _init = false;
    private bool _continuePostFrameUpdate = false;

    void Init()
    {
        _mvrViewport = MVR.DisplayMgr.GetViewport(ViewportName);

        _unityCam = GetComponent<Camera>();

        if (_mvrViewport != null)
        {
            _mvrCam = _mvrViewport.GetCamera();

            if (_mvrCam != null)
            {
                var GO = MVRNodesMapper.Instance.GetNode(_mvrCam);

                if (GO != null)
                {
                    _unityMvrCam = GO.GetComponent<Camera>();

                    if (_unityMvrCam != null)
                    {
                        // Disable rendering of the MVR camera
                        _unityMvrCam.enabled = false;

                        _mvrTexture = _unityMvrCam.targetTexture;

                        if (_mvrTexture == null)
                        {
                            MVRTools.Log(1, $"[X] MVRCopyTextureToViewport: _mvrTexture for '{ViewportName}' is null");
                            return;
                        }
                    }
                }
            }
            else
            {
                MVRTools.Log(1, $"[X] MVRCopyTextureToViewport: Couldn't find vrCamera for viewport '{ViewportName}'");
                return;
            }
        }
        else
        {
            MVRTools.Log(1, $"[X] MVRCopyTextureToViewport: Couldn't find viewport '{ViewportName}'");
            return;
        }

        if (Texture == null)
        {
            if (_unityCam != null)
            {
                if (_unityCam.targetTexture == null)
                {
                    // create texture same as compositor
                    _unityCam.targetTexture = new RenderTexture(_mvrTexture)
                    {
                        name = _mvrTexture.name + "-CopyToViewport"
                    };
                }

                Texture = _unityCam.targetTexture;
            }
        }

        if (Texture != null)
        {
            MVRTools.Log(3, $"[+] MVRCopyTextureToViewport: Setup successful for camera '{_unityCam.name}' and viewport '{ViewportName}'");

            if (SameFrame)
            {
                _continuePostFrameUpdate = true;
                StartCoroutine(PostFrameUpdate());
            }

            _init = true;
        }
    }

    void CopyTexture()
    {
        if (_init)
        {
            Graphics.Blit(Texture, _mvrTexture);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!_init)
        {
            Init();
        }

        if (!SameFrame) CopyTexture();
    }

    private void OnApplicationQuit()
    {
        _continuePostFrameUpdate = false;
    }

    private IEnumerator PostFrameUpdate()
    {
        while (_continuePostFrameUpdate)
        {
            yield return new WaitForEndOfFrame();
            CopyTexture();
        }
    }
}
