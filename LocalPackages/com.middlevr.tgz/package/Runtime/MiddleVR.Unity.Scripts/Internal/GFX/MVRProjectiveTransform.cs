using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;

public class MVRProjectiveTransform : MonoBehaviour
{
    private vrViewport _viewport;
    private Material _material;
    private Shader _shader;
    private Color _background = Color.black;

    [SerializeField] private Vector2 _topLeft = Vector2.up;
    [SerializeField] private Vector2 _topRight = Vector2.one;
    [SerializeField] private Vector2 _bottomLeft = Vector2.zero;
    [SerializeField] private Vector2 _bottomRight = Vector2.right;

    private Matrix4x4 _transform2d = Matrix4x4.identity;

    private bool _updateShader = true;

    public class Quad2
    {
        /// <summary>
        /// bottom-left corner
        /// </summary>
        public Vector2 bl = Vector2.zero;
        /// <summary>
        /// bottom-right corner
        /// </summary>
        public Vector2 br = Vector2.right;
        /// <summary>
        /// top-left corner
        /// </summary>
        public Vector2 tl = Vector2.up;
        /// <summary>
        /// top-right corner
        /// </summary>
        public Vector2 tr = Vector2.one;

        public Quad2() { }
        public Quad2(Vector2 bl, Vector2 br, Vector2 tl, Vector2 tr)
        {
            this.bl = bl;
            this.br = br;
            this.tl = tl;
            this.tr = tr;
        }
        public Quad2(float blX, float blY, float brX, float brY, float tlX, float tlY, float trX, float trY)
        {
            this.bl = new Vector2(blX, blY);
            this.br = new Vector2(brX, brY);
            this.tl = new Vector2(tlX, tlY);
            this.tr = new Vector2(trX, trY);
        }
    };

    public void SetViewport(vrViewport iViewport)
    {
        _viewport = iViewport;
    }

    void Awake()
    {
        CreateMaterial();
    }

    /// <summary>
    /// Create a matrix that maps 3D basis vectors to the four corners of a specified 2D quad.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The resulting matrix will map (1, 0, 0) to (a * quad.bl.xy, a), (0, 1, 0) to
    /// (b * quad.br.xy, b), (0, 0, 1) to (c * quad.tl.xy, c) and (1, 1, 1) to (d * quad.tr.xy, d).
    /// </para>
    /// </remarks>
    /// <param name="quad">Quadrilateral (four corners in 2D)</param>
    public static Matrix4x4 BasisMap2D(Quad2 quad)
    {
        Matrix4x4 m = new Matrix4x4()
        {
            m00 = quad.bl.x,
            m10 = quad.bl.y,
            m20 = 1f,
            m01 = quad.br.x,
            m11 = quad.br.y,
            m21 = 1f,
            m02 = quad.tl.x,
            m12 = quad.tl.y,
            m22 = 1f,
            m33 = 1f
        };
        Vector3 v = Adjugate3x3(m).MultiplyPoint3x4(new Vector3(quad.tr.x, quad.tr.y, 1f));
        return m * new Matrix4x4() { m00 = v.x, m11 = v.y, m22 = v.z, m33 = 1f };
    }

    /// <summary>
    /// Find the projective transformation (homography) from one 2D quadrilateral to another.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The source and destination quadrilaterals are defined by four corners in homogeneous coordinates.
    /// </para><para>
    /// No three of the four corners in a quad may be collinear.
    /// </para>
    /// </remarks>
    /// <returns>Matrix that maps points from A to B with perspectiveness (w-coordinate).</returns>
    /// <param name="A">Source quadrilateral.</param>
    /// <param name="B">Destination quadrilateral.</param>
    public static Matrix4x4 Proj_transform2d(Quad2 A, Quad2 B)
    {
        Matrix4x4 basisToA = BasisMap2D(A);
        Matrix4x4 basisToB = BasisMap2D(B);
        Matrix4x4 C = basisToB * Adjugate3x3(basisToA);
        float scale = 1f / C.m22;
        return new Matrix4x4()
        {
            m00 = C.m00 * scale,
            m01 = C.m01 * scale,
            m02 = 0f,
            m03 = C.m02 * scale,
            m10 = C.m10 * scale,
            m11 = C.m11 * scale,
            m12 = 0f,
            m13 = C.m12 * scale,
            m20 = 0f,
            m21 = 0f,
            m22 = 1f,
            m23 = 0f,
            m30 = C.m20 * scale,
            m31 = C.m21 * scale,
            m32 = 0f,
            m33 = C.m22 * scale
        };
    }

    void CreateMaterial()
    {
        if (_shader == null)
        {
            _shader = Shader.Find("MVR/ProjectiveTransform");
        }

        if (_shader != null)
        {
            _material = new Material(_shader);
        }

        _updateShader = true;
    }

    private void UpdateShader()
    {
        UpdateShader(_material);
    }

    public void UpdateShader(Material material)
    {
        if (material == null || _viewport == null)
            return;

        material.SetColor("_Background", _background);

        // Transform UV-coordinates from specified quad to normalized screen coordinates

        // Convert from MiddleVR corner offsets which are offsets and not absolute positions
        float w = (float)_viewport.GetWidth();
        float h = (float)_viewport.GetHeight();

        float blx = _bottomLeft.x / w;
        float bly = _bottomLeft.y / h;
        float brx = 1 - (_bottomRight.x / w);
        float bry = _bottomRight.y / h;
        float tlx = _topLeft.x / w;
        float tly = 1 - _topLeft.y / h;
        float trx = 1 - _topRight.x / w;
        float try_ = 1 - _topRight.y / h; // Can't name a variable 'try' ...

        Quad2 source = new Quad2(blx,bly, brx, bry, tlx, tly, trx, try_);
        Quad2 destination = new Quad2(Vector2.zero, Vector2.right, Vector2.up, Vector2.one);

        _transform2d = Proj_transform2d(source, destination);
        material.SetMatrix("_Transform", _transform2d);
    }

    public bool UpdateValues()
    {
        if (_viewport == null)
            return false;

        if (_viewport.GetCornerOffsetBottomLeftX() != _bottomLeft.x)
        {
            _bottomLeft.x = _viewport.GetCornerOffsetBottomLeftX();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetBottomLeftY() != _bottomLeft.y)
        {
            _bottomLeft.y = _viewport.GetCornerOffsetBottomLeftY();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetTopLeftX() != _topLeft.x)
        {
            _topLeft.x = _viewport.GetCornerOffsetTopLeftX();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetTopLeftY() != _topLeft.y)
        {
            _topLeft.y = _viewport.GetCornerOffsetTopLeftY();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetBottomRightX() != _bottomRight.x)
        {
            _bottomRight.x = _viewport.GetCornerOffsetBottomRightX();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetBottomRightY() != _bottomRight.y)
        {
            _bottomRight.y = _viewport.GetCornerOffsetBottomRightY();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetTopRightX() != _topRight.x)
        {
            _topRight.x = _viewport.GetCornerOffsetTopRightX();
            _updateShader = true;
        }

        if (_viewport.GetCornerOffsetTopRightY() != _topRight.y)
        {
            _topRight.y = _viewport.GetCornerOffsetTopRightY();
            _updateShader = true;
        }

        return _updateShader;
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        UpdateValues();

        if (_updateShader)
        {
            UpdateShader();
            _updateShader = false;
        }

#if MVR_URP

#else
        Graphics.Blit(source, destination, _material);
#endif
    }

    public static Matrix4x4 Adjugate3x3(Matrix4x4 m)
    {
        return new Matrix4x4()
        {
            m00 = +(m.m11 * m.m22 - m.m12 * m.m21),
            m10 = -(m.m10 * m.m22 - m.m12 * m.m20),
            m20 = +(m.m10 * m.m21 - m.m11 * m.m20),
            m30 = 0f,
            m01 = -(m.m01 * m.m22 - m.m02 * m.m21),
            m11 = +(m.m00 * m.m22 - m.m02 * m.m20),
            m21 = -(m.m00 * m.m21 - m.m01 * m.m20),
            m31 = 0f,
            m02 = +(m.m01 * m.m12 - m.m02 * m.m11),
            m12 = -(m.m00 * m.m12 - m.m02 * m.m10),
            m22 = +(m.m00 * m.m11 - m.m01 * m.m10),
            m32 = 0f,
            m03 = 0f,
            m13 = 0f,
            m23 = 0f,
            m33 = 1f
        };
    }
}
