﻿/* MVREncoder
 * MiddleVR
 * (c) MiddleVR
 */
using UnityEngine;
using UnityEngine.Events;
using System.Runtime.InteropServices;
using System;
using MiddleVR.Unity;

[System.Serializable]
public class MVREncoder
{
    public enum Format
    {
        R8G8B8A8_UNORM = 28,
        B8G8R8A8_UNORM = 87,
        NV12 = 103,
        UNKNOWN = 0,
    }
    public enum Codec
    {
        UNDEFINED = -1,
        H264 = 0,
        HEVC = 1,
        AV1 = 2
    };

    [StructLayout(LayoutKind.Sequential), Serializable]
    public struct Desc
    {
        [MarshalAs(UnmanagedType.I4)]
        public int Width;
        [MarshalAs(UnmanagedType.I4)]
        public int Height;
        [MarshalAs(UnmanagedType.I4)]
        public int FrameRate;
        [MarshalAs(UnmanagedType.I4)]
        public int BitRate;
        [MarshalAs(UnmanagedType.I4)]
        public int MaxFrameSize;
        [MarshalAs(UnmanagedType.I4)]
        public Format EncoderFormat;
        [MarshalAs(UnmanagedType.I4)]
        public Codec EncoderCodec;
        [MarshalAs(UnmanagedType.I1)]
        public bool Lossless;
    }

    [System.Serializable]
    public class EncodedCallback : UnityEvent<System.IntPtr, int> {};
    public EncodedCallback onEncoded = new EncodedCallback();

    public int Id { get; private set; } = -1;

    public string Name = "Undefined";
    private bool _texturePtrLog = false;

    public MVREncoder(string iName)
    {
        Name = iName;
    }

    public bool IsValid
    {
        get { return Lib.EncoderIsValid(Id); }
    }

    public int Width
    {
        get { return Lib.EncoderGetWidth(Id); }
    }

    public int Height
    {
        get { return Lib.EncoderGetHeight(Id); }
    }

    public Format EncoderFormat
    {
        get { return Lib.EncoderGetFormat(Id); }
    }

    public int FrameRate
    {
        get { return Lib.EncoderGetFrameRate(Id); }
    }

    public string Error
    {
        get
        {
            if (!Lib.EncoderHasError(Id)) return "";

            var str = Lib.EncoderGetError(Id);
            Lib.EncoderClearError(Id);
            return "XXX"; // str;
        }
    }

    public void Create(Desc desc)
    {
        Id = Lib.Create(desc);

        if (!IsValid)
        {
            MVRTools.LogError("MVREncoder::Create: " + Error);
        }
    }

    public int GetCodec()
    {
        return Lib.EncoderGetCodec(Id);
    }

    public void Destroy()
    {
        Lib.EncoderDestroy(Id);
    }

    public void Reconfigure(Desc desc)
    {
        Destroy();
        Create(desc);
    }

    public int GetBestEncoderSupportedByGPU()
    {
        return Lib.GetBestEncoderSupportedByGPU(Id);
    }

    public void Update()
    {
        if (!IsValid) return;

        Lib.EncoderCopyEncodedData(Id);

        int n = Lib.EncoderGetEncodedDataCount(Id);
        for (int i = 0; i < n; ++i)
        {
            var size = Lib.EncoderGetEncodedDataSize(Id, i);
            var data = Lib.EncoderGetEncodedDataBuffer(Id, i);
            onEncoded.Invoke(data, size);
        }
    }

    public bool EncodeTexture(Texture texture, bool forceIdrFrame)
    {
        if (!texture)
        {
            MVRTools.LogError("MVREncoder::EncodeTexture: The given texture is null.");
            return false;
        }

        var ptr = texture.GetNativeTexturePtr();

        if (ptr == IntPtr.Zero)
        {
            if (!_texturePtrLog)
            {
                MVRTools.Log(2, $"[~] MVREncoder::EncodeTexture: {Name}: Texture pointer is null. Texture not yet ready?");
                _texturePtrLog = true;
            }

            return false;
        }

        if (!EncodePtr(ptr, forceIdrFrame))
        {
            var msg = Error;
            if (!string.IsNullOrEmpty(msg))
            {
                MVRTools.LogError("MVREncoder::Encode:" + msg);
            }
            return false;
        }

        return true;
    }

    public bool EncodePtr(System.IntPtr ptr, bool forceIdrFrame)
    {
        if (ptr == System.IntPtr.Zero)
        {
            MVRTools.Log(2, "[X] MVREncoder::EncodePtr:The given texture pointer is invalid.");
            return false;
        }

        if (!IsValid)
        {
            MVRTools.LogError("MVREncoder::Encoder has not been initialized yet.");
            return false;
        }

        var result = Lib.EncoderEncode(Id, ptr, forceIdrFrame);
        if (!result)
        {
            MVRTools.LogError("MVREncoder::Encode: " + Error);
        }

        return result;
    }

    #region Plugin Bindings
    public static class Lib
    {
        public const string DllName = "MiddleVR_UnityRendering";

        // ---

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        private static extern int EncoderCreate(IntPtr desc);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderDestroy(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EncoderIsValid(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetCodec(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int GetBestEncoderSupportedByGPU(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        private static extern void EncoderReconfigure(int Id, IntPtr desc);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetWidth(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetHeight(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern Format EncoderGetFormat(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetFrameRate(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EncoderEncode(int id, IntPtr texturePtr, bool forceIdrFrame);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern void EncoderCopyEncodedData(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetEncodedDataCount(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern int EncoderGetEncodedDataSize(int Id, int index);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr EncoderGetEncodedDataBuffer(int Id, int index);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr EncoderGetError(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EncoderHasError(int Id);

        [DllImport(DllName, CallingConvention = CallingConvention.StdCall)]
        public static extern void EncoderClearError(int Id);

        public static int Create(Desc desc)
        {
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Desc)));
            Marshal.StructureToPtr(desc, ptr, false);
            var Id = EncoderCreate(ptr);
            Marshal.FreeHGlobal(ptr);
            return Id;
        }

        public static void Reconfigure(int Id, Desc desc)
        {
            var ptr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Desc)));
            Marshal.StructureToPtr(desc, ptr, false);
            EncoderReconfigure(Id, ptr);
            Marshal.FreeHGlobal(ptr);
        }

        public static string GetError(int Id)
        {
            var ptr = EncoderGetError(Id);
            return Marshal.PtrToStringAnsi(ptr);
        }
    }
    #endregion
}
