﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using MiddleVR;
using MiddleVR.Unity;

public class MVRICVFXRender : MonoBehaviour
{
    private Camera _camera = null;
    private vrCamera _mvrCamera = null;
    private GameObject _quad = null;

    private List<Camera> _backgroundCameras = new List<Camera>();

    public GameObject GetQuad()
    {
        return _quad;
    }

    public List<Camera> GetBackgroundCameras()
    {
        return _backgroundCameras;
    }

    vrCamera GetFirstNonICVFXCamera()
    {
        foreach (var mvrCamera in MVR.DisplayMgr.Cameras)
        {
            if (!mvrCamera.IsICVFX())
            {
                return mvrCamera;
            }
        }
        return null;
    }

    void SetupICVFXCamera()
    {
        _camera = this.GetComponent<Camera>();

        if (_camera != null)
        {
            // Don't render the quad or warping when rendering this camera
            _camera.cullingMask = ~(MVRTools.GetScreensLayerMask() | MVRTools.GetWarpingLayerMask());

            // Render after background cameras
            // We need the ICVFX background cameras
            // to be rendered after both the regular background
            // cameras and the ICVFX camera
            var mvrBackgroundCamera = GetFirstNonICVFXCamera();
            if(mvrBackgroundCamera != null)
            {
                _camera.depth = MVRNodesMapper.Instance.GetNode(mvrBackgroundCamera).GetComponent<Camera>().depth + 1;
            }
            else
            {
                // Default camera depth is -1, so 1 should be enough for default case
                _camera.depth = 1;
            }

            // XXX Debug
            //_camera.clearFlags = CameraClearFlags.Color;
            //_camera.backgroundColor = Color.red;

            _mvrCamera = MVRNodesMapper.Instance.GetNode(this.gameObject) as vrCamera;
        }
    }

    void SetupRenderingQuad()
    {
        _quad = GameObject.CreatePrimitive(PrimitiveType.Quad);

        _quad.layer = MVRTools.GetScreensLayer();

        Renderer qr = _quad.GetComponent<Renderer>();
#if MVR_HDRP
        qr.material = new Material(Shader.Find("MVR/UnlitShader_HDRP"));
        qr.material.SetTexture("_ColorMap", GetComponent<Camera>().targetTexture);
#else
        qr.material = new Material(Shader.Find("MVR/UnlitShader"));
        _quad.GetComponent<Renderer>().material.mainTexture = GetComponent<Camera>().targetTexture;
#endif
        qr.shadowCastingMode = ShadowCastingMode.Off;
        qr.lightProbeUsage = LightProbeUsage.Off;
        qr.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
        qr.allowOcclusionWhenDynamic = false;

        _quad.transform.parent = _camera.gameObject.transform;
        _quad.transform.localRotation = Quaternion.identity;

        UpdateQuad();

        // We don't want to see it in the editor
        _quad.GetComponent<Renderer>().enabled = false;
    }

    void UpdateQuad()
    {
        float vpDist = 30.0f;

        float vpLeft = _mvrCamera.GetFrustumLeft() / _mvrCamera.GetNear() * vpDist;
        float vpRight = _mvrCamera.GetFrustumRight() / _mvrCamera.GetNear() * vpDist;
        float width = (vpRight - vpLeft);
        float x = width / 2.0f + vpLeft;

        float vpTop = _mvrCamera.GetFrustumTop() / _mvrCamera.GetNear() * vpDist;
        float vpBottom = _mvrCamera.GetFrustumBottom() / _mvrCamera.GetNear() * vpDist;
        float height = (vpTop - vpBottom);
        float y = height / 2.0f + vpBottom;

        _quad.transform.localScale = new Vector3(width, height, 1.0f);
        _quad.transform.localPosition = new Vector3(x, y, vpDist);
    }

    void SetupICVFXDisplay()
    {
        foreach (var backgndMvrCamera in MVR.DisplayMgr.Cameras)
        {
            if (!backgndMvrCamera.IsICVFX() && !backgndMvrCamera.GetIgnoreICVFX())
            {
                // ---- Regular MVR cameras should not render the ICVFX frustum ----
                var backgndUnityCameraGO = MVRNodesMapper.Instance.GetNode(backgndMvrCamera);
                Camera backgndUnityCamera = backgndUnityCameraGO.GetComponent<Camera>();

                // Render everything except the ICVFX frustum 
                backgndUnityCamera.cullingMask = backgndUnityCamera.cullingMask & ~MVRTools.GetScreensLayerMask();

                // ---- Create ICVFX background cameras which will display only the ICVFX frustum ----
                var ICVFXbackgndCamGO = UnityEngine.Object.Instantiate(backgndUnityCameraGO) as GameObject;
                ICVFXbackgndCamGO.name = _mvrCamera.GetName() + "_" + backgndUnityCamera.name;

                var script = ICVFXbackgndCamGO.AddComponent<MVRICVFXDisplay>();
                script.SetReferences(_quad, backgndMvrCamera, _mvrCamera);

                _backgroundCameras.Add(ICVFXbackgndCamGO.GetComponent<Camera>());
            }
        }
    }

    void Start()
    {
        SetupICVFXCamera();
        SetupRenderingQuad();
        SetupICVFXDisplay();
    }

    // Update is called once per frame
    void Update()
    {
        UpdateQuad();
    }
}
