﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using AOT;
#if UNITY_EDITOR
using UnityEditor;
#endif

using UnityEngine.Rendering;


public class MVRWarperMesh : MonoBehaviour
{
    public bool ShowSceneOnScreens = false;

    private vrCamera _mvrCam = null;
    private vrWarper _mvrWarper;
    private vrWarperMPCDI _mvrWarperMPCDI;
    private vrMesh _mvrWarperMesh;

    private GameObject _warperMeshGO = null;
    private Mesh _warperMesh;

    private Camera _viewCamera;

    private Mesh _gridMesh;
    private GameObject _gridMeshGO;

    private Material _warpMaterial = null;

    public bool DebugGridMesh = false;

    private RenderTexture _RT = null;
    private RenderTexture _overscanDestination = null;

    private Texture2D _blendingImage = null;
    private Texture2D _blackImage = null;

    public Texture2D GetBlendingImage()
    {
        return _blendingImage;
    }

    public Texture2D GetBlackImage()
    {
        return _blackImage;
    }

    public vrCamera GetMVRCamera()
    {
        return _mvrCam;
    }

    public Camera GetViewCamera()
    {
        return _viewCamera;
    }

    public GameObject GetWarperMeshGO()
    {
        return _warperMeshGO;
    }

    public GameObject GetGridMeshGO()
    {
        return _gridMeshGO;
    }

    public Mesh GetGridMesh()
    {
        return _gridMesh;
    }

    public vrWarper GetWarper()
    {
        return _mvrWarper;
    }

    public vrWarperMPCDI GetWarperMPCDI()
    {
        return _mvrWarperMPCDI;
    }

    void CreateGridMesh()
    {
        _gridMeshGO = new GameObject("MVRGridMeshGO" + _mvrWarper.GetName());
        _gridMeshGO.transform.parent = _viewCamera.transform;

        _gridMeshGO.transform.localPosition = new Vector3(0, 0, 0);
        _gridMeshGO.transform.localRotation = Quaternion.Euler(0, 0, 0);

        var meshFilter = _gridMeshGO.AddComponent<MeshFilter>();

        if(DebugGridMesh)
        {
            var meshRenderer = _gridMeshGO.AddComponent<MeshRenderer>();
#if MVR_HDRP
            meshRenderer.material = new Material(Shader.Find("Unlit/Texture"));
#else
            meshRenderer.material = new Material(Shader.Find("Standard"));
#endif
        }

        // Prepare mesh

        _gridMesh = new Mesh();

        Vector3[] gridVertices = new Vector3[_warperMesh.vertexCount];
        List<Vector3> distortionMeshVertices = new List<Vector3>();

        int nb = gridVertices.Length;

        for (int i = 0; i < nb; i++)
        {
            Vector3 vtx;

            vtx.x = (_warperMesh.uv[i].x - 0.5f) * 2.0f;
            vtx.y = (_warperMesh.uv[i].y - 0.5f) * 2.0f;
            vtx.z = 1.0f;

            gridVertices[i] = vtx;

            // Store original mesh positions in uv
            Vector3 distortionMeshVertex = _warperMesh.vertices[i];
            distortionMeshVertices.Add(distortionMeshVertex);
        }

        _gridMesh.vertices = gridVertices;
        _gridMesh.SetUVs(0, distortionMeshVertices);
        _gridMesh.SetUVs(1, _warperMesh.uv);

        _gridMesh.triangles = _warperMesh.triangles;

        meshFilter.mesh = _gridMesh;

        //_gridMeshGO.SetActive(false);
    }

    void PrepareWarper()
    {
        if (_mvrCam == null)
            return;

        _mvrWarper = _mvrCam.GetWarper();
        _mvrWarperMesh = _mvrWarper.GetMesh();

        if (_mvrWarperMesh != null)
        {
            // find matching warper mesh
            _warperMeshGO = MVRNodesMapper.Instance.GetNode(_mvrWarperMesh);
            _warperMesh = _warperMeshGO.GetComponent<MeshFilter>().mesh;

            if(ShowSceneOnScreens)
            {
                _warperMeshGO.layer = MVRTools.GetWarpingLayer();
                _warperMeshGO.SetActive(true);
                _warperMeshGO.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
                _warperMeshGO.GetComponent<Renderer>().lightProbeUsage = LightProbeUsage.Off;
#if MVR_HDRP
                _warperMeshGO.GetComponent<Renderer>().material = new Material(Shader.Find("MVR/UnlitShader_HDRP"));
#else
                _warperMeshGO.GetComponent<Renderer>().material = new Material(Shader.Find("MVR/UnlitShader"));
#endif
                _warperMeshGO.GetComponent<Renderer>().enabled = true;
            }
            else
            {
                _warperMeshGO.SetActive(false);
            }
        }
        else
        {
            MVRTools.Log(1, $"[X] Warper '{_mvrWarper.GetName()}' does not have a mesh.");
        }

        _mvrWarperMPCDI = _mvrWarper as vrWarperMPCDI;

        if (_mvrWarperMPCDI != null)
        {
            // Prepare images
            _blendingImage = LoadImage(_mvrWarperMPCDI.GetBlendingImage());
            _blackImage = LoadImage(_mvrWarperMPCDI.GetBlackImage());
        }
    }

    Texture2D LoadImage(vrImage iImage)
    {
        if (iImage != null)
        {
            int width = (int)iImage.GetWidth();
            int height = (int)iImage.GetHeight();

            Texture2D tex = new Texture2D(width, height, TextureFormat.RGB24, false);

            for (uint y = 0; y < iImage.GetHeight(); y++)
            {
                for (uint x = 0; x < iImage.GetWidth(); x++)
                {
                    byte value = iImage.GetValue(x, y);
                    Color color = new Color(value / 255.0f, value / 255.0f, value / 255.0f);
                    tex.SetPixel((int)x, height - (int)y, color);
                }
            }

            tex.Apply();
            return tex;
        }

        return null;
    }

    void SetupViewCamera()
    {
        // _mvrCam might have been set by the ICVFX script already
        if (_mvrCam == null)
        {
            _mvrCam = MVRNodesMapper.Instance.GetNode(this.gameObject) as vrCamera;
        }

        if (_mvrCam != null)
        {
            _viewCamera = this.GetComponent<Camera>();

            // Remove our warping layer so we don't render the warping mesh
            _viewCamera.cullingMask &= (~MVRTools.GetWarpingLayerMask());
        }
    }

    public void ICVFXFrom(MVRWarperMesh iScript)
    {
        _mvrCam = iScript.GetMVRCamera();

        SetupViewCamera();
        PrepareWarper();

        // Delete grid mesh that was cloned from the background camera
        GameObject.Destroy( transform.Find("MVRGridMeshGO" + _mvrWarper.GetName()).gameObject);

        CreateGridMesh();
    }

    private void Start()
    {
        SetupViewCamera();

        // If we are a copy, _mvrCam wil be set in CopyFrom
        if (_mvrCam != null)
        {
            PrepareWarper();
            CreateGridMesh();

#if UNITY_EDITOR
            Selection.activeObject = _viewCamera.gameObject;
#endif
        }
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        uint overscan = MVR.DisplayMgr.GetOverscan();

        int vpWidth = (int)_mvrCam.GetViewport().GetWidth();
        int vpHeight = (int)_mvrCam.GetViewport().GetHeight();

        if (_RT == null)
        {
            RenderTextureDescriptor desc;

            // If overscan, only warp the original viewport
            if (overscan > 0)
            {
                desc = source.descriptor;

                desc.width = vpWidth;
                desc.height = vpHeight;
            }
            else
            {
                if (destination != null)
                {
                    desc = destination.descriptor;
                }
                else
                {
                    desc = source.descriptor;
                }
            }

            _RT = new RenderTexture(desc);
        }

        if (_overscanDestination == null && overscan > 0)
        {
            var desc = destination.descriptor;
            desc.width = vpWidth;
            desc.height = vpHeight;

            _overscanDestination = new RenderTexture(desc);
        }

        Matrix4x4 projMat = _viewCamera.projectionMatrix;

        if (overscan > 0)
        {
            // We need to get the non-overscanned texture here
            Graphics.CopyTexture(source, 0, 0, (int)overscan, (int)overscan,
                vpWidth, vpHeight, _RT, 0, 0, 0, 0);

            // Ignore overscan for warping only
            MVR.DisplayMgr.SetOverscan(0);
            _mvrCam.Update();
            projMat = _mvrCam.GetProjectionMatrix().RawToUnity();
            MVR.DisplayMgr.SetOverscan(overscan);
        }
        else
        {
            // When using post-processing effects with the built-in pipeline,
            // The source RT causes a black render. So we copy the source RT
            // to an internal RT
            Graphics.Blit(source, _RT);
        }

        if (_warpMaterial == null)
        {
            _warpMaterial = new Material(Shader.Find("MVR/WarpBlend"));
        }

        /*
        string clusterId = "Local";
        if(MVR.ClusterMgr.GetMyClusterNode() != null)
        {
            clusterId = MVR.ClusterMgr.GetMyClusterNode().GetClusterID();
        }

        MVRTools.SaveRenderTexture(source, $"c:\\temp\\source_{clusterId}.png");*/

        _warpMaterial.SetMatrix("_LocalToWorldMatrix", _warperMeshGO.transform.localToWorldMatrix);
        _warpMaterial.SetMatrix("_WorldToCameraMatrix", _viewCamera.worldToCameraMatrix);
        _warpMaterial.SetMatrix("_ProjMatrix", projMat);
        _warpMaterial.SetTexture("_MainTex", _RT);

        if (_mvrWarperMPCDI != null)
        {
            _warpMaterial.SetTexture("_BlendTex", _blendingImage);
            _warpMaterial.SetTexture("_BlackTex", _blackImage);
            _warpMaterial.SetFloat("_Gamma", (float)_mvrWarperMPCDI.GetGamma());
        }
        else
        {
            _warpMaterial.SetFloat("_Gamma", 1.0f);
        }

        bool passOk = _warpMaterial.SetPass(0);

        if(passOk)
        {
            var previousRenderTexture = RenderTexture.active;

            if (overscan > 0)
            {
                RenderTexture.active = _overscanDestination;
            }
            else
            {
                RenderTexture.active = destination;
            }

            GL.PushMatrix();
            GL.LoadPixelMatrix(-1.0f, 1.0f, -1.0f, 1.0f);
            Graphics.DrawMeshNow(_gridMesh, _gridMeshGO.transform.localToWorldMatrix);
            GL.PopMatrix();

            RenderTexture.active = previousRenderTexture;

            if (overscan > 0)
            {
                float wScale = destination.width / (float)vpWidth;
                float hScale = destination.height / (float)vpHeight;

                float wOffset = -overscan / (float)vpWidth;
                float hOffset = -overscan / (float)vpHeight;

                // Copy the non-overscan image to the destination, which has an overscanned resolution
                Graphics.Blit(_overscanDestination, destination, new Vector2(wScale, hScale), new Vector2(wOffset, hOffset));
            }
        }
        else
        {
            MVRTools.Log(1, "[X] MVRWarperMesh: SetPass failed.");
        }
    }
}
