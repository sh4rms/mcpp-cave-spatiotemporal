﻿/* MVRNavigationWandJoystick
 * MiddleVR
 * (c) MiddleVR
 */

using MiddleVR;
using MiddleVR.Unity;
using UnityEngine;

public class MVRNavigationWandJoystick : MonoBehaviour
{
    public float TranslationSpeed = 1.0f;
    public float RotationSpeed = 45.0f;
    public bool Fly = false;
    public bool LockMultiUserNavigations = true;

    private MVRWand _wand = null;
    public MVRWand Wand { get { return _wand; } }

    private GameObject _rootNode = null;
    public GameObject RootNode { get { return _rootNode; } }

    private GameObject _directionReferenceNode = null;
    public GameObject DirectionReferenceNode {  get { return _directionReferenceNode; } }

    private GameObject _pivotNode = null;
    public GameObject PivotNode { get { return _pivotNode; } }

    private GameObject _user0 = null;

    #region MonoBehaviour
    private void Start()
    {
        _wand = gameObject.GetComponent<MVRWand>();

        string handNodeName = "HandNode";
        string headNodeName = "HeadNode";

        int userIndex = _wand.GetUserIndex();

        if(userIndex >= 0)
        {
            // Multi-user cfg
            handNodeName = "User" + userIndex.ToString() + "." + handNodeName;
            headNodeName = "User" + userIndex.ToString() + "." + headNodeName;

            _rootNode = GameObject.Find("User" + userIndex.ToString());

            _user0 = GameObject.Find("User0");
        }
        else
        {
            _rootNode = MVRTools.GetMVRManager().GetRoot();
        }

        _directionReferenceNode = GameObject.Find(handNodeName);
        _pivotNode = GameObject.Find(headNodeName);


        if (_directionReferenceNode == null || _pivotNode == null || _rootNode == null )
        {
            MVRTools.Log(VRLogLevel.Info, "[X] VRNavigationWandJoystick: One or several nodes are missing.");
        }
    }

    private void Update()
    {
        float dt = (float)MVR.Kernel.GetDeltaTime();
        float x = _wand.GetHorizontalAxisValue();
        float y = _wand.GetVerticalAxisValue();

        // Translation
        if (Mathf.Abs(y) > 0.01f)
        {
            float speed = y * TranslationSpeed * dt;
            Vector3 front = _directionReferenceNode.transform.forward;

            if (!Fly)
            {
                front.y = 0.0f;
            }

            _rootNode.transform.Translate(front * speed, Space.World);
        }

        // Rotation
        if (Mathf.Abs(x) > 0.01f)
        {
            float speed = x * RotationSpeed * dt;

            _rootNode.transform.RotateAround(_pivotNode.transform.position, new Vector3(0, 1, 0), speed);
        }

        if (_user0 != null && LockMultiUserNavigations)
        {
            // If we are in a multi-user configuration and we are not user 0, follow User0
            _rootNode.transform.localPosition = _user0.transform.localPosition;
            _rootNode.transform.localRotation = _user0.transform.localRotation;
        }

        vrKeyboard keyb = MVR.DeviceMgr.GetKeyboard();

        if (keyb != null)
        {
            if (keyb.IsKeyPressed(MVR.VRK_LSHIFT) || keyb.IsKeyPressed(MVR.VRK_RSHIFT))
            {

                if (keyb.IsKeyToggled(MVR.VRK_F))
                {
                    Fly = !Fly;
                    MVRTools.Log(2, "MVRNavigationWandJoystick::Fly = " + Fly);
                }

                // If we are in a multi-user configuration and we are not user 0, teleport to User0
                if (_wand != null && _wand.GetUserIndex() >= 1)
                {
                    if (keyb.IsKeyToggled(MVR.VRK_T))
                    {
                        if (_user0 == null)
                        {
                            MVRTools.Log("[X] Couldn't teleport to User0 because it was not found.");
                        }
                        else
                        {
                            MVRTools.Log("[+] Teleport User" + _wand.GetUserIndex().ToString() + " to User0.");
                            _rootNode.transform.localPosition = _user0.transform.localPosition;
                            _rootNode.transform.localRotation = _user0.transform.localRotation;
                        }
                    }

                    if (keyb.IsKeyToggled(MVR.VRK_L))
                    {
                        LockMultiUserNavigations = !LockMultiUserNavigations;
                        MVRTools.Log("[+] Lock Multi User Navigations = " + LockMultiUserNavigations.ToString());
                    }
                }
            }
        }
    }
#endregion
}
