/* MVRSwitchUser
 * MiddleVR
 * (c) MiddleVR
 * 
 * Allows the "view" to be passed to other users based on the proximity of the "HandNode"
 * to a user's HeadNode.
 * 
 * Add this script to the MVRWand.
 * 
 * See a sample template configuration in C:\Program Files\MiddleVR3\data\Config\VR\Wall_SwitchUser.vrx
 * 
 * Will wait for "SwitchWaitTime" before switching the view.
 * 
 * The MVR configuration must comply to the following rules:
 * - Must contain a node called exactly "HandNode"
 * - Must contain a node called exactly "HeadNode"
 * - For each user, have a "User1.HeadNode", "User2.HeadNode", ...
 *   that has a Tracker assigned to it.
 *   
 * The position of HandNode will be compared to all the HeadNodes.
 * The HeadNode which is closer to the HandNode will have the "focus",
 * ie its local position will be copied the original "HeadNode".
 * 
 * This means that the glasses offsets must be the same for all users.
 */
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;

public class MVRSwitchUser : MonoBehaviour
{
    public double SwitchWaitTime = 500;

    private vrNode3D _handNode = null;
    private vrNode3D _defaultHeadNode = null;
    private vrNode3D _currentUserHeadNode = null;
    private vrNode3D _currentClosestHeadNode = null;
    private double _userSwitchRequestTime = -1.0;
    private List<vrNode3D> _otherHeadNodes = new List<vrNode3D>();

    void Start()
    {
        _handNode = MVR.DisplayMgr.GetNode("HandNode");
        if (_handNode == null)
        {
            MVR.Log(1, "[X] MVRSwitchUser: Couldn't find HandNode");
            return;
        }

        _defaultHeadNode = MVR.DisplayMgr.GetNode("HeadNode");

        if (_defaultHeadNode == null)
        {
            MVR.Log(1, "[X] MVRSwitchUser: Couldn't find HeadNode");
            return;
        }

        _currentClosestHeadNode = _defaultHeadNode;

        foreach (var headNode in MVR.DisplayMgr.Nodes)
        {
            if (headNode.GetName().Contains("HeadNode") && headNode.GetName() != "HeadNode")
            {
                _otherHeadNodes.Add(headNode);
            }
        }
    }

    float GetSqrDistance(vrNode3D node1, vrNode3D node2)
    {
        vrVec3 pos = node1.GetPositionRelative(node2);
        float sqrDistance = pos.x * pos.x + pos.y * pos.y + pos.z * pos.z;
        return sqrDistance;
    }

    vrNode3D GetClosestNode()
    {
        var closestNode = _currentClosestHeadNode;
        float closestDistance = Mathf.Infinity;

        foreach (var node in _otherHeadNodes)
        {
            float distance = GetSqrDistance(_handNode, node);
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestNode = node;
            }
        }

        return closestNode;
    }

    void Update()
    {
        if (_handNode == null || _defaultHeadNode == null || _otherHeadNodes.Count == 0)
            return;

        var closestNode = GetClosestNode();

        if (closestNode != _currentClosestHeadNode)
        {
            _userSwitchRequestTime = MVR.Kernel.GetTime();
            _currentClosestHeadNode = closestNode;
        }
        else
        {
            if (_currentUserHeadNode != _currentClosestHeadNode
                && MVR.Kernel.GetTime() - _userSwitchRequestTime > SwitchWaitTime)
            {
                _currentUserHeadNode = _currentClosestHeadNode;
                _userSwitchRequestTime = -1;

                MVRTools.Log(2, "MVRSwitchUser: Switching to '" + _currentUserHeadNode.GetName() + "'.");
            }
        }

        CopyMatrixFromCurrentUser();
    }

    void CopyMatrixFromCurrentUser()
    {
        if (_currentUserHeadNode != null && _defaultHeadNode != null)
        {
            _defaultHeadNode.SetMatrixLocal(_currentUserHeadNode.GetMatrixLocal());
            MVRTools.Log(4, "MVRSwitchUser: Forcing MVR.DisplayMgr.Update");
            MVR.DisplayMgr.Update(); // Force recalculation of vrCamera's orientations & projection matrices
        }
    }
}
