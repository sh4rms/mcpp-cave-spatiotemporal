/* MVRInteractionManipulationHomer
 * MiddleVR
 * (c) MiddleVR
 * */
using UnityEngine;

public class MVRInteractionManipulationHomer : MonoBehaviour
{
    public bool Grabbed = false;

    public Transform TargetNode;

    private MVRWand _wand = null;
    private GameObject _wandRay = null;
    private GameObject _currentSelectedObject = null;

    // Initial position and rotation of the target node
    private Vector3 _targetInitialPosition;
    private Quaternion _targetInitialRotation;

    // Initial position and rotation of the follower node
    private Vector3 _followerInitialPosition;
    private Quaternion _followerInitialRotation;


    private void Start()
    {
        TargetNode = GameObject.Find("HandNode").transform;
        _wand = this.GetComponent<MVRWand>();
        _wandRay = GameObject.Find("MVRRayMesh");
    }

    public void ResetPos()
    {
        //transform.localPosition = _initPos;
        //transform.localRotation = _initRot;
    }

    public void Grab(GameObject iObject)
    {
        // Hide wand ray
        _wandRay.GetComponent<Renderer>().enabled = false;

        _currentSelectedObject = iObject;
        Grabbed = true;

        //_currentSelectedObject.GetComponent<Rigidbody>().isKinematic = true;

        // Store initial positions and rotations of both target and follower
        _targetInitialPosition = TargetNode.position;
        _targetInitialRotation = TargetNode.rotation;

        _followerInitialPosition = _currentSelectedObject.transform.position;
        _followerInitialRotation = _currentSelectedObject.transform.rotation;
    }

    public void Ungrab()
    {
        // Hide wand ray
        _wandRay.GetComponent<Renderer>().enabled = true;

        Grabbed = false;
        _currentSelectedObject = null;
        //_currentSelectedObject.GetComponent<Rigidbody>().isKinematic = false;
    }

    void Update()
    {
        if (_wand.IsButtonToggled(0) && !Grabbed)
        {
            // Retrieve selection result
            MVRSelection selection = _wand.GetSelection();

            if (selection != null && selection.SelectedObject.GetComponent<MVRActor>().Grabable)
            {
                Grab(selection.SelectedObject);
            }
        }
        else if (_wand.IsButtonToggled(0, false) && Grabbed)
        {
            Ungrab();
        }

        if (Grabbed)
        {
            // Calculate the delta in position and rotation
            Vector3 positionDelta = TargetNode.position - _targetInitialPosition;
            Quaternion rotationDelta = TargetNode.rotation * Quaternion.Inverse(_targetInitialRotation);

            // Apply the delta to the follower's initial position and rotation
            _currentSelectedObject.transform.position = _followerInitialPosition + positionDelta;
            _currentSelectedObject.transform.rotation = rotationDelta * _followerInitialRotation;
        }

    }
}
