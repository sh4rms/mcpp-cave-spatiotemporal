/* MVRFollowMVRNode
 * MiddleVR
 * (c) MiddleVR
 * 
 * Will copy the transform of a MiddleVR node to the current GameObject
 */

using UnityEngine;

[AddComponentMenu("MiddleVR/Samples/MVR Follow Node")]
public class MVRFollowMVRNode : MonoBehaviour
{
    public string VRNodeName = "HeadNode";
    public Vector3 RotationOffsetsEuler;

    private GameObject _node = null;

    #region MonoBehaviour

    public void SetNode(GameObject iNode)
    {
        _node = iNode;

        if (_node != null) VRNodeName = _node.name;
    }

    private void Update()
    {
        if (_node == null)
        {
            _node = GameObject.Find(VRNodeName);
        }

        if (_node != null)
        {
            transform.position = _node.transform.position;
            transform.rotation = _node.transform.rotation * Quaternion.Euler(RotationOffsetsEuler);
        }
    }
    #endregion
}
