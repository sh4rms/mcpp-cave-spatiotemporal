/* MVRTransformUnityToMVR
 * MiddleVR
 * (c) MiddleVR
 * Assigns a GameObject's local position & orientation to a MiddleVR vrNode3D
 */

using MiddleVR;
using MiddleVR.Unity;
using UnityEngine;

[AddComponentMenu("MiddleVR/Interactions/MVR Sync Transform")]
public class MVRTransformUnityToMVR : MonoBehaviour
{
    public string MVRNodeName = "HeadNode";

    private vrNode3D _MVRnode = null;

    #region MonoBehaviour
    private void Update()
    {
        if (_MVRnode == null)
        {
            _MVRnode = MVR.DisplayMgr.GetNode(MVRNodeName);
        }

        if (_MVRnode != null)
        {
            vrVec3 position = FromUnity(transform.localPosition);
            vrQuat orientation = FromUnity(transform.localRotation);

            _MVRnode.SetPositionLocal(position);
            _MVRnode.SetOrientationLocal(orientation);
        }
    }

    public vrVec3 FromUnity(Vector3 iVec)
    {
        var v = new vrVec3();

        v.x = iVec.x;
        v.y = iVec.z;
        v.z = iVec.y;
        return v;
    }

    public vrQuat FromUnity(Quaternion iQuat)
    {
        var q = new vrQuat();

        q.x = +iQuat.x;
        q.y = +iQuat.z;
        q.z = +iQuat.y;
        q.w = -iQuat.w;

        return q;
    }
    #endregion
}
