﻿/* MVRNavigationController
 * MiddleVR
 * (c) MiddleVR
 */

using MiddleVR;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class MVRNavigationController : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    public float TranslationSpeed = 1.0f;
    public float RotationSpeed = 10.0f;
    private float jumpHeight = 1.0f;
    private float gravityValue = -9.81f;

    private void Start()
    {
        controller = this.GetComponent<CharacterController>();

        // Disable wand navigations
#if UNITY_2023_1_OR_NEWER
        var wands = GameObject.FindObjectsByType<MVRWand>(FindObjectsSortMode.None);
#else
        var wands = GameObject.FindObjectsOfType<MVRWand>();
#endif
        foreach (var wand in wands)
        {
            if( wand.transform.IsChildOf(this.transform))
            {
                var joy = wand.GetComponent<MVRNavigationWandJoystick>();
                if( joy ) joy.enabled = false;

                var elastic = wand.GetComponent<MVRNavigationElastic>();
                if (elastic) elastic.enabled = false;
            }
        }
    }

    private void Update()
    {
        // Disable wand navigs
        float horizontal = MVR.DeviceMgr.GetWandHorizontalAxisValue();
        float vertical = MVR.DeviceMgr.GetWandVerticalAxisValue();

        groundedPlayer = controller.isGrounded;
        if (groundedPlayer && playerVelocity.y < 0)
        {
            playerVelocity.y = 0f;
        }

        Vector3 move = transform.TransformDirection(new Vector3(0, 0, vertical));
        controller.Move(move * (float)MVR.Kernel.GetDeltaTime() * TranslationSpeed);

        Vector3 rotation = new Vector3(0, horizontal * (float)MVR.Kernel.GetDeltaTime() * RotationSpeed);
        this.transform.Rotate(rotation);

        // Jump
        if (MVR.DeviceMgr.IsWandButtonToggled(1) && groundedPlayer)
        {
            playerVelocity.y += Mathf.Sqrt(jumpHeight * -3.0f * gravityValue);
        }

        playerVelocity.y += gravityValue * (float)MVR.Kernel.GetDeltaTime();
        controller.Move(playerVelocity * (float)MVR.Kernel.GetDeltaTime());
    }
}
