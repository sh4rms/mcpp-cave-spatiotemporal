﻿/* MVRInteractionManipulationRay
 * MiddleVR
 * (c) MiddleVR
 *
 * Note: Made to be attached to the Wand
 */

using MiddleVR;
using UnityEngine;

public class MVRInteractionManipulationRay : MonoBehaviour
{
    private vrNode3D _handNode = null;
    private MVRWand _wand = null;
    private MVRRaySelection _selectionScript = null;
    private InteractionState _state = InteractionState.Inactive;

    private GameObject _currentSelectedObject = null;
    private GameObject _currentManipulatedObject = null;
    private bool _manipulatedObjectInitialIsKinematic;

    private Vector3 _startParentPosition;
    private Vector3 _startChildPosition;
    private Quaternion _startParentRotationQ;
    private Quaternion _startChildRotationQ;

    private enum InteractionState
    {
        Inactive,
        Running
    }

    #region MonoBehaviour
    private void Start()
    {
        _handNode = MVR.DisplayMgr.GetNode("HandNode");
        _wand = this.GetComponent<MVRWand>();
        _selectionScript = this.GetComponent<MVRRaySelection>();

        if (_handNode == null || _wand == null)
        {
            MVR.Log(VRLogLevel.Info, "[X] VRInteractionManipulationRay: One or several nodes are missing.");
        }
    }

    private void Update()
    {
        // Retrieve selection result
        MVRSelection selection = _wand.GetSelection();

        if (selection == null || !selection.SelectedObject.GetComponent<MVRActor>().Grabable)
        {
            return;
        }

        _currentSelectedObject = selection.SelectedObject;

        switch (_state)
        {
            case InteractionState.Inactive:
                {
                    if (_wand.IsButtonPressed(0))
                    {
                        Grab(_currentSelectedObject);
                        _state = InteractionState.Running;
                    }
                    break;
                }

            case InteractionState.Running:
                {
                    // Simulate parent child relationship
                    Matrix4x4 parentMatrix = Matrix4x4.TRS(transform.position, transform.rotation, transform.lossyScale);

                    _currentManipulatedObject.transform.position = parentMatrix.MultiplyPoint3x4(_startChildPosition);
                    _currentManipulatedObject.transform.rotation = (transform.rotation * Quaternion.Inverse(_startParentRotationQ)) * _startChildRotationQ;

                    if (!_wand.IsButtonPressed(0))
                    {
                        Ungrab();
                        _state = InteractionState.Inactive;
                    }
                    break;
                }
        }
    }
    #endregion

    Vector3 DivideVectors(Vector3 num, Vector3 den)
    {
        return new Vector3(num.x / den.x, num.y / den.y, num.z / den.z);
    }

    public void Grab(GameObject iGrabbedObject)
    {
        // Pause rigidbody acceleration 
        Rigidbody manipulatedRigidbody = iGrabbedObject.GetComponent<Rigidbody>();
        if (manipulatedRigidbody != null)
        {
            _manipulatedObjectInitialIsKinematic = manipulatedRigidbody.isKinematic;
            manipulatedRigidbody.isKinematic = true;
        }

        // Initialize manipulated node for parent / child relationship simulation
        _currentManipulatedObject = iGrabbedObject;

        _startParentPosition = transform.position;
        _startParentRotationQ = transform.rotation;

        _startChildPosition = _currentManipulatedObject.transform.position;
        _startChildRotationQ = _currentManipulatedObject.transform.rotation;

        _startChildPosition = DivideVectors(Quaternion.Inverse(transform.rotation) * (_startChildPosition - _startParentPosition), transform.lossyScale);

        // Deactivate selection during the manipulation
        _selectionScript.enabled = false;
    }

    public void Ungrab()
    {
        if (_currentManipulatedObject == null)
        {
            return;
        }

        // Unpause rigidbody acceleration 
        Rigidbody manipulatedRigidbody = _currentManipulatedObject.GetComponent<Rigidbody>();
        if (manipulatedRigidbody != null)
        {
            manipulatedRigidbody.isKinematic = _manipulatedObjectInitialIsKinematic;
        }

        // Reactivate selection after the manipulation
        _selectionScript.enabled = true;

        _currentManipulatedObject = null;
    }
}
