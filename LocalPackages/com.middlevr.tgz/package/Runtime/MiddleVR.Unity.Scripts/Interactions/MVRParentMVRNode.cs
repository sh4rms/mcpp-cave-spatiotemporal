/* MVRParentMVRNode
 * MiddleVR
 * (c) MiddleVR
 * 
 * Attaches an MVR Node to the current GameObject
 * without modifying its local position and rotation
 */
using UnityEngine;

public class MVRParentMVRNode : MonoBehaviour
{
    public string MVRNodeName = "HeadNode";

    void Start()
    {
        var mvrGO = GameObject.Find(MVRNodeName);

        if (mvrGO != null)
        {
            Vector3 pos = mvrGO.transform.localPosition;
            Quaternion quat = mvrGO.transform.localRotation;

            mvrGO.transform.parent = transform;
            mvrGO.transform.localPosition = pos;
            mvrGO.transform.localRotation = quat;
        }
    }
}
