/* MVRCenterNode
 * MiddleVR
 * (c) MiddleVR
 * 
 * Offsets the current node's position so that the specified MVRNode
 * is centered on this node's parent
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MVRCenterNode : MonoBehaviour
{
    public string MVRNode = "HeadNode";

    // Start is called before the first frame update
    void Start()
    {
        var go = GameObject.Find(MVRNode);

        if (go != null && this.transform.parent != null)
        {
            Vector3 parentRelative = this.transform.parent.InverseTransformPoint(go.transform.position);
            this.transform.localPosition = -parentRelative;
        }
    }
}
