using UnityEngine;
using MiddleVR;
using System;
using MiddleVR.Unity;
using UnityEditor;

public class MVRClusterDisableComponent : MonoBehaviour
{
    public string ComponentToDisable;

    public bool DisableIfServer = false;
    public bool DisableIfClient = false;
    public bool DisableIfCluster = false;
    public bool DisableIfNoCluster = false;
    public bool DisableIfMVR = false;
    public bool DisableIfNoMVR = false;

    void DisableComponent(string componentName)
    {
        {
            // Get all components attached to this GameObject
            Component[] components = GetComponents<Component>();

            // Log the type name and namespace of each component
            foreach (Component component in components)
            {
                Type componentType = component.GetType();
                string namespaceName = componentType.Namespace ?? "No Namespace";
                string typeName = componentType.Name;

                MVRTools.Log(3, $"[ ] MVRClusterDisableComponent: Component: {typeName}, Namespace: {namespaceName}, Assembly: {componentType.Assembly.FullName}");
            }
        }

        {
            // Getting the Type from the component name
            Type type = Type.GetType(componentName);

            if (type == null)
            {
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    type = asm.GetType(componentName);
                    if (type != null) break;
                }
            }

            if (type == null)
            {
                MVRTools.Log("[X] MVRClusterDisableComponent: Component not found: " + componentName);
                return;
            }

            // Getting the component of that type
            Component component = GetComponent(type);
            if (component == null)
            {
                MVRTools.Log("[X] MVRClusterDisableComponent: Component not attached: " + componentName);
                return;
            }

            // Disable the component if it is a Behaviour
            if (component is Behaviour behaviour)
            {
                behaviour.enabled = false;
                MVRTools.Log("[+] MVRClusterDisableComponent: Component disabled: " + componentName);
            }
            else
            {
                MVRTools.Log("[X] MVRClusterDisableComponent: Component cannot be disabled: " + componentName);
            }
        }
    }

    void Start()
    {
        bool disable = false;

        if (MVRTools.GetMVRManager() == null && DisableIfNoMVR)
        {
            disable = true;
        }

        if (MVRTools.GetMVRManager() != null)
        {
            if (DisableIfMVR)
            {
                disable = true;
            }

            if (MVR.ClusterMgr != null && MVR.ClusterMgr.IsServer() && DisableIfServer)
            {
                disable = true;
            }

            if (MVR.ClusterMgr != null && MVR.ClusterMgr.IsClient() && DisableIfClient)
            {
                disable = true;
            }

            if (MVR.ClusterMgr != null && MVR.ClusterMgr.IsClusterConfig() && DisableIfCluster)
            {
                disable = true;
            }

            if (MVR.ClusterMgr != null && !MVR.ClusterMgr.IsClusterConfig() && DisableIfNoCluster)
            {
                disable = true;
            }

            if (disable)
            {
                DisableComponent(ComponentToDisable);
            }
        }
    }
}
