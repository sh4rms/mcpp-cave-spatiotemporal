/* MVRClusterTexture
 * MiddleVR
 * (c) MiddleVR
 */

//#define SAVEFILE
//#define LOCALDEBUG

using UnityEngine;
using UnityEngine.Assertions;
using Unity.Collections;
using UnityEngine.Rendering;

using System;
using System.Collections;
using System.Runtime.InteropServices;

using MiddleVR.Unity;
using MiddleVR;

using System.Diagnostics;

#if SAVEFILE
using System.IO;
#endif

#if !LOCALDEBUG
[MVRDisable(ifNoCluster: true, ifNoMVR: true)]
#endif

[AddComponentMenu("MiddleVR/Cluster/MVR Cluster Texture")]
public class MVRClusterTexture : MonoBehaviour
{
#if SAVEFILE
    [SerializeField]
    string filePath = "c:\\temp\\test.h264";

    FileStream fileStream_;
    BinaryWriter binaryWriter_;
#endif

#if LOCALDEBUG
    public bool LocalDebug = true;
    public GameObject DebugDestination = null;
    public bool UseGPU = true;
#else
    private bool LocalDebug = false;
    private GameObject DebugDestination = null;
    private bool UseGPU = true;
#endif

    #region Encoder parameters
    private MVREncoder.Codec _encoderCodec = MVREncoder.Codec.UNDEFINED;
    public float CompressionFactor = 1;
    public bool Lossless = false;

    private MVREncoder.Desc _settings;
    private bool _forceIdrFrame = true;

    private MVREncoder _encoder = null;
#if LOCALDEBUG
    public Texture _encodedTexture = null;
#else
    private Texture _encodedTexture = null;
#endif
    private byte[] _encodedTextureBytes = null;
    #endregion

    #region Decoder parameters
#if LOCALDEBUG
    public Texture2D _decodedTexture = null;
#else
    private Texture2D _decodedTexture = null;
#endif
    MVRDecoder _decoder = null;
    #endregion

    private byte[] _recvBytes;
    private GCHandle _pinnedArray;

    private bool _mainTextureLog = false;

    void ProcessCommandLineArguments()
    {
        string[] args = System.Environment.GetCommandLineArgs();

        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "--mvr-codec")
            {
                string codec = args[i + 1];
                switch (codec.ToUpper())
                {
                    case "H264": _encoderCodec = MVREncoder.Codec.H264; break;
                    case "HEVC": case "H265": _encoderCodec = MVREncoder.Codec.HEVC; break;
                    case "AV1": _encoderCodec = MVREncoder.Codec.AV1; break;
                    case "RAW": UseGPU = false; break;
                    default:
                        MVRTools.Log("[X] Failed to set codec " + codec);
                        break;
                }
            }

            if (args[i] == "--mvr-compression-factor")
            {
                string factor = args[i + 1];
                float f;
                if (float.TryParse(factor, out f))
                {
                    CompressionFactor = f;
                }
            }

            if (args[i] == "--mvr-lossless")
            {
                string lossless = args[i + 1];

                switch(lossless.ToUpper())
                {
                    case "TRUE":
                    case "1":
                        Lossless = true;
                        break;
                    case "FALSE":
                    case "0":
                        Lossless = false;
                        break;
                    default:
                        MVRTools.Log("[X] Failed to read lossless option " + lossless);
                        break;
                }
            }
        }
    }

    bool Init()
    {
        Texture texture = null;

        if (_encodedTexture == null)
        {
            var renderer = GetComponent<Renderer>();

#if MVR_HDRP
            if (renderer.material.HasProperty("_ColorMap"))
            {
                texture = renderer.material.GetTexture("_ColorMap");
            }
            else if (renderer.material.HasProperty("_BaseColorMap"))
            {
                texture = renderer.material.GetTexture("_BaseColorMap");
            }
#else
            if (renderer.material.HasProperty("_BaseMap"))
            {
                texture = renderer.material.GetTexture("_BaseMap");
            }
            else
            if (renderer.material.HasProperty("_MainTex"))
            {
                texture = renderer.material.GetTexture("_MainTex");
            }
#endif

            if (texture != null)
            {
                SetTexture(texture);
            }
            else
            {
                if (!_mainTextureLog)
                {
                    MVRTools.Log(2, $"[~] MVRClusterTexture::Init: {this.name}: Couldn't find renderer.material.mainTexture.");
                    _mainTextureLog = true;
                }
            }
        }

        return (_encodedTexture != null);
    }

    void Start()
    {
        ProcessCommandLineArguments();

        MVRTools.Log(3, $"[+] MVRClusterTexture: GameObject {gameObject.name}");

        Cluster.AddMessageHandler(this, OnSynchronizedByteArray, channel: 1);
        Cluster.AddMessageHandler<MVREncoder.Codec>(this, OnSetCodec, channel: 2);

        if (MVRTools.GetMVRManager() && MVR.ClusterMgr.IsClusterConfig())
        {
            LocalDebug = false;
        }

        Init();
    }

    public void SetTexture(Texture iTexture)
    {
        Assert.IsNotNull(iTexture);

        _encodedTexture = iTexture;

        //Encoder
        if (Cluster.IsServer || LocalDebug)
        {
            if (UseGPU)
            {
                MVRTools.Log(3, $"[+] MVRClusterTexture: Creating Encoded texture {_encodedTexture.width}x{_encodedTexture.height}");

                if (_encodedTexture.graphicsFormat != UnityEngine.Experimental.Rendering.GraphicsFormat.R8G8B8A8_UNorm)
                {
                    MVRTools.Log(1, $"[X] MVRClusterTexture: Encoded texture is not R8G8B8A8_UNorm");
                    return;
                }

                if (_encodedTexture.isDataSRGB == true)
                {
                    MVRTools.Log(1, $"[X] MVRClusterTexture: Encoded texture is sRGB, must be linear.");
                    return;
                }

                int textureByteSize = 4;
                int textureSize = _encodedTexture.width * _encodedTexture.height * textureByteSize;
                int textureSizeKb = textureSize * 8 / 1000;
                double bitRateKbps = textureSizeKb / CompressionFactor;

                MVRTools.Log(3, $"[+] MVRClusterTexture: Bitrate = {bitRateKbps} kbps");

                _settings = new MVREncoder.Desc
                {
                    Width = _encodedTexture.width,
                    Height = _encodedTexture.height,
                    FrameRate = 60,
                    EncoderFormat = MVREncoder.Format.R8G8B8A8_UNORM,
                    BitRate = (int)bitRateKbps * 1000,
                    MaxFrameSize = 0,
                    EncoderCodec = _encoderCodec,
                    Lossless = Lossless
                };

                _encoder = new MVREncoder(this.name);
                _encoder.Create(_settings);
                _encoderCodec = (MVREncoder.Codec)_encoder.GetCodec();

                MVR.Log(2, "[ ] MVRClusterTexture: Codec: " + _encoderCodec);

                // Cluster create decoder with codec
                Cluster.BroadcastMessage(this, _encoderCodec, channel: 2);

                _encoder.onEncoded.AddListener(OnEncodedData);
            }
            else
            {
                MVRTools.Log(2, $"[+] MVRClusterTexture: SetTexture: Codec = RAW or CPU_PNG");
                Cluster.BroadcastMessage(this, MVREncoder.Codec.UNDEFINED, channel: 2);
            }
        }
    }

    void OnSetCodec(MVREncoder.Codec iCodec)
    {
        _encoderCodec = iCodec;

        MVRTools.Log(3, "[ ] MVRClusterTexture::OnSetCodec: " + _encoderCodec);

        //Decoder
        if (_encodedTexture != null && (Cluster.IsClient || LocalDebug))
        {
            if (UseGPU)
            {
                _decodedTexture = new Texture2D(_encodedTexture.width, _encodedTexture.height, TextureFormat.BGRA32, false, true);
                _decoder = new MVRDecoder();
                _decoder.Create(_decodedTexture);
                _decoder.SetCodec(_encoderCodec);
            }
            else
            {
                _decodedTexture = new Texture2D(_encodedTexture.width, _encodedTexture.height, TextureFormat.RGBA32, false, true);
            }

            if (LocalDebug && DebugDestination != null)
            {
                DebugDestination.GetComponent<Renderer>().material.mainTexture = _decodedTexture;
            }
            else
            {
                this.GetComponent<Renderer>().material.mainTexture = _decodedTexture;
            }

            StartCoroutine(CopyTextureLoop());

#if SAVEFILE
        fileStream_ = new FileStream(filePath, FileMode.Create, FileAccess.Write);
        binaryWriter_ = new BinaryWriter(fileStream_);
#endif
        }
    }

    private void Update()
    {
        if (_encodedTexture == null)
        {
            Init();
        }
        else
        {
            if (UseGPU)
            {
                if (_encoder != null && !(MVRTools.GetMVRManager() && MVR.Kernel.IsQuitting()))
                {
                    Encode();
                }
            }
            else
            {
                RenderTexture renderTexture = new RenderTexture(_encodedTexture.width, _encodedTexture.height, 24);
                Graphics.Blit(_encodedTexture, renderTexture);

                RenderTexture.active = renderTexture;

                Texture2D texture2D = new Texture2D(_encodedTexture.width, _encodedTexture.height, TextureFormat.RGBA32, false, true);
                Graphics.CopyTexture(renderTexture, texture2D);

                RenderTexture.active = null;

                AsyncGPUReadback.Request(texture2D, 0, textureData =>
                {
                    if (textureData.hasError)
                    {
                        UnityEngine.Debug.LogError("GPU readback error detected.");
                        return;
                    }

                    NativeArray<byte> rawBytes = textureData.GetData<byte>();
                    _encodedTextureBytes = new byte[rawBytes.Length];
                    rawBytes.CopyTo(_encodedTextureBytes);
#if SAVEFILE
                File.WriteAllBytes("c://temp//encoded.dat", _encodedTextureBytes);
#endif

                    if (!MVRTools.GetMVRManager() || (MVRTools.GetMVRManager() != null && !MVR.Kernel.IsQuitting()))
                    {
                        Cluster.BroadcastMessage(this, _encodedTextureBytes, channel: 1);
                    }
                });
            }
        }
    }

    void OnApplicationQuit()
    {
        if (_encoder != null)
        {
            _encoder.Destroy();
        }

        if (_decoder != null)
        {
            _decoder.Destroy();
#if SAVEFILE
            if (fileStream_ != null) 
            {
                fileStream_.Close();
            }

            if (binaryWriter_ != null) 
            {
                binaryWriter_.Close();
            }
#endif

        }
    }

    #region Cluster
    public void OnEncodedData(System.IntPtr ptr, int size)
    {
        if (!enabled) return;

        if (ptr == System.IntPtr.Zero) return;

        var bytes = new byte[size];
        Marshal.Copy(ptr, bytes, 0, size);

        MVRTools.Log(5, $"[ ] ClusterTexture sending {size} bytes");
        Cluster.BroadcastMessage(this, bytes, channel: 1);
    }

    private void OnSynchronizedByteArray(byte[] iArray)
    {
        if (Cluster.IsServer && !LocalDebug)
            return;

        if (_pinnedArray.IsAllocated)
        {
            _pinnedArray.Free();
        }

        _pinnedArray = GCHandle.Alloc(iArray, GCHandleType.Pinned);
        IntPtr pointer = _pinnedArray.AddrOfPinnedObject();

        int size = iArray.Length;

        _recvBytes = new byte[size];
        Marshal.Copy(pointer, _recvBytes, 0, size);

#if SAVEFILE
        binaryWriter_.Write(_bytes);
#endif
        if (UseGPU)
        {
            bool res = _decoder.Decode(pointer, size);
            //_decoder.CopyTexture();
        }
        else
        {
            MVRTools.Log(5, "[ ] Decoder RAW: size " + size);

            Stopwatch sw = Stopwatch.StartNew();
            sw.Start();
            _decodedTexture.LoadRawTextureData(iArray);
            _decodedTexture.Apply();
            sw.Stop();
            MVRTools.Log(3, "Time taken for LoadRawTextureData: " + sw.ElapsedMilliseconds + " ms");
        }
    }
#endregion

    #region Encoder
    void Encode()
    {
        if (!_encodedTexture) return;

        _encoder.Update();
        _encoder.EncodeTexture(_encodedTexture, _forceIdrFrame);
    }
    #endregion

    #region Decoder
    IEnumerator CopyTextureLoop()
    {
        for (; ; )
        {
            yield return new WaitForEndOfFrame();
            //CopyTexture();
        }
    }

    void CopyTexture()
    {
        _decoder.CopyTexture();
    }
    #endregion
}
