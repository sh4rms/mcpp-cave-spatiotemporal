﻿/* MVRVideoSync
 * MiddleVR
 * (c) MiddleVR
 * 
 * It is best to use the MVRClusterTexture script since it will perfectly synchronize the video.
 * 
 * Place this script on a GameObject with a Video Player.
 * If PlayOnAwake is enabled, will prepare and start the video on all cluster nodes.
 * If not, call "PlayPauseVideo" on this script to play/pause the video.
 * It will wait for all cluster nodes to finish preparing the video then start it.
 */
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.Video;
using System.Collections;

[AddComponentMenu("MiddleVR/Cluster/MVR Cluster Texture")]
public class MVRClusterVideoSyncStart : MonoBehaviour
{
    private VideoPlayer _videoPlayer = null;
    private int _nbClusterNodesReady = 0;
    private bool _ready = false;
    public bool _playing = false;

    // Start is called before the first frame update
    void Start()
    {
        Cluster.AddMessageHandler(this, ClusterPrepareThenPlayVideo, channel: 10);
        Cluster.AddMessageHandler(this, ClusterPlayPause, channel: 11);
        Cluster.AddClientMessageHandler(this, ClusterNodeVideoPrepared, channel: 12);

        _videoPlayer = GetComponent<VideoPlayer>();

        if (_videoPlayer != null && _videoPlayer.playOnAwake)
        {
            PlayPauseVideo();
        }
    }

    private void OnApplicationQuit()
    {
        Cluster.RemoveMessageHandler(this, 10);
        Cluster.RemoveMessageHandler(this, 11);
        Cluster.RemoveClientMessageHandler(this, 12);
    }

    public void PlayPauseVideo()
    {
        if (MVR.ClusterMgr.IsClient())
            return;

        if (!_ready)
        {
            Cluster.BroadcastMessage(this, "PrepareThenPlay", channel: 10);
        }
        else
        {
            Cluster.BroadcastMessage(this, "PlayPause", channel: 11);
        }
    }

    private void ClusterPrepareThenPlayVideo(string iCmd)
    {
        MVRTools.Log("ClusterPrepareThenPlayVideo");

        _videoPlayer.enabled = true;
        _videoPlayer.Play();
        _videoPlayer.Pause();
        _videoPlayer.frame = 0;

        _playing = false;

        StartCoroutine(CoWaitPrepareVideo());
    }

    private IEnumerator CoWaitPrepareVideo()
    {
        while (!_videoPlayer.isPrepared)
        {
            yield return new WaitForEndOfFrame();
        }
        MVRTools.Log("Sending Video ready");

        if (MVR.ClusterMgr.IsClient())
            Cluster.SendAsyncMessageToServer(this, "Ready", channel: 12);
        else
            ClusterNodeVideoPrepared(-1, "Ready");
    }

    private void ClusterNodeVideoPrepared(int clientId, string msg)
    {
        MVRTools.Log("Video ready from clientId " + clientId);

        _nbClusterNodesReady++;

        if (_nbClusterNodesReady == MVR.ClusterMgr.Clients.Count + 1)
        {
            _ready = true;

            MVRTools.Log("All ready, broadcast Play");

            Cluster.BroadcastMessage(this, "Play", channel: 11);
            _nbClusterNodesReady = 0;
        }
    }

    private void ClusterPlayPause(string ready)
    {
        LocalPlayPauseVideo();
    }

    private void LocalPlayPauseVideo()
    {
        MVRTools.Log("LocalPlayPauseVideo");

        _playing = !_playing;

        if (_playing)
        {
            _videoPlayer.Play();
        }
        else
        {
            _videoPlayer.Pause();
        }
    }
}
