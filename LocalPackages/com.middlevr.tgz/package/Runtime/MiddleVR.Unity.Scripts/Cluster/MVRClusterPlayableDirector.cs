/* MVRSynchronizeParticleSystem
 * MiddleVR
 * (c) MiddleVR
 */
using UnityEngine;
using UnityEngine.Playables;
using MiddleVR.Unity;

// Synchronize the time of a PlayableDirector on cluster clients
[RequireComponent(typeof(PlayableDirector))]
public class MVRClusterPlayableDirector : MonoBehaviour
{
    PlayableDirector _director = null;

    void Start()
    {
        _director = GetComponent<PlayableDirector>();

        if (Cluster.IsServer)
        {
            MVRTools.Log(5, "[ ] MVRSynchronizePlayableDirector: Server registering " + gameObject.name);
        }
        else

        {
            MVRTools.Log(5, "[ ] MVRSynchronizePlayableDirector: Client registering " + gameObject.name);

            if (_director.timeUpdateMode != DirectorUpdateMode.Manual)
            {
                _director.timeUpdateMode = DirectorUpdateMode.Manual;
            }
        }

        Cluster.AddMessageHandler<double>(this, OnSynchronizedTime, channel: 1);
    }

    void Update()
    {
        if(_director != null)
        {
            BroadcastTime();
        }
    }

    private void BroadcastTime()
    {
        if (Cluster.IsServer)
        {
            MVRTools.Log(5, $"[ ] MVRSynchronizePlayableDirector: Server broadcasting '{_director.name}' time : {_director.time}");
            Cluster.BroadcastMessage(this, _director.time, channel: 1);
        }
    }

    private void OnSynchronizedTime(double iTime)
    {
        if (Cluster.IsServer)
            return;

        _director.time = iTime;

        // XXX evaluate only of time has drifted too much ?
        _director.Evaluate();

        MVRTools.Log(5, $"[ ] MVRSynchronizePlayableDirector: Client  Director '{_director.name}' time : {_director.time}");
    }
}
