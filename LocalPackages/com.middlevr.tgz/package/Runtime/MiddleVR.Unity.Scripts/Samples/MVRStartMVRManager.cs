﻿/* MVRStartMVRManager
 * MiddleVR
 * (c) MiddleVR
 * 
 * Allows to start MiddleVR 
 */
using UnityEngine;

public class MVRStartMVRManager : MonoBehaviour
{
    public GameObject MVRManager;
    public string ConfigFile = "C:/Program Files/MiddleVR3/data/Config/Standard/VirtualCluster.vrx";

    void Start()
    {
        // On the clients, enable MiddleVR if --config is found on the command line
        string[] args = System.Environment.GetCommandLineArgs();
        bool foundCfgParam = false;

        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "--config")
            {
                foundCfgParam = true;
            }
        }

        if (foundCfgParam)
        {
            MVRManager.GetComponent<MVRManagerScript>().EditorConfigFile = ConfigFile;
            MVRManager.SetActive(true);
        }
    }

    void Update()
    {
        // On the master, wait for a key to activate the MVRManager
        // It will spawn all the cluster nodes
        if (Input.GetKey(KeyCode.Space))
        {
            MVRManager.GetComponent<MVRManagerScript>().EditorConfigFile = ConfigFile;
            MVRManager.GetComponent<MVRManagerScript>().ForceEnable = true;
            MVRManager.SetActive(true);
        }
    }
}
