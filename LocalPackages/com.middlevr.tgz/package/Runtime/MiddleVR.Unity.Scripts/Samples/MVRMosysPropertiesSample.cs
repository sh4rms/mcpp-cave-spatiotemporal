﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;


public class MVRMosysPropertiesSample : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        vrDriver MosysDriver = MVR.DeviceMgr.GetDriver("Mo-sys Driver");
        if (MosysDriver != null)
        {
            float focus = MosysDriver.GetProperty("Focus").GetFloat();
            float zoom = MosysDriver.GetProperty("Zoom").GetFloat();

            Debug.Log("Mosys:");
            Debug.Log("       Zoom: " + zoom);
            Debug.Log("       Focus: " + focus);
        }
    }
}
