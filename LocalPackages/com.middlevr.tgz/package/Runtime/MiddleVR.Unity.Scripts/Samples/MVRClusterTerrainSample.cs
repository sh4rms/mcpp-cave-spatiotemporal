using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using System.Runtime.InteropServices;

[MVRDisable(ifNoCluster: true, ifNoMVR: true)]
[AddComponentMenu("MiddleVR/Cluster/MVR Cluster Terrain")]
public class MVRClusterTerrain : MonoBehaviour
{
    private Terrain _terrain;
    private TerrainData _terrainData;
    
    [Header("Synchronization Settings")]
    [Tooltip("Which channel to use for terrain data synchronization")]
    public int Channel = 10;
    
    [Tooltip("Enable to send terrain data every frame (expensive)")]
    public bool SyncEveryFrame = true;
    
    [Tooltip("Enable verbose logging")]
    public bool EnableLogging = false;
    
    // Cached terrain dimensions
    private int _heightmapWidth;
    private int _heightmapHeight;
    private int _heightmapResolution;
    
    // Reusable arrays to minimize GC allocations
    private float[,] _heightData;
    private byte[] _serializedData;
    private GCHandle _pinnedArray;
    
    void Start()
    {
        // Get the terrain component
        _terrain = GetComponent<Terrain>();
        
        if (_terrain == null)
        {
            MVRTools.Log(1, $"[X] MVRClusterTerrain: No Terrain component found on {gameObject.name}");
            enabled = false;
            return;
        }
        
        _terrainData = _terrain.terrainData;
        
        if (_terrainData == null)
        {
            MVRTools.Log(1, $"[X] MVRClusterTerrain: No TerrainData found on {gameObject.name}");
            enabled = false;
            return;
        }
        
        // Cache terrain dimensions
        _heightmapResolution = _terrainData.heightmapResolution;
        _heightmapWidth = _heightmapResolution;
        _heightmapHeight = _heightmapResolution;
        
        MVRTools.Log(2, $"[ ] MVRClusterTerrain: Initializing terrain sync for {gameObject.name}, resolution: {_heightmapResolution}x{_heightmapResolution}");
        
        // Register message handler for receiving terrain data on clients
        Cluster.AddMessageHandler(this, OnSynchronizedTerrainData, channel: Channel);
        
        // Pre-allocate arrays to avoid GC pressure
        _heightData = new float[_heightmapHeight, _heightmapWidth];
        
        // Calculate size: width * height * sizeof(float)
        int dataSize = _heightmapWidth * _heightmapHeight * sizeof(float);
        _serializedData = new byte[dataSize];
        
        int dataSizeKB = dataSize / 1024;
        int dataSizeMB = dataSizeKB / 1024;
        
        MVRTools.Log(2, $"[ ] MVRClusterTerrain: Terrain data size per frame: {dataSizeKB} KB ({dataSizeMB} MB)");
        
        if (dataSizeMB > 10)
        {
            MVRTools.Log(1, $"[!] MVRClusterTerrain: Warning - Large terrain data ({dataSizeMB} MB) will be sent every frame. Consider reducing heightmap resolution or sync frequency.");
        }
    }

    void Update()
    {
        if (SyncEveryFrame)
        {
            BroadcastTerrainData();
        }
    }
    
    /// <summary>
    /// Manually trigger terrain data synchronization (useful if SyncEveryFrame is false)
    /// </summary>
    public void SyncTerrain()
    {
        BroadcastTerrainData();
    }

    private void BroadcastTerrainData()
    {
        // Only the server sends terrain data
        if (!Cluster.IsServer)
            return;
            
        if (_terrainData == null)
            return;
        
        // Get current height data from terrain
        _heightData = _terrainData.GetHeights(0, 0, _heightmapWidth, _heightmapHeight);
        
        // Serialize height data to byte array
        SerializeHeightData(_heightData, _serializedData);
        
        if (EnableLogging)
        {
            MVRTools.Log(3, $"[ ] MVRClusterTerrain: Server sending terrain data, size: {_serializedData.Length} bytes");
        }
        
        // Broadcast to all clients
        Cluster.BroadcastMessage(this, _serializedData, channel: Channel);
    }

    private void OnSynchronizedTerrainData(byte[] data)
    {
        // Only clients should process received data
        if (Cluster.IsServer)
            return;
            
        if (_terrainData == null)
            return;
        
        if (EnableLogging)
        {
            MVRTools.Log(3, $"[ ] MVRClusterTerrain: Client receiving terrain data, size: {data.Length} bytes");
        }
        
        // Deserialize byte array back to height data
        DeserializeHeightData(data, _heightData);
        
        // Apply the received height data to the terrain
        _terrainData.SetHeights(0, 0, _heightData);
    }
    
    /// <summary>
    /// Efficiently serialize float[,] height data to byte array
    /// </summary>
    private void SerializeHeightData(float[,] heights, byte[] buffer)
    {
        int index = 0;
        
        for (int y = 0; y < _heightmapHeight; y++)
        {
            for (int x = 0; x < _heightmapWidth; x++)
            {
                float value = heights[y, x];
                byte[] floatBytes = System.BitConverter.GetBytes(value);
                
                // Copy 4 bytes (sizeof(float)) to buffer
                System.Buffer.BlockCopy(floatBytes, 0, buffer, index, sizeof(float));
                index += sizeof(float);
            }
        }
    }
    
    /// <summary>
    /// Efficiently deserialize byte array back to float[,] height data
    /// </summary>
    private void DeserializeHeightData(byte[] buffer, float[,] heights)
    {
        int index = 0;
        
        for (int y = 0; y < _heightmapHeight; y++)
        {
            for (int x = 0; x < _heightmapWidth; x++)
            {
                float value = System.BitConverter.ToSingle(buffer, index);
                heights[y, x] = value;
                index += sizeof(float);
            }
        }
    }
    
    void OnDestroy()
    {
        // Free pinned array if allocated
        if (_pinnedArray.IsAllocated)
        {
            _pinnedArray.Free();
        }
    }
}
