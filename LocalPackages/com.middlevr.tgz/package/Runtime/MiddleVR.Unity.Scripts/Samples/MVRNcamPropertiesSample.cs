﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;


public class MVRNcamPropertiesSample : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        vrDriver NcamDriver = MVR.DeviceMgr.GetDriver("Ncam Driver");
        if (NcamDriver != null)
        {
            uint frame = NcamDriver.GetProperty("TimecodeFrame").GetUInt();
            uint hour = NcamDriver.GetProperty("TimecodeHour").GetUInt();
            uint minute = NcamDriver.GetProperty("TimecodeMinute").GetUInt();
            uint second = NcamDriver.GetProperty("TimecodeSecond").GetUInt();
            uint packetNo = NcamDriver.GetProperty("PacketNo").GetUInt();
            float focus = NcamDriver.GetProperty("Focus").GetFloat();
            float zoom = NcamDriver.GetProperty("Zoom").GetFloat();


            Debug.Log(string.Format("Ncam: Timecode: {0}-{1}-{2}:{3}", hour, minute, second, frame));
            Debug.Log("       Zoom: " + zoom);
            Debug.Log("       Focus: " + focus);
        }
    }
}
