﻿/* MVRAttachMVRManagerAfterSceneLoad
 * MiddleVR
 * (c) MiddleVR
 * 
 * After a load scene:
 * - if the AttachToObject parameter is not null, will parent the MVRManager to this object
 * - if the AttachToObject parameter is null & MVRManager::AttachToCamera is true: find
 *      first camera and attach to it
 * - Otherwise leave at root
 */
using MiddleVR.Unity;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MVRAttachMVRManagerAfterSceneLoad : MonoBehaviour
{
    public GameObject AttachToObject = null;

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        //MVRTools.Log($"Scene loaded: {scene.name} (mode: {mode})");

        var mvrMgr = GameObject.Find("MVRManager");
        var mvrMgrScript = mvrMgr.GetComponent<MVRManagerScript>();

        SceneManager.MoveGameObjectToScene(mvrMgr, scene);

        if (AttachToObject == null && mvrMgrScript.AttachToCamera == true)
        {
            var cam = FindFirstCameraNotInChildren(mvrMgr);
            AttachToObject = cam.gameObject;
        }

        //MVRTools.Log("AttachToObject:" + AttachToObject);

        if (AttachToObject != null)
        {
            mvrMgr.transform.parent = AttachToObject.transform;
            mvrMgr.transform.localPosition = new Vector3(0, 0, 0);
            mvrMgr.transform.localRotation = new Quaternion(0, 0, 0, 1);
            mvrMgr.transform.localScale = new Vector3(1, 1, 1);
        }
    }

    public Camera FindFirstCameraNotInChildren(GameObject root)
    {
        if (root == null) return null;

#if UNITY_2023_1_OR_NEWER
        var cameras = Object.FindObjectsByType<Camera>(FindObjectsSortMode.None);
#else
        var cameras = Object.FindObjectsOfType<Camera>();
#endif

        foreach (var cam in cameras)
        {
            if (cam.gameObject == root)
                continue;

            if (cam.transform.IsChildOf(root.transform))
                continue;

            return cam;
        }

        return null;
    }
}
