/* MVRFlashColor
 * MiddleVR
 * (c) MiddleVR
 * 
 * Changes the color of this object based on the current frame
 * Useful to check if all cluster nodes are perfectly in sync
 * 
 */

using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;

[MVRDisable(IfNoMVR =true)]
public class MVRFlashColor : MonoBehaviour
{
    private Color[] m_FlashColors = new Color[9];

    void Start()
    {
        m_FlashColors[0] = Color.black;
        m_FlashColors[1] = Color.blue;
        m_FlashColors[2] = Color.cyan;
        m_FlashColors[3] = Color.green;
        m_FlashColors[4] = Color.grey;
        m_FlashColors[5] = Color.magenta;
        m_FlashColors[6] = Color.red;
        m_FlashColors[7] = Color.yellow;
        m_FlashColors[8] = Color.white;
    }

    void Update()
    {
        uint frame = MVR.Kernel.GetFrame();
        Color color = m_FlashColors[frame % 9];

        GetComponent<Renderer>().material.color = color;

    }
}
