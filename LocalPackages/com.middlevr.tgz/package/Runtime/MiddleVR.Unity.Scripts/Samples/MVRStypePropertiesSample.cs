﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;


public class MVRStypePropertiesSample : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        vrDriver stypeDriver = MVR.DeviceMgr.GetDriver("Stype Driver");
        if (stypeDriver != null)
        {
            uint frame = stypeDriver.GetProperty("TimecodeFrame").GetUInt();
            uint hour = stypeDriver.GetProperty("TimecodeHour").GetUInt();
            uint minute = stypeDriver.GetProperty("TimecodeMinute").GetUInt();
            uint second = stypeDriver.GetProperty("TimecodeSecond").GetUInt();
            uint packetNo = stypeDriver.GetProperty("PacketNo").GetUInt();
            float focus = stypeDriver.GetProperty("Focus").GetFloat();
            float zoom = stypeDriver.GetProperty("Zoom").GetFloat();

            Debug.Log(string.Format("Stype: Timecode: {0}-{1}-{2}:{3}", hour, minute, second, frame));
            Debug.Log("       Zoom: " + zoom);
            Debug.Log("       Focus: " + focus);
        }
    }
}
