/* MVRDisableSample
 * MiddleVR
 * (c) MiddleVR
 * 
 * Demonstrates the use of [MVRDisable]
 */
using UnityEngine;
using MiddleVR.Unity;

[MVRDisable(ifServer: true, ifClient: false, ifCluster: false, ifNoCluster: false, ifNoMVR: true)]
public class MVRDisableSample : MonoBehaviour
{
    void Start()
    {
        MVRTools.Log("Start");
    }

    void Update()
    {
        MVRTools.Log("Update");
    }
}
