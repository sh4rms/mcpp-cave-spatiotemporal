/* MVRLoadSceneSample
 * MiddleVR
 * (c) MiddleVR
 * 
 * LoadScene sample.
 * Make sure that there is only a MVRManager in the first scene and not the others
 * It will not be destroyed when loading a new scene
 * 
 */

using UnityEngine;
using MiddleVR;
using MiddleVR.Unity;
using UnityEngine.SceneManagement;

public class MVRLoadSceneSample : MonoBehaviour
{
    public string Scene = "Scene1";

    void Update()
    {
        var deviceMgr = MVR.DeviceMgr;

        if (deviceMgr != null)
        {
            // Testing keyboard key
            if (deviceMgr.IsKeyToggled(MVR.VRK_SPACE))
            {
                LoadScene();
            }
        }
    }

    public void LoadScene()
    {
        var mgr = GameObject.Find("MVRManager");

        if (mgr != null)
        {
            mgr.transform.parent = null;

            DontDestroyOnLoad(mgr);
        }

        MVRTools.Log("[+] Loading scene: " + Scene);
        SceneManager.LoadScene(Scene);
    }
}
