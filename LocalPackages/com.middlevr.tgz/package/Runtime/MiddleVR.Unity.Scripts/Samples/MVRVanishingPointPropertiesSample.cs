﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MiddleVR;
using MiddleVR.Unity;

public class MVRVanishingPointPropertiesSample : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        vrAxis props = MVR.DeviceMgr.GetAxis("VanishingPoint_Viper.Axis");
        float focalLength_mm = props.GetValue(0);
        float focusDistance_cm = props.GetValue(1);

        Debug.Log("Vanishing point:");
        Debug.Log("- Focal length (mm): " + focalLength_mm);
        Debug.Log("- Focus distance (cm): " + focusDistance_cm);
    }
}
